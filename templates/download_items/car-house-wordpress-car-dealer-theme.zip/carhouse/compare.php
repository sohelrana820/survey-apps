<?php
/*
Template Name: Vehicle Compare (Vehicle comparing layout)
*/
?>

<?php
global $carhouse;
// Displaying header
get_header();

// Displaying single page banner
get_template_part('elements/banner-single');

$vehicleIds = [];
if(isset($_GET['v1'])) {
    $vehicleIds[] = intval($_GET['v1']);
}
if(isset($_GET['v2'])) {
    $vehicleIds[] = intval($_GET['v2']);
}

$vehicles = wp_carhouse_gte_compare_entities($vehicleIds);
if(isset($vehicles['items'][0]) && isset($vehicles['items'][1])) {
    $vehicle1 = $vehicles['items'][0];
    $vehicle2 = $vehicles['items'][1];
}
?>


<div class="content-area">
    <div class="comparison-page">
        <div class="container">
            <div class="comparison-box">
                <div class="row">
                    <div class="col-lg-4 visible-lg">
                        <h3 class="heading">Select Car's You Want To Compare</h3>
                    </div>
                    <div class="col-lg-8">
                        <?php $vehicleLists = wp_query_all_vehicles_array();?>
                        <form method="GET" action="">
                            <div class="row">
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6 ">
                                    <div class="form-group">
                                        <select class="form-control" name="v1">
                                            <?php foreach ($vehicleLists as $vehicle):?>
                                                <option value="<?php echo esc_attr($vehicle->ID)?>"
                                                        <?php if(isset($vehicle1['details']['ID']) && $vehicle->ID == $vehicle1['details']['ID']) {echo esc_attr('selected="selected"');}?>
                                                ><?php echo esc_attr($vehicle->post_title)?></option>
                                            <?php endforeach;;?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6">
                                    <div class="form-group">
                                        <select class="form-control" name="v2">
                                            <?php foreach ($vehicleLists as $vehicle):?>
                                                <option value="<?php echo esc_attr($vehicle->ID)?>"
                                                    <?php if(isset($vehicle2['details']['ID']) &&  $vehicle->ID == $vehicle2['details']['ID']) {echo esc_attr('selected="selected"');}?>
                                                ><?php echo esc_attr($vehicle->post_title)?></option>
                                            <?php endforeach;;?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                    <div class="form-group">
                                        <button class="btn details-button">Start Comparison</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>

    <?php if(isset($vehicles['items'][0]) && isset($vehicles['items'][1])):?>
    <div class="comparison faq content-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                    <div class="compare-media">
                        <?php
                        global $carhouse;
                        $image = array_values(rwmb_meta( 'vehicle_main_image',[], $vehicle1['details']['ID']));
                        $title = the_title('', '', false);

                        $alt = null;
                        if (!$alt && isset($image[0]) && $image[0]['alt'] != '') {
                            $alt = $image[0]['alt'];
                        } elseif (!$alt && isset($image[0]) && $image[0]['title'] != '') {
                            $alt = $image[0]['title'];
                        }elseif (!$alt && isset($image[0]) && $image[0]['caption'] != '') {
                            $alt = $image[0]['caption'];
                        } else {
                            $alt = $title;
                        }

                        if(sizeof($image) > 0){
                            $vehicleImg = $image[0]['url'];
                        } else {
                            $vehicleImg = $carhouse['opt_default_vehicle_image']['url'];
                        }
                        ?>
                        <div class="media">
                            <div class="media-left">
                                <a href="<?php echo esc_url(get_permalink($vehicle1['details']['ID']))?>">
                                    <img class="campare-img" src='<?php echo esc_url($vehicleImg)?>' alt='<?php echo esc_attr($alt);?>'>
                                </a>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading">
                                    <a href="<?php echo esc_url(get_permalink($vehicle1['details']['ID']))?>">
                                        <?php echo wp_html_excerpt($vehicle1['details']['post_title'], 20, '...')?>
                                    </a>
                                    <span class="price"><?php echo esc_attr($carhouse['opt_default_currency']).esc_attr(number_format($vehicle1['details']['vehicle_sale_price'], 2)) ?></span>
                                </h4>
                                <p><?php echo wp_html_excerpt(get_post_meta($vehicle1['details']['ID'], 'vehicle_short_description', true), 250, '...')?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                    <div class="compare-media">
                        <?php
                        global $carhouse;
                        $image = array_values(rwmb_meta( 'vehicle_main_image',[], $vehicle2['details']['ID']));
                        $title = the_title('', '', false);

                        $alt = null;
                        if (!$alt && isset($image[0]) && $image[0]['alt'] != '') {
                            $alt = $image[0]['alt'];
                        } elseif (!$alt && isset($image[0]) && $image[0]['title'] != '') {
                            $alt = $image[0]['title'];
                        }elseif (!$alt && isset($image[0]) && $image[0]['caption'] != '') {
                            $alt = $image[0]['caption'];
                        } else {
                            $alt = $title;
                        }

                        if(sizeof($image) > 0){
                            $vehicleImg = $image[0]['url'];
                        } else {
                            $vehicleImg = $carhouse['opt_default_vehicle_image']['url'];
                        }
                        ?>
                        <div class="media">
                            <div class="media-left">
                                <a href="<?php echo esc_url(get_permalink($vehicle2['details']['ID']))?>">
                                    <img class="campare-img" src='<?php echo esc_url($vehicleImg)?>' alt='<?php echo esc_attr($alt);?>'>
                                </a>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading">
                                    <a href="<?php echo esc_url(get_permalink($vehicle2['details']['ID']))?>">
                                        <?php echo wp_html_excerpt($vehicle2['details']['post_title'], 20, '...')?>
                                    </a>
                                    <span class="price"><?php echo esc_attr($carhouse['opt_default_currency']).esc_attr(number_format($vehicle2['details']['vehicle_sale_price'], 2)) ?></span>
                                </h4>
                                <p><?php echo wp_html_excerpt(get_post_meta($vehicle2['details']['ID'], 'vehicle_short_description', true), 250, '...')?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div id="faq" class="faq-accordion">
                        <div class="card m-b-0">
                            <div class="card-header collapsed" data-toggle="collapse" data-parent="#faq" href="#collapse1" aria-expanded="false">
                                <a class="card-title">
                                    General Information
                                </a>
                            </div>
                            <div id="collapse1" class="card-block">
                                <div class="compare-table">
                                    <table>
                                        <tbody>
                                        <tr>
                                            <td> Price </td>
                                            <td> <?php echo esc_attr($carhouse['opt_default_currency']).esc_attr(number_format($vehicle1['details']['vehicle_sale_price'], 2)) ?></td>
                                            <td> <?php echo esc_attr($carhouse['opt_default_currency']).esc_attr(number_format($vehicle2['details']['vehicle_sale_price'], 2)) ?></td>
                                        </tr>
                                        <tr>
                                            <td> Brand </td>
                                            <td> <?php echo esc_attr(isset($vehicle1['brand']->name) ? $vehicle1['brand']->name : 'N/A');?></td>
                                            <td> <?php echo esc_attr(isset($vehicle2['brand']->name) ? $vehicle2['brand']->name : 'N/A');?></td>
                                        </tr>
                                        <tr>
                                            <td> Fuel </td>
                                            <td> <?php echo esc_attr(isset($vehicle1['fuel']->name) ? $vehicle1['fuel']->name : 'N/A');?></td>
                                            <td> <?php echo esc_attr(isset($vehicle2['fuel']->name) ? $vehicle2['fuel']->name : 'N/A');?></td>
                                        </tr>
                                        <tr>
                                            <td> Transmission </td>
                                            <td> <?php echo esc_attr(isset($vehicle1['transmission']->name) ? $vehicle1['transmission']->name : 'N/A');?></td>
                                            <td> <?php echo esc_attr(isset($vehicle2['transmission']->name) ? $vehicle2['transmission']->name : 'N/A');?></td>
                                        </tr>
                                        <tr>
                                            <td> Category </td>
                                            <td> <?php echo esc_attr(isset($vehicle1['category']->name) ? $vehicle1['category']->name : 'N/A');?></td>
                                            <td> <?php echo esc_attr(isset($vehicle2['category']->name) ? $vehicle2['category']->name : 'N/A');?></td>
                                        </tr>
                                        <tr>
                                            <td> Condition </td>
                                            <td> <?php echo esc_attr(isset($vehicle1['condition']->name) ? $vehicle1['condition']->name : 'N/A');?></td>
                                            <td> <?php echo esc_attr(isset($vehicle2['condition']->name) ? $vehicle2['condition']->name : 'N/A');?></td>
                                        </tr>
                                        <tr>
                                            <td> Manufacture Year </td>
                                            <td> <?php echo esc_attr($vehicle1['details']['vehicle_manufacture_year']);?></td>
                                            <td> <?php echo esc_attr($vehicle2['details']['vehicle_manufacture_year']);?></td>
                                        </tr>
                                        <tr>
                                            <td> Engine </td>
                                            <td> <?php echo esc_attr($vehicle1['details']['vehicle_engine']);?></td>
                                            <td> <?php echo esc_attr($vehicle2['details']['vehicle_engine']);?></td>
                                        </tr>
                                        <tr>
                                            <td> Mileage </td>
                                            <td>
                                                <?php echo esc_attr($vehicle1['details']['vehicle_mileage']). ' ';?>
                                                <?php
                                                if($vehicle1['details']['vehicle_mileage'] != 'N/A') {
                                                    echo esc_attr($carhouse['opt_default_mileage_unit']);
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php echo esc_attr($vehicle2['details']['vehicle_mileage']) . ' ';?>
                                                <?php
                                                if($vehicle2['details']['vehicle_mileage'] != 'N/A') {
                                                    echo esc_attr($carhouse['opt_default_mileage_unit']);
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td> Miles </td>
                                            <td>
                                                <?php echo esc_attr($vehicle1['details']['vehicle_miles']). ' ' ;?>
                                                <?php
                                                if($vehicle1['details']['vehicle_miles'] != 'N/A') {
                                                    echo esc_attr($carhouse['opt_default_mile_unit']);
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php echo esc_attr($vehicle2['details']['vehicle_miles']) . ' ';?>
                                                <?php
                                                if($vehicle2['details']['vehicle_miles'] != 'N/A') {
                                                    echo esc_attr($carhouse['opt_default_mile_unit']);
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td> Horse Power </td>
                                            <td> <?php echo esc_attr($vehicle1['details']['vehicle_horse_power']);?></td>
                                            <td> <?php echo esc_attr($vehicle2['details']['vehicle_horse_power']);?></td>
                                        </tr>
                                        <tr>
                                            <td> Doors </td>
                                            <td> <?php echo esc_attr($vehicle1['details']['vehicle_doors']);?></td>
                                            <td> <?php echo esc_attr($vehicle2['details']['vehicle_doors']);?></td>
                                        </tr>
                                        <tr>
                                            <td> Drive Train </td>
                                            <td> <?php echo esc_attr($vehicle1['details']['vehicle_drive_train']);?></td>
                                            <td> <?php echo esc_attr($vehicle2['details']['vehicle_drive_train']);?></td>
                                        </tr>
                                        <tr>
                                            <td> Interior Color </td>
                                            <td> <?php echo esc_attr($vehicle1['details']['vehicle_interior_color']);?></td>
                                            <td> <?php echo esc_attr($vehicle2['details']['vehicle_interior_color']);?></td>
                                        </tr>
                                        <tr>
                                            <td> Exterior Color </td>
                                            <td> <?php echo esc_attr($vehicle1['details']['vehicle_exterior_color']);?></td>
                                            <td> <?php echo esc_attr($vehicle2['details']['vehicle_exterior_color']);?></td>
                                        </tr>
                                        <tr>
                                            <td> Top Speed </td>
                                            <td>
                                                <?php echo esc_attr($vehicle1['details']['vehicle_top_speed']) . ' ';?>
                                                <?php
                                                if($vehicle1['details']['vehicle_top_speed'] != 'N/A') {
                                                    echo esc_attr($carhouse['opt_default_speed_unit']);
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php echo esc_attr($vehicle2['details']['vehicle_top_speed']) . ' ';?>
                                                <?php
                                                if($vehicle2['details']['vehicle_top_speed'] != 'N/A') {
                                                    echo esc_attr($carhouse['opt_default_speed_unit']);
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td> Odometer </td>
                                            <td>
                                                <?php echo esc_attr($vehicle1['details']['vehicle_odometer']) . ' '?>
                                                <?php
                                                if($vehicle1['details']['vehicle_odometer'] != 'N/A') {
                                                    echo esc_attr($carhouse['opt_default_speed_unit']);
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php echo esc_attr($vehicle2['details']['vehicle_odometer']) . ' ';?>
                                                <?php
                                                if($vehicle2['details']['vehicle_odometer'] != 'N/A') {
                                                    echo esc_attr($carhouse['opt_default_speed_unit']);
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td> Torque </td>
                                            <td> <?php echo esc_attr($vehicle1['details']['vehicle_torque']);?></td>
                                            <td> <?php echo esc_attr($vehicle2['details']['vehicle_torque']);?></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div class="card-header" data-toggle="collapse" data-parent="#faq" href="#collapse3" aria-expanded="false">
                                <a class="card-title">
                                    Extra feature
                                </a>
                            </div>
                            <div id="collapse3" class="card-block collapse">
                                <div class="compare-table">
                                    <?php if(sizeof($vehicles['all_features']) > 0):?>
                                    <table>
                                        <tbody>
                                        <?php foreach ($vehicles['all_features'] as $feature):?>
                                            <tr>
                                                <td> <?php echo esc_attr($feature);?> </td>
                                                <td>
                                                    <?php
                                                    if(in_array($feature, $vehicle1['features'])) {
                                                      echo '<i class="fa fa-check"></i>';
                                                    } else {
                                                        echo '<i class="fa fa-times"></i>';
                                                    }
                                                    ?>
                                                </td>
                                                <td>
                                                    <?php
                                                    if(in_array($feature, $vehicle2['features'])) {
                                                        echo '<i class="fa fa-check"></i>';
                                                    } else {
                                                        echo '<i class="fa fa-times"></i>';
                                                    }
                                                    ?>
                                                </td>
                                            </tr>
                                        <?php endforeach;?>
                                        </tbody>
                                    </table>
                                    <?php else:?>
                                        <h4>No features are available to compare</h4>
                                    <?php endif;?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php else:?>
        <div class="error-404">
            <div>
                <div class="title-error">Comparison is Empty</div>
                <p class="visible-lg visible-md">Please select vehicle to enable the comparison!</p>
            </div>
        </div>
    <div class="clearfix"></div>
    <?php endif;?>
</div>


<?php get_footer();?>