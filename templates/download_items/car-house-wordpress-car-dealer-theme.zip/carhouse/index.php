<?php
/*
Template Name: Home (Home page layout)
*/
?>


<?php
if ( is_home() && 'posts' == get_option( 'show_on_front' ) ) {
    get_home_template();
} else {
    get_template_part('template-parts/front-page-content');
}