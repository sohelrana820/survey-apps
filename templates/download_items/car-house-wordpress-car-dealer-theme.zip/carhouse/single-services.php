<?php
global $carhouse;
// Displaying header
get_header();

// Displaying single page banner
get_template_part('elements/banner-single');
?>

<div class="about-body padd-50">
    <div class="container">
        <?php while ( have_posts() ) : the_post(); ?>
            <div <?php post_class();?>>
                <div class="title title-area">
                    <h2 class="h2-title">
                        <a href="<?php echo esc_url(get_permalink());?>"><?php echo esc_attr(get_the_title());?></a>
                    </h2>
                    <hr/>
                </div>
                <div class="page_dynamic_content">
                    <?php echo the_content(); ?>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<?php get_footer();?>