<?php

/**
 * Class SidebarVehicleSearch
 */
class SidebarVehicleSearch extends WP_Widget
{
    /**
     * SidebarVehicleSearch constructor.
     */
    public function __construct()
    {
        $widget_details = array(
            'classname' => 'sidebar_vehicle_search_widget',
            'description' => __('Sidebar Vehicle Search Widget', 'carhouse')
        );

        parent::__construct('sidebar_vehicle_search_widget', __('Car House: Search Vehicle (Sidebar)', 'carhouse'), $widget_details);
    }


    public function form($instance)
    {

    }

    public function update($new_instance, $old_instance)
    {

    }

    /**
     * @param array $args
     * @param array $instance
     */
    public function widget($args, $instance)
    {
        extract($args);
        echo $before_widget;
        get_template_part('elements/vehicle_search_box');
        echo $after_widget;
    }
}