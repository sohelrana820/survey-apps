=== Car House - Car Dealer WordPress Theme ===
Author: Sohel Rana
Author URI: http://sohelrana.me
Requires at least: WordPress 4.8.X
Tested up to: WordPress 4.9.1
Version: 1.1.0
License: Envato Split License for WP Themes
License URI: http://themeforest.net/licenses
Tags: two-columns, grid-layout, right-sidebar, left-sidebar, custom-menu, featured-images, footer-widgets, theme-options, blog

== Description ==

Car House is a modern and full featured automotive car dealer wordpress theme to acquire your all auto dealer business needs. This theme is suitable for any agency, agent, car, car dealer, car listing, vehicle listing, car dealership, car tread, etc.Our Car Classified Ads theme comes with effective vehicle search functionality that makes it Perfect for buyers to look after various Cars or Vehicle Models available. This theme is available with theme option, several page templates, fonts, custom widgets,shortcodes and much more for your all classifieds business requirement - <a href="http://wp.themevessel.com/car-house">Demo Website</a>

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.1.0 - Dec 13 2017 =
* Initial release

== Credits ==

* Redux Framework (https://wordpress.org/plugins/redux-framework/)
* Meta Box (https://wordpress.org/plugins/meta-box/)
* Advance Custom Field (https://wordpress.org/plugins/advanced-custom-fields/)
* Contact Form 7 (https://wordpress.org/plugins/contact-form-7/)