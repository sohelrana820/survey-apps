<?php
// Displaying header
get_header();

// Displaying single page banner
get_template_part('elements/banner-single');
?>

<div class="container">
    <?php while ( have_posts() ) : the_post(); ?>
        <div <?php post_class();?>>
            <div class="page_dynamic_content page_dynamic_with_height">
                <?php echo the_content(); ?>
            </div>
        </div>
    <?php endwhile; ?>
    <br/>
</div>

<?php get_footer();?>