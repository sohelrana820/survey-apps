<?php
global $carhouse;
// Displaying header

get_header();

$layout = $carhouse['blog_page_layout'];
if(!$layout){
	$layout = 'right_sidebar';
}

$title = $carhouse['blog_page_title'];
if (!$title) {
	$title = 'Blog';
}

$postPerPage = (int) get_option('posts_per_page');
if($postPerPage < 1){
	$postPerPage = 10;
}

$tagSlug = get_query_var('tag');
if(is_tag($tagSlug)) {
	$tagInfo = get_term_by('slug', $tagSlug, 'post_tag');
}
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
?>
	<div class="blog-banner">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<h2><?php echo esc_attr($title); ?></h2>
					<?php
					if($tagInfo) {
						echo 'Tag: <a href="'.get_tag_link($tagInfo->term_id).'">'.$tagInfo->name.'</a>';
					}
					?>
				</div>
			</div>
		</div>
	</div>

	<div class="blog-body">
		<div class="container">
			<div class="row">
				<div class="<?php echo esc_attr($layout == 'full_layout' ? 'col-lg-12 col-md-12 col-xs-12' : 'col-lg-8 col-md-8 col-xs-12');?> <?php echo esc_attr($layout == 'left_sidebar' ? 'col-lg-push-4' : '');?>">
					<?php
					if ( have_posts() ) :
						while ( have_posts() ) : the_post();
							get_template_part('elements/posts-list');
						endwhile;
						?>
						<div class="blog-pagination">
							<?php
							the_posts_pagination( array(
								'mid_size' => 2,
								'prev_text' =>  __('&laquo;', 'carhouse'),
								'next_text' => __('&raquo;', 'carhouse'),
							) );
							?>
						</div>
						<?php
					else :
						get_template_part('elements/empty');
					endif;
					?>
				</div>
				<?php if($layout != 'full_layout'):?>
					<div class="col-lg-4 col-md-4 col-xs-12 <?php echo esc_attr($layout == 'left_sidebar' ? 'col-lg-pull-8' : '');?>">
						<?php get_sidebar('blog')?>
					</div>
				<?php endif;?>
			</div>
		</div>
	</div>

<?php get_footer();?>