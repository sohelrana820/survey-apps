<div class="listing-sidebar">
    <?php
    if(is_active_sidebar('vehicle_listing_widget')){
        dynamic_sidebar('vehicle_listing_widget');
    }
    ?>
</div>