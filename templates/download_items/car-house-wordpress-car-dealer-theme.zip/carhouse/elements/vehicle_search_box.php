<?php
global $carhouse;
$currentPage = home_url(add_query_arg(array(),$wp->request));
$queryParams = $_GET;
$archive = get_post_type_archive_link('vehicles'). '?' .http_build_query($queryParams);
?>

<form role="search" method="get" class="search-form" action="<?php echo esc_attr($archive); ?>">
    <!-- Sidebar start-->
    <aside class="sidebar">
        <div class="section-heading">
            <i class="fa fa-search"></i>
            <h2><?php echo esc_attr($carhouse['opt_default_listing_search_box_title']);?></h2>
            <div class="border"></div>
            <h4><?php echo esc_attr($carhouse['opt_default_listing_search_box_subtitle']); ?></h4>
        </div>

        <?php if(count($queryParams) > 0):?>
            <a class="btn reset-button btn-block" href="<?php echo esc_url($currentPage); ?>"><?php echo esc_attr($carhouse['opt_default_listing_reset_btn_button']);?></a>
        <?php endif;?>


        <div class="search-block">
            <h2 class="title"><?php echo esc_attr($carhouse['opt_default_listing_search_box_criteria']);?></h2>
            <input class="form-control" name="title" placeholder="<?php echo esc_attr($carhouse['opt_default_listing_search_box_vehicle_title'])?>" value="<?php echo isset($queryParams['title']) ? esc_attr($queryParams['title']) : ''?>">
            <?php
            $fuels = get_terms( array('taxonomy' => 'vehicle_fuels', 'hide_empty' => false) );
            if(sizeof($fuels) > 0):?>
                <select class="form-control" name="fuel">
                    <option value=""><?php echo esc_attr($carhouse['opt_default_listing_search_box_choose_fuel']);?></option>
                    <?php foreach ($fuels as $fuel):?>
                        <option value="<?php echo esc_attr($fuel->slug);?>" <?php if(isset($queryParams['fuel']) && $queryParams['fuel'] == $fuel->slug){echo esc_attr__('selected', 'carhouse');}?>><?php echo esc_attr($fuel->name)?></option>
                    <?php endforeach;?>
                </select>
            <?php endif; ?>

            <?php
            $transmissions = get_terms( array('taxonomy' => 'vehicle_transmissions', 'hide_empty' => false) );
            if(sizeof($transmissions) > 0):?>
                <select class="form-control" name="transmission">
                    <option value=""><?php echo esc_attr($carhouse['opt_default_listing_search_box_choose_transmission'])?></option>
                    <?php foreach ($transmissions as $transmission):?>
                        <option value="<?php echo esc_attr($transmission->slug);?>" <?php if(isset($queryParams['transmission']) && $queryParams['transmission'] == $transmission->slug){echo esc_attr__('selected', 'carhouse');}?>><?php echo esc_attr($transmission->name)?></option>
                    <?php endforeach;?>
                </select>
            <?php endif; ?>

            <?php
            $conditions = get_terms( array('taxonomy' => 'vehicle_conditions', 'hide_empty' => false) );
            if(sizeof($conditions) > 0):?>
                <select class="form-control" name="condition">
                    <option value=""><?php echo esc_attr($carhouse['opt_default_listing_search_box_choose_condition']);?></option>
                    <?php foreach ($conditions as $condition):?>
                        <option value="<?php echo esc_attr($condition->slug);?>" <?php if(isset($queryParams['condition']) && $queryParams['condition'] == $condition->slug){echo esc_attr__('selected', 'carhouse');}?>><?php echo esc_attr($condition->name)?></option>
                    <?php endforeach;?>
                </select>
            <?php endif; ?>

            <select class="form-control" name="manufacture_year">
                <option value=""><?php echo esc_attr($carhouse['opt_default_listing_search_box_manufacture_year']);?></option>
                <?php $year = 1980; while($year <= date('Y')):?>
                    <option value="<?php echo esc_attr($year);?>" <?php if(isset($queryParams['manufacture_year']) && $queryParams['manufacture_year'] == $year){echo esc_attr__('selected', 'carhouse');}?>><?php echo esc_attr($year); ?></option>
                    <?php $year++; endwhile;?>
            </select>
        </div>

        <div class="search-block">
            <h2 class="title"><?php echo esc_attr($carhouse['opt_default_listing_search_box_price']);?></h2>
            <div class="row">
                <div class="price-box">
                    <div class="col-lg-6">
                        <label><?php echo esc_attr__('Min price', 'carhouse');?></label>
                        <input class="form-control" name="min_price" placeholder="Min price" id="minPrice" value="<?php echo isset($queryParams['min_price']) ? esc_attr($queryParams['min_price']) : esc_attr__('0', 'carhouse')?>">
                    </div>
                    <div class="col-lg-6">
                        <label><?php  echo esc_attr__('Max price', 'carhouse');?></label>
                        <input class="form-control" name="max_price" placeholder="Min price" id="maxPrice" value="<?php echo isset($queryParams['max_price']) ? esc_attr($queryParams['max_price']) : esc_attr__('50000', 'carhouse')?>">
                    </div>
                </div>
            </div>
        </div>

        <?php
        $selectedBrands = isset($queryParams['brands']) ? $queryParams['brands'] : [];
        $uniqueId = uniqid();
        $brands = get_terms( array('taxonomy' => 'vehicle_brands', 'hide_empty' => false) );
        if(is_array($brands) && sizeof($brands) > 0):
            ?>
            <div class="search-block">
                <h2 class="title"><?php echo esc_attr($carhouse['opt_default_listing_search_box_brand']);?></h2>
                <?php $shown = 0; foreach ($brands as $brand):?>
                    <div class="checkbox checkbox-theme checkbox-circle <?php if($shown > 9) {echo 'brand-checkbox hide';}?>">
                        <input type="checkbox" id="<?php echo esc_attr($uniqueId.'-'.$brand->term_id);?>" name="brands[]" value="<?php echo esc_attr($brand->term_id);?>"
                        <?php
                        foreach ($selectedBrands as $selectedBrand){
                            if($selectedBrand == $brand->term_id) {echo esc_attr__('checked', 'carhouse');}
                        }
                        ?>>
                        <label for="<?php echo esc_attr($uniqueId.'-'.$brand->term_id);?>">
                            <?php echo esc_attr($brand->name); $shown++?>
                        </label>
                    </div>
                <?php endforeach;?>
                <?php if($shown > 10) {echo '<a class="show_brand">More Brands</a> <a class="hide_brand hide">Less Brand</a>';}?>
            </div>
        <?php endif; ?>

        <?php
        $selectedCategories = isset($queryParams['categories']) ? $queryParams['categories'] : [];
        $categories = get_terms( array('taxonomy' => 'vehicle_categories', 'hide_empty' => false) );
        if(sizeof($categories) > 0):
            ?>
            <div class="search-block">
                <h2 class="title"><?php echo esc_attr($carhouse['opt_default_listing_search_box_category']);?></h2>
                <?php foreach ($categories as $category):?>
                    <div class="checkbox checkbox-theme checkbox-circle">
                        <input type="checkbox" id="<?php echo esc_attr($uniqueId.'-'.$category->term_id);?>" name="categories[]" value="<?php echo esc_attr($category->term_id);?>"
                            <?php
                            foreach ($selectedCategories as $selectedCategory){
                                if($selectedCategory == $category->term_id) {echo esc_attr__('checked', 'carhouse');}
                            }
                            ?>>
                        <label for="<?php echo esc_attr($uniqueId.'-'.$category->term_id);?>">
                            <?php echo esc_attr($category->name)?>
                        </label>
                    </div>
                <?php endforeach;?>
            </div>
        <?php endif; ?>

        <button class="btn details-button btn-block"><?php echo esc_attr($carhouse['opt_default_listing_search_btn_text']);?></button>
    </aside>
    <!-- Sidebar end-->
</form>