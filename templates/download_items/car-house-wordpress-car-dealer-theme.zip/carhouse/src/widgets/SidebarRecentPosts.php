<?php

/**
 * Class SidebarRecentPosts
 */
class SidebarRecentPosts extends WP_Widget
{
    /**
     * SidebarRecentPosts constructor.
     */
    public function __construct()
    {
        $widget_details = array(
            'classname' => 'footer_posts_widget',
            'description' => __('Sidebar Recent Posts Widget', 'carhouse')
        );

        parent::__construct('sidebar_recent_posts_widget', __('Car House:  Recent Posts (Sidebar)', 'carhouse'), $widget_details);
    }


    /**
     * @param array $instance
     */
    public function form($instance)
    {
        $title = !empty($instance['title']) ? $instance['title'] : 'Recent Posts';
        $postCount = !empty($instance['post_count']) ? $instance['post_count'] : 5;
        ?>
        <div class="widget_box">
            <div class="widget-field">
                <label><?php echo esc_attr__('Title', 'carhouse'); ?></label>
                <input class="widefat form-control" name="<?php echo $this->get_field_name('title'); ?>"
                       placeholder="<?php echo esc_attr__('Title', 'carhouse'); ?>" value="<?php echo esc_attr($title); ?>"/>
            </div>

            <div class="widget-field">
                <label><?php echo esc_attr__('Number of Post to Show', 'carhouse'); ?></label>
                <input class="widefat form-control" name="<?php echo $this->get_field_name('post_count'); ?>"
                       placeholder="<?php echo esc_attr__('Number of Post to Show', 'carhouse'); ?>"
                       value="<?php echo $postCount; ?>"/>
            </div>
        </div>
        <?php
    }

    /**
     * @param array $new_instance
     * @param array $old_instance
     * @return array
     */
    public function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        $instance['title'] = $new_instance['title'];
        $instance['post_count'] = $new_instance['post_count'];
        return $instance;
    }

    /**
     * @param array $args
     * @param array $instance
     */
    public function widget($args, $instance)
    {
        extract($args);
        $title = $instance['title'];
        $postCount = $instance['post_count'];
        $query = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => $postCount
        );
        $posts = new WP_Query($query);
        global  $carhouse;
        echo $before_widget; ?>

        <div class="">
            <div class="recent-comments">
                <h2 class="title"> <?php echo esc_attr($title); ?></h2>
                <?php while ($posts->have_posts()): $posts->the_post(); ?>
                    <div <?php post_class();?>>
                        <div class="media">
                            <?php
                            $title = the_title('', '', false);
                            ?>
                            <div class="media-left">
                                <a href="#">
                                    <?php
                                    $postThumbnail = get_the_post_thumbnail(null, 'post-thumbnail', array('class' => 'media-object'));
                                    if($postThumbnail) {
                                        echo $postThumbnail;
                                    } else {
                                        echo '<img src="'.$carhouse['opt_default_featured_image']['url'].'" alt="'.$title.'"/>';
                                    }
                                    ?>
                                </a>
                            </div>
                            <div class="media-body">
                                <p>
                                    <a href="<?php echo esc_url(get_permalink());?>"><?php echo esc_attr($title);?></a>
                                </p>
                                <span class="author">By
                                    <?php the_author_posts_link();?>
                            </span>
                            </div>
                        </div>
                    </div>
                <?php endwhile;
                wp_reset_postdata(); ?>
            </div>
        </div>
        <?php echo $after_widget;
    }
}