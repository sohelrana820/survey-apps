<?php
/*
Template Name: Vehicle Listing (listing  page layout)
*/
?>

<?php
// Displaying header
get_header();

// Displaying single page banner
get_template_part('elements/banner-single');
?>

<div class="car-list content-area">
    <?php
    $sidebarPosition = $carhouse['opt_default_listing_sidebar_position'] ? $carhouse['opt_default_listing_sidebar_position'] : 'Right';
    $vehicles = new WP_Query(wp_carhouse_get_vehicles_query_builder($_GET));
    ?>
    <?php if($vehicles->post_count > 0 || sizeof($_GET) > 0):?>
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 <?php if($sidebarPosition == 'Left'){echo esc_attr__('col-lg-push-4 col-md-push-4', 'carhouse');}?>">
                <?php
                $view = strtolower(get_field('listing_view'));
                if(array_key_exists('view', $_GET) && $_GET['view']){
                    $view = $_GET['view'];
                } else if(!$view) {
                    $view = strtolower($carhouse['opt_default_listing_view']);
                }
                ?>
                <?php get_template_part('elements/option-bar')?>

                <div class="row">
                    <?php
                    if($vehicles->post_count > 0) :
                        while($vehicles->have_posts()): $vehicles->the_post();
                        ?>
                            <?php
                            if($view == 'grid'):
                            ?>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <?php get_template_part('elements/listing-grid') ?>
                                </div>
                            <?php else:?>
                                <?php get_template_part('elements/listing-list') ?>
                            <?php endif;?>
                        <?php endwhile;?>
                    <?php else:?>
                        <?php get_template_part('elements/record-not-found') ?>
                    <?php endif;?>
                </div>
                <?php if($vehicles->max_num_pages): ?>
                    <div class="page-count"><?php _e('Showing page','carhouse'); ?> <?php echo esc_attr($paged == 0 ? $paged + 1 : $paged); ?> <?php _e('of','carhouse'); ?> <?php echo esc_attr($vehicles->max_num_pages); ?></div>
                    <?php wp_carhouse_pagination($vehicles->max_num_pages); ?>
                    <br/>
                <?php endif; ?>
            </div>

            <div class="col-lg-4 col-md-4 col-xs-12 <?php if($sidebarPosition == 'Left'){echo esc_attr__('col-lg-pull-8 col-md-pull-8', 'carhouse');}?>">
                <div class="vehicle-sidebar-area">
                    <?php get_sidebar('vehicle'); ?>
                </div>
            </div>
        </div>
    </div>
    <?php else:?>
        <div class="error-404">
            <div class="e404">
                <div class="title-error">Vehicle is Empty</div>
                <p class="visible-lg visible-md">Sorry, No vechile were found.</p>
            </div>
        </div>
        <br/><br/>
        <br/><br/>
    <?php endif;?>
</div>
<?php get_footer();?>