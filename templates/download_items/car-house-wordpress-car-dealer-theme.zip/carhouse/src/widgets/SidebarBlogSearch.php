<?php

/**
 * Class SidebarBlogSearch
 */
class SidebarBlogSearch extends WP_Widget
{

    /**
     * SidebarBlogSearch constructor.
     */
    public function __construct()
    {
        $widget_details = array(
            'classname' => 'footer_blog_widget',
            'description' => __('Sidebar Blog Search Widget', 'carhouse')
        );

        parent::__construct('footer_blog_widget', __('Car House:  Blog Search (Sideabr)', 'carhouse'), $widget_details);
    }

    /**
     * @param array $instance
     */
    public function form($instance)
    {
        $title = !empty($instance['title']) ? $instance['title'] : 'Search';
        $placeholder = !empty($instance['placeholder']) ? $instance['placeholder'] : 'Search...';
        $searchBtnText = !empty($instance['search_btn_text']) ? $instance['search_btn_text'] : 'Search';
        ?>
        <div class="widget_box">
            <div class="widget-field">
                <label><?php echo esc_attr__('Title', 'carhouse'); ?></label>
                <input class="widefat form-control" name="<?php echo $this->get_field_name('title'); ?>"
                       placeholder="<?php echo esc_attr__('Title', 'carhouse'); ?>" value="<?php echo esc_attr($title); ?>"/>
            </div>
            <div class="widget-field">
                <label><?php echo esc_attr__('Placeholder', 'carhouse'); ?></label>
                <input class="widefat form-control" name="<?php echo $this->get_field_name('placeholder'); ?>"
                       placeholder="<?php echo esc_attr__('Placeholder', 'carhouse'); ?>" value="<?php echo $placeholder; ?>"/>
            </div>
            <div class="widget-field">
                <label><?php echo esc_attr__('Search Button Text', 'carhouse'); ?></label>
                <input class="widefat form-control" name="<?php echo $this->get_field_name('search_btn_text'); ?>"
                       placeholder="<?php echo esc_attr__('Search Button Text', 'carhouse'); ?>" value="<?php echo $searchBtnText; ?>"/>
            </div>
        </div>
        <?php
    }

    /**
     * @param array $new_instance
     * @param array $old_instance
     * @return array
     */
    public function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        $instance['title'] = $new_instance['title'];
        $instance['placeholder'] = $new_instance['placeholder'];
        $instance['search_btn_text'] = $new_instance['search_btn_text'];
        return $instance;
    }

    /**
     * @param array $args
     * @param array $instance
     */
    public function widget($args, $instance)
    {
        extract($args);
        $title = $instance['title'];
        $placeholder = $instance['placeholder'];
        $searchBtnText = $instance['search_btn_text'];
        $queryParams = $_GET;
        $searchUrl = get_site_url(). '?' .http_build_query($queryParams);
        ?>
        <div class="car-sidebar-right">
            <div class="mrg-b-30">
                <?php echo esc_attr($title) ? '<h2 class="title">'.$title.'</h2>' : ''?>
                <form class="blog-search-form mrg-b-30" action="<?php echo $searchUrl;?>">
                    <div class="form-group">
                        <input type="text" name="s" class="form-control" placeholder="<?php echo $placeholder;?>">
                        <button class="btn search-details-button"><i class="fa fa-search"></i></button>
                    </div>
                </form>
                <div class="clearfix"></div>
            </div>
        </div>
        <?php echo $after_widget;
    }
}