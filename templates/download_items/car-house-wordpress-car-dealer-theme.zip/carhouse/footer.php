<!-- Footer start-->
<?php global $carhouse;?>

<?php if(is_active_sidebar( 'footer_widget_1' )
|| is_active_sidebar( 'footer_widget_2' )
|| is_active_sidebar( 'footer_widget_3' )
|| is_active_sidebar( 'footer_widget_4' )
|| is_active_sidebar( 'footer_widget_5' )):?>
<footer class="main-footer">
    <div class="container">
        <div class="row">
            <?php if ( is_active_sidebar( 'footer_widget_1' ) ) : ?>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 footer-item">
                <?php dynamic_sidebar( 'footer_widget_1' ); ?>
                </div>
            <?php endif; ?>

            <?php if ( is_active_sidebar( 'footer_widget_2' ) ) : ?>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 footer-item">
                <?php dynamic_sidebar( 'footer_widget_2' ); ?>
                </div>
            <?php endif; ?>

            <?php if ( is_active_sidebar( 'footer_widget_3' ) ) : ?>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 footer-item">
                <?php dynamic_sidebar( 'footer_widget_3' ); ?>
                </div>
            <?php endif; ?>

            <?php if ( is_active_sidebar( 'footer_widget_4' ) ) : ?>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 footer-item">
                <?php dynamic_sidebar( 'footer_widget_4' ); ?>
                </div>
            <?php endif; ?>


            <?php /*if ( is_active_sidebar( 'footer_widget_5' ) ) : */?><!--
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 footer-item">
                <?php /*dynamic_sidebar( 'footer_widget_5' ); */?>
                </div>
            --><?php /*endif; */?>
        </div>
    </div>
</footer>
<!-- Footer end-->
<?php endif;?>

<!-- Sub footer start-->
<div class="sub-footer">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-6">
                <p><?php echo esc_attr($carhouse['opt_footer_copyright_text']);?></p>
            </div>
            <div class="col-md-6 col-sm-6 hidden-xs ">
                <?php
                wp_nav_menu(array(
                    'menu' => 'id',
                    'theme_location' => 'footer-menu',
                    'fallback_cb' => 'wp_carhouse_carhouse_menu_editor'
                ))
                ?>
            </div>
        </div>
    </div>
</div>
<!-- Sub footer end-->
</div>
<?php wp_footer();?>
</body>
</html>