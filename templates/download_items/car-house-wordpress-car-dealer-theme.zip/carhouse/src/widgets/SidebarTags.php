<?php

/**
 * Class SidebarTags
 */
class SidebarTags extends WP_Widget
{

    /**
     * SidebarTags constructor.
     */
    public function __construct()
    {
        $widget_details = array(
            'classname' => 'footer_tag_widget',
            'description' => __('Sidebar Tags Widget', 'carhouse')
        );

        parent::__construct('sidebar_tags_widget', __('Car House: Tags (Sidebar)', 'carhouse'), $widget_details);
    }

    /**
     * @param array $args
     * @param array $instance
     */
    public function widget($args, $instance)
    {
        $current_taxonomy = $this->_get_current_taxonomy($instance);
        if (empty($instance['title'])) {
            $title = $instance['title'];
        } else {
            if ('post_tag' == $current_taxonomy) {
                $title = __('Tags', 'carhouse');
            } else {
                $tax = get_taxonomy($current_taxonomy);
                $title = $tax->labels->name;
            }
        }

        $tag_cloud = wp_tag_cloud(
            array(
                'taxonomy' => $current_taxonomy,
                'echo' => false,
                'number' => $instance['number_of_tag_count']
            )
        );

        if (empty($tag_cloud)) {
            return;
        }
        /** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
        $title = apply_filters('widget_title', $title, $instance, $this->id_base);

        echo $args['before_widget'];
        ?>

        <div class="blog-tags">
            <h2 class="title"><?php echo esc_attr($title);?></h2>
            <?php echo $tag_cloud;?>
        </div>
        <div class="clearfix"></div>
        <?php
        echo $args['after_widget'];
    }


    /**
     * @param array $new_instance
     * @param array $old_instance
     * @return array
     */
    public function update($new_instance, $old_instance)
    {
        $instance = array();
        $instance['title'] = sanitize_text_field(stripslashes($new_instance['title']));
        $instance['taxonomy'] = stripslashes($new_instance['taxonomy']);
        $instance['number_of_tag_count'] = stripslashes($new_instance['number_of_tag_count']);
        return $instance;
    }


    /**
     * @param array $instance
     */
    public function form($instance)
    {
        $current_taxonomy = $this->_get_current_taxonomy($instance);
        $title_id = $this->get_field_id('title');
        $instance['title'] = !empty($instance['title']) ? esc_attr($instance['title']) : 'Tags';
        echo '<div class="widget_box"><div class="widget-field"><label>' . __('Title:', 'carhouse') . '</label>
			<input type="text" class="widefat form-control" placeholder="' . __('Title', 'carhouse') . '" id="' . $title_id . '" name="' . $this->get_field_name('title') . '" value="' . $instance['title'] . '" />
		</div>';

        $taxonomies = get_taxonomies(array('show_tagcloud' => true), 'object');
        $id = $this->get_field_id('taxonomy');
        $name = $this->get_field_name('taxonomy');
        $input = '<input type="hidden" id="' . $id . '" name="' . $name . '" value="%s" />';
        switch (count($taxonomies)) {
            // No tag cloud supporting taxonomies found, display error message
            case 0:
                echo '<p>' . __('The tag cloud will not be displayed since there are no taxonomies that support the tag cloud widget.', 'carhouse') . '</p>';
                printf($input, '');
                break;
            // Just a single tag cloud supporting taxonomy found, no need to display options
            case 1:
                $keys = array_keys($taxonomies);
                $taxonomy = reset($keys);
                printf($input, esc_attr($taxonomy));
                break;
            // More than one tag cloud supporting taxonomy found, display options
            default:
                printf(
                    '<div class="widget-field"><label>%2$s</label>' .
                    '<select class="widefat form-control" name="%3$s">',
                    $id,
                    __('Taxonomy:', 'carhouse'),
                    $name
                );
                foreach ($taxonomies as $taxonomy => $tax) {
                    printf(
                        '<option value="%s"%s>%s</option>',
                        esc_attr($taxonomy),
                        selected($taxonomy, $current_taxonomy, false),
                        $tax->labels->name
                    );
                }
                echo '</select></div>';
        }

        $instance['number_of_tag_count'] = !empty($instance['number_of_tag_count']) ? esc_attr($instance['number_of_tag_count']) : 15;
        echo '<div class="widget-field"><label>' . __('Number of Tag Count:', 'carhouse') . '</label>
			<input type="text" class="widefat form-control" placeholder="' . __('Number of Tag Count', 'carhouse') . '"  name="' . $this->get_field_name('number_of_tag_count') . '" value="' . $instance['number_of_tag_count'] . '" />
		</div></div>';
    }


    /**
     * @param $instance
     * @return string
     */
    public function _get_current_taxonomy($instance)
    {
        if (!empty($instance['taxonomy']) && taxonomy_exists($instance['taxonomy']))
            return $instance['taxonomy'];
        return 'post_tag';
    }
}