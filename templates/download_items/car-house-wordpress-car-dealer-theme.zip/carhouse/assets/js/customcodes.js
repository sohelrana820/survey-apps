(function() {
    tinymce.create('tinymce.plugins.FAQs', {
        init : function(editor, url) {
            editor.addButton( 'FAQs', {
                text: 'WDM Dropdown',
                icon: false,
                class: 'hello bangaldesh',
                type: 'menubutton',
                menu: [
                    {
                        text: 'Sample Item 1',
                        onclick: function() {
                            editor.insertContent('[wdm_shortcode 1]');
                            tinymce.DOM.setStyle(["TB_overlay", "TB_window", "TB_load"], "z-index", "999999")
                        }
                    },
                    {
                        text: 'Sample Item 2',
                        onclick: function() {
                            editor.insertContent('[wdm_shortcode 2]');
                        }
                    }
                ]
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('FAQs', tinymce.plugins.FAQs);
})();