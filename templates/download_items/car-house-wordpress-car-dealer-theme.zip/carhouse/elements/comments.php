<?php
$comments = get_comments( array(
    'post_id'	=> get_the_ID(),
    'status'	=> 'approve'
) );

?>

<div class="comments-box">
    <h2 class="title">
        <?php
        if(count($comments) > 0){
            echo esc_attr(count($comments) . ' Responses');
        } else {
            echo esc_attr__('Comments Section', 'carhouse');
        }
        ?>

    </h2>
    <?php if( isset( $_GET['success'] ) ) { ?>
        <div class="thanks-comments alert alert-success">
            <p>Thanks for your comment!</p>
        </div>
    <?php } ?>
    <?php if ( count($comments) ) : ?>
    <div class="comments-container">
        <ul class="blog-post-comments">
            <?php foreach ( $comments as $comment ) : ?>
            <li>
                <span class="user-image"><i class="fa fa-user"></i></span>
                <span class="user-name">
                    <?php echo esc_attr($comment->comment_author) ?>
                    <br/>
                    <small><i class="fa fa-clock-o"></i>
                    Posted on
                    <time datetime="<?php echo esc_attr($comment->comment_date) ?>" itemprop="datePublished">
                        <?php echo esc_attr(date('d.m.Y', strtotime($comment->comment_date)) ) ?>
                    </time>
                    at <?php echo esc_attr(date('H:i', strtotime($comment->comment_date)) ) ?>
                </small>
                </span>
                <span class="comment">
                    <?php echo esc_attr($comment->comment_content) ?>
                </span>
            </li>
            <?php endforeach ?>
        </ul>
    </div>
    <?php else : ?>
        <p>
            There are no responses to this post, why not be the first?
        </p>
    <?php endif ?>
</div>

<?php if ( comments_open() ) : ?>
    <div class="contact-form">
        <form id="contact_form" action="<?php echo esc_url(site_url('/wp-comments-post.php')) ?>" method="post">
            <div class="row">
                <?php if(!is_user_logged_in()): ?>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="form-group">
                            <input type="text" class="input-text" name="author" id="full-name" placeholder="Your Name">
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="form-group">
                            <input type="text" class="input-text" name="email" id="email" placeholder="Email Address">
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="form-group">
                            <input type="url" class="input-text" name="url" id="url" placeholder="Website URL">
                        </div>
                    </div>
                <?php else: ?>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="form-group">
                            <input type="url" class="input-text" name="url" id="url" placeholder="Website URL">
                        </div>
                    </div>
                <?php endif; ?>

                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="form-group">
                        <textarea id="message" class="input-text" name="comment" placeholder="Write some message..."></textarea>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="form-group send-message">
                        <?php wp_carhouse_comment_form_hidden_fields() ?>
                        <input type="submit" name="sent message" class=" btn btn-message" value="Submit">
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php endif ?>
