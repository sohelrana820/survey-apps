<?php
get_template_part('template-parts/blog-content');