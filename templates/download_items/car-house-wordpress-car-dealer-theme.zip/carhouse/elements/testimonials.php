<?php
$showTestimonial = (int) get_field('how_many_testimonial_will_show');
$testimonials = getVisibleTestimonial(['posts_per_page' => $showTestimonial]);
$countTestimonials = $testimonials->post_count;
?>

<?php if($countTestimonials > 0): ?>
<!-- Testimonials start-->
<div class="testimonials-box">
    <h1>Our Testimonial</h1>
<div class="col-lg-12">
    <div class="row">
        <div id="carouse2-example-generic" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <?php $counter = 0;?>
                <?php while ($countTestimonials > 0): $counter?>
                    <li data-target="#carouse2-example-generic" data-slide-to="<?php echo esc_attr($counter);?>" <?php if($counter == 0){echo esc_attr__('class="active"', 'carhouse');}?>></li>
                    <?php $countTestimonials--; $counter++?>
                <?php endwhile;?>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
                <?php
                $counter = 0;
                while ($testimonials->have_posts()): $testimonials->the_post();
                    ?>
                    <div class="item <?php if($counter == 0){echo esc_attr__('active', 'carhouse');} $counter++?>">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-10 col-lg-offset-1 col-md-12 testimonials-inner">
                                    <div <?php post_class();?>>
                                        <?php
                                        $star = (int) get_post_meta(get_the_ID(), 'testimonial_rating', true);
                                        $unStar = 5 - $star;
                                        ?>
                                        <ul class="star-rating">
                                            <?php while ($star > 0): ?>
                                                <li>
                                                    <i class="fa fa-star orange-color"></i>
                                                </li>
                                                <?php $star--; endwhile; ?>
                                            <?php while ($unStar > 0): ?>
                                                <li>
                                                    <i class="fa fa-star"></i>
                                                </li>
                                                <?php $unStar--; endwhile; ?>
                                        </ul>
                                        <div class="line-dec"></div>
                                        <p>
                                            <?php the_content();?>
                                        </p>
                                        <div class="author-rate">
                                            <?php
                                            $clientImage = array_values(rwmb_meta( 'testimonial_image',[], get_the_ID()));
                                            $clientName = the_title('"', '"', false);
                                            if(sizeof($clientImage) > 0){
                                                $clientImg = $clientImage[0]['url'];
                                            } else {
                                                global $carhouse;
                                                $clientImg = $carhouse['opt_default_profile_image']['url'];
                                            }
                                            ?>
                                            <img src='<?php echo esc_url($clientImg)?>' alt='<?php echo esc_attr($clientName)?>'>
                                            <h4><?php echo esc_attr($clientName);?></h4>
                                            <div class="line-dec2"></div>
                                            <span><?php echo esc_attr(get_post_meta(get_the_ID(), 'client_type', true))?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile;?>
            </div>
            <?php if($testimonials->post_count > 1):?>
                <!-- Controls -->
                <a class="left carousel-control" href="#carouse2-example-generic" role="button" data-slide="prev">
          <span class="slider-mover-left" aria-hidden="true">
             <img src="<?php echo get_template_directory_uri()?>/assets/img/png/left-chevron.png" alt="left-chevron">
          </span>
                    <span class="sr-only"><?php echo esc_attr__('Previous', 'carhouse');?></span>
                </a>
                <a class="right carousel-control" href="#carouse2-example-generic" role="button" data-slide="next">
            <span class="slider-mover-right" aria-hidden="true">
                <img src="<?php echo get_template_directory_uri()?>/assets/img/png/right-chevron.png" alt="right-chevron">
            </span>
                    <span class="sr-only"><?php echo esc_attr__('Next', 'carhouse');?></span>
                </a>
            <?php endif;?>
        </div>
    </div>
</div>
<div class="clearfix"></div>
</div>
<!-- Testimonials end-->
<?php endif;?>