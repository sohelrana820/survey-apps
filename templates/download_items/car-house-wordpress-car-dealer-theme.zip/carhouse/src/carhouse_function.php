<?php

$carhouseOption = get_option('carhouse');
get_template_part('src/wp-bootstrap-navwalker');
get_template_part('src/widgets/widget');


/**
 * @param $queryParams
 * @return array
 */
function wp_carhouse_get_vehicles_query_builder($queryParams)
{
    global $carhouse;
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    $vehiclePerPage = (int) get_field('vehicle_per_page', false, true);
    if($vehiclePerPage < 1){
        $vehiclePerPage = (int)$carhouse['opt_vehicle_per_page_in_listing_page'];
    }

    $queries = array(
        'post_type' => 'vehicles',
        'posts_per_page' => $vehiclePerPage,
        'paged' => $paged,
    );

    // Default meta_query array
    $metaQueries = array();

    // Default tax_query array
    $taxQueries = array();

    // Adding an array as first index of $metaQueries array
    $metaQueries[] = array(
        'key' => 'vehicle_status',
        'value' => 'active',
        'compare' => '=',
    );
    $metaQueries[] = array(
        'key' => 'vehicle_expiry',
        'value' => date("Y-m-d"),
        'compare' => '>=',
        'type' => 'DATE'
    );

    if (array_key_exists('title', $queryParams) && $queryParams['title']) {

    }

    if (array_key_exists('min_price', $queryParams) && $queryParams['min_price']) {
        $metaQueries[] = array(
            'key' => 'vehicle_sale_price',
            'value' => (int)$queryParams['min_price'],
            'compare' => '>',
            'type' => 'numeric',
        );
    }

    if (array_key_exists('max_price', $queryParams) && $queryParams['max_price']) {
        $metaQueries[] = array(
            'key' => 'vehicle_sale_price',
            'value' => (int)$queryParams['max_price'],
            'compare' => '<',
            'type' => 'numeric',
        );
    }

    if (array_key_exists('manufacture_year', $queryParams) && $queryParams['manufacture_year']) {
        $metaQueries[] = array(
            'key' => 'vehicle_manufacture_year',
            'value' => $queryParams['manufacture_year'],
            'compare' => '=',
            'type' => 'numeric',
        );
    }

    if (array_key_exists('brands', $queryParams) && $queryParams['brands']) {
        $brands = $queryParams['brands'];
        $taxQueries[] = array(
            'taxonomy' => 'vehicle_brands',
            'field' => 'term_id',
            'terms' => $brands,
            'operator' => 'IN',
        );
    }

    if (array_key_exists('categories', $queryParams) && $queryParams['categories']) {
        $taxQueries[] = array(
            'taxonomy' => 'vehicle_categories',
            'field' => 'term_id',
            'terms' => $queryParams['categories'],
            'operator' => 'IN',
        );
    }

    if (array_key_exists('features', $queryParams) && $queryParams['features']) {
        $taxQueries[] = array(
            'taxonomy' => 'vehicle_features',
            'field' => 'term_id',
            'terms' => $queryParams['features'],
            'operator' => 'IN',
        );
    }

    if (array_key_exists('transmission', $queryParams) && $queryParams['transmission']) {
        $taxQueries[] = array(
            'taxonomy' => 'vehicle_transmissions',
            'field' => 'slug',
            'terms' => $queryParams['transmission'],
        );
    }

    if (array_key_exists('fuel', $queryParams) && $queryParams['fuel']) {
        $taxQueries[] = array(
            'taxonomy' => 'vehicle_fuels',
            'field' => 'slug',
            'terms' => $queryParams['fuel'],
        );
    }

    if (array_key_exists('condition', $queryParams) && $queryParams['condition']) {
        $taxQueries[] = array(
            'taxonomy' => 'vehicle_conditions',
            'field' => 'slug',
            'terms' => $queryParams['condition'],
        );
    }

    if (array_key_exists('sort', $queryParams) && $queryParams['sort']) {
        if ($queryParams['sort'] == 'price') {
            $queries['meta_key'] = 'vehicle_sale_price';
            $queries['orderby'] = 'meta_value';
        }
    }

    if (array_key_exists('order', $queryParams) && $queryParams['order']) {
        if ($queryParams['order'] == 'asc') {
            $queries['order'] = 'ASC';
        }
    }

    if (array_key_exists('title', $queryParams) && $queryParams['title']) {
        $queries['s'] = $queryParams['title'];
    }

    $queries['meta_query'] = $metaQueries;
    $queries['tax_query'] = $taxQueries;
    return $queries;
}

/**
 * Template Page's Custom Fields [Vehicles, Teams, Testimonials, Services]
 */
if (function_exists("register_field_group")) {

    register_field_group(array(
        'id' => 'index_page_general',
        'title' => 'General Section',
        'fields' => array(
            array(
                'key' => 'field9das4dwdsddwddasdfds30ec139aae',
                'label' => 'Title',
                'name' => 'index_listing_title',
                'type' => 'text',
                'default_value' => $carhouseOption['opt_default_listing_title'],
                'placeholder' => 'Title',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            ),
            array(
                'key' => 'field94dwdsddsadwddasdfds30ec139aae',
                'label' => 'Title',
                'name' => 'index_listing_subtitle',
                'type' => 'text',
                'default_value' => $carhouseOption['opt_default_listing_subtitle'],
                'placeholder' => 'Title',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            ),
            array(
                'key' => 'field_59dsadsa418674ae692',
                'label' => 'Number of Vehicle',
                'name' => 'index_number_of_vehicle',
                'type' => 'select',
                'choices' => array(
                    '3' => '3',
                    '6' => '6',
                    '9' => '9',
                    '12' => '12',
                    '15' => '15'
                ),
                'default_value' => $carhouseOption['opt_vehicle_per_page_in_home_page'],
                'allow_null' => 0,
                'multiple' => 0,
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'page_template',
                    'operator' => '==',
                    'value' => 'index.php',
                    'order_no' => 0,
                    'group_no' => 0,
                ),
            ),
        ),
        'options' => array(
            'position' => 'normal',
            'layout' => 'default',
            'hide_on_screen' => array(),
        ),
        'menu_order' => 1,
    ));

    register_field_group(array(
        'id' => 'index_page_banners',
        'title' => 'Banner Section',
        'fields' => array(
            array(
                'key' => 'field_dsefdsaadasdada39aad',
                'label' => 'Banner Image',
                'name' => 'inner_page_banner_image',
                'type' => 'image',
                'save_format' => 'object',
                'preview_size' => 'full',
                'library' => 'all',
                'default_value' => isset($carhouseOption['opt_default_single_banner_image']['id']) ? $carhouseOption['opt_default_single_banner_image']['id'] : null,
            ),
            array(
                'key' => 'field94dwdsddwddasdfds30ec139aae',
                'label' => 'Title',
                'name' => 'inner_page_banner_title',
                'type' => 'text',
                'default_value' => $carhouseOption['opt_default_banner_title'],
                'placeholder' => 'Title',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            ),
            array(
                'key' => 'field_3ffdsfds0ede39aaf',
                'label' => 'Subtitle',
                'name' => 'inner_page_banner_subtitle',
                'type' => 'text',
                'default_value' => $carhouseOption['opt_default_banner_subtitle'],
                'placeholder' => 'Subtitle',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'page_template',
                    'operator' => '==',
                    'value' => 'index.php',
                    'order_no' => 0,
                    'group_no' => 0,
                ),
            ),
        ),
        'options' => array(
            'position' => 'normal',
            'layout' => 'default',
            'hide_on_screen' => array(),
        ),
        'menu_order' => 2,
    ));

    register_field_group(array(
        'id' => 'home-page-testimonial',
        'title' => 'Testimonial Section',
        'fields' => array(
            array(
                'key' => 'field_59418674ae692',
                'label' => 'Enabled/Disable Testimonial Section?',
                'name' => 'enabled_disable_testimonial_section',
                'type' => 'select',
                'choices' => array(
                    'Yes' => 'Yes',
                    'No' => 'No',
                ),
                'default_value' => 'Yes',
                'allow_null' => 0,
                'multiple' => 0,
            ),
            array(
                'key' => 'field_594186a5ae693',
                'label' => 'How Many Testimonial will Show?',
                'name' => 'how_many_testimonial_will_show',
                'type' => 'number',
                'default_value' => 5,
                'placeholder' => '',
                'prepend' => '',
                'append' => '',
                'min' => '',
                'max' => '',
                'step' => '',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'page_template',
                    'operator' => '==',
                    'value' => 'index.php',
                    'order_no' => 0,
                    'group_no' => 0,
                ),
            ),
        ),
        'options' => array(
            'position' => 'normal',
            'layout' => 'default',
            'hide_on_screen' => array(),
        ),
        'menu_order' => 3,
    ));

    register_field_group(array(
        'id' => 'listing_page_banners',
        'title' => 'Banner Section',
        'fields' => array(
            array(
                'key' => 'field_59430eaa39aad',
                'label' => 'Banner Image',
                'name' => 'inner_page_banner_image',
                'type' => 'image',
                'save_format' => 'object',
                'preview_size' => 'full',
                'library' => 'all',
                'default_value' => isset($carhouseOption['opt_default_single_banner_image']['id']) ? $carhouseOption['opt_default_single_banner_image']['id'] : null,
            ),
            array(
                'key' => 'field_59430ec139aae',
                'label' => 'Title',
                'name' => 'inner_page_banner_title',
                'type' => 'text',
                'default_value' => $carhouseOption['opt_default_banner_title'],
                'placeholder' => 'Title',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            ),
            array(
                'key' => 'field_59430ede39aaf',
                'label' => 'Subtitle',
                'name' => 'inner_page_banner_subtitle',
                'type' => 'text',
                'default_value' => $carhouseOption['opt_default_banner_subtitle'],
                'placeholder' => 'Subtitle',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            ),
            array(
                'key' => 'field_59418674ase692',
                'label' => 'Listing View',
                'name' => 'listing_view',
                'type' => 'select',
                'choices' => array(
                    'Grid' => 'Grid',
                    'List' => 'List',
                ),
                'default_value' => $carhouseOption['opt_default_listing_view'],
                'allow_null' => 0,
                'multiple' => 0,
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'page_template',
                    'operator' => '==',
                    'value' => 'vehicles.php',
                    'order_no' => 0,
                    'group_no' => 0,
                ),
            ),
        ),
        'options' => array(
            'position' => 'normal',
            'layout' => 'default',
            'hide_on_screen' => array(),
        ),
        'menu_order' => 2,
    ));

    register_field_group(array(
        'id' => 'teams_page_general',
        'title' => 'General Section',
        'fields' => array(
            array(
                'key' => 'field_59430edgde39aaf',
                'label' => 'Title Text',
                'name' => 'team_member_title_text',
                'type' => 'text',
                'default_value' => 'MEET THE TEAM',
                'placeholder' => 'Title Text',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            ),
            array(
                'key' => 'field_59gf418674ae692',
                'label' => 'Member Per Page',
                'name' => 'member_per_page',
                'type' => 'select',
                'choices' => array(
                    '4' => '4',
                    '8' => '8',
                    '12' => '12',
                    '16' => '16',
                    '20' => '20',
                ),
                'default_value' => '4',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'page_template',
                    'operator' => '==',
                    'value' => 'teams.php',
                    'order_no' => 0,
                    'group_no' => 0,
                ),
            ),
        ),
        'options' => array(
            'position' => 'normal',
            'layout' => 'default',
            'hide_on_screen' => array(),
        ),
        'menu_order' => 1,
    ));

    register_field_group(array(
        'id' => 'teams_page_banners',
        'title' => 'Banner Section',
        'fields' => array(
            array(
                'key' => 'field_59430efdsaa39aad',
                'label' => 'Banner Image',
                'name' => 'inner_page_banner_image',
                'type' => 'image',
                'save_format' => 'object',
                'preview_size' => 'full',
                'library' => 'all',
                'default_value' => isset($carhouseOption['opt_default_single_banner_image']['id']) ? $carhouseOption['opt_default_single_banner_image']['id'] : null,
            ),
            array(
                'key' => 'field_594fds30ec139aae',
                'label' => 'Title',
                'name' => 'inner_page_banner_title',
                'type' => 'text',
                'default_value' => $carhouseOption['opt_default_banner_title'],
                'placeholder' => 'Title',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            ),
            array(
                'key' => 'field_5943fds0ede39aaf',
                'label' => 'Subtitle',
                'name' => 'inner_page_banner_subtitle',
                'type' => 'text',
                'default_value' => $carhouseOption['opt_default_banner_subtitle'],
                'placeholder' => 'Subtitle',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'page_template',
                    'operator' => '==',
                    'value' => 'teams.php',
                    'order_no' => 0,
                    'group_no' => 0,
                ),
            ),
        ),
        'options' => array(
            'position' => 'normal',
            'layout' => 'default',
            'hide_on_screen' => array(),
        ),
        'menu_order' => 2,
    ));

    register_field_group(array(
        'id' => 'services_page_general',
        'title' => 'General Section',
        'fields' => array(
            array(
                'key' => 'field_5das9430edsdgde39aaf',
                'label' => 'Title Text',
                'name' => 'service_title_text',
                'type' => 'text',
                'default_value' => 'Our Services',
                'placeholder' => 'Title Text',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            )
        ),
        'location' => array(
            array(
                array(
                    'param' => 'page_template',
                    'operator' => '==',
                    'value' => 'services.php',
                    'order_no' => 0,
                    'group_no' => 0,
                ),
            ),
        ),
        'options' => array(
            'position' => 'normal',
            'layout' => 'default',
            'hide_on_screen' => array(),
        ),
        'menu_order' => 1,
    ));

    register_field_group(array(
        'id' => 'services_page_banners',
        'title' => 'Banner Section',
        'fields' => array(
            array(
                'key' => 'field_594dsefdsaa39aad',
                'label' => 'Banner Image',
                'name' => 'inner_page_banner_image',
                'type' => 'image',
                'save_format' => 'object',
                'preview_size' => 'full',
                'library' => 'all',
                'default_value' => isset($carhouseOption['opt_default_single_banner_image']['id']) ? $carhouseOption['opt_default_single_banner_image']['id'] : null,
            ),
            array(
                'key' => 'field_594dwdwdfds30ec139aae',
                'label' => 'Title',
                'name' => 'inner_page_banner_title',
                'type' => 'text',
                'default_value' => $carhouseOption['opt_default_banner_title'],
                'placeholder' => 'Title',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            ),
            array(
                'key' => 'field_3fds0ede39aaf',
                'label' => 'Subtitle',
                'name' => 'inner_page_banner_subtitle',
                'type' => 'text',
                'default_value' => $carhouseOption['opt_default_banner_subtitle'],
                'placeholder' => 'Subtitle',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'page_template',
                    'operator' => '==',
                    'value' => 'services.php',
                    'order_no' => 0,
                    'group_no' => 0,
                ),
            ),
        ),
        'options' => array(
            'position' => 'normal',
            'layout' => 'default',
            'hide_on_screen' => array(),
        ),
        'menu_order' => 2,
    ));

    register_field_group(array(
        'id' => 'blank_page_banners',
        'title' => 'Banner Section',
        'fields' => array(
            array(
                'key' => 'field_dsefdsaa39aad',
                'label' => 'Banner Image',
                'name' => 'inner_page_banner_image',
                'type' => 'image',
                'save_format' => 'object',
                'preview_size' => 'full',
                'library' => 'all',
                'default_value' => isset($carhouseOption['opt_default_single_banner_image']['id']) ? $carhouseOption['opt_default_single_banner_image']['id'] : null,
            ),
            array(
                'key' => 'field94dwdsddwdfds30ec139aae',
                'label' => 'Title',
                'name' => 'inner_page_banner_title',
                'type' => 'text',
                'default_value' => $carhouseOption['opt_default_banner_title'],
                'placeholder' => 'Title',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            ),
            array(
                'key' => 'field_3ffdsfds0ede39aaf',
                'label' => 'Subtitle',
                'name' => 'inner_page_banner_subtitle',
                'type' => 'text',
                'default_value' => $carhouseOption['opt_default_banner_subtitle'],
                'placeholder' => 'Subtitle',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'page_template',
                    'operator' => '==',
                    'value' => 'blank.php',
                    'order_no' => 0,
                    'group_no' => 0,
                ),
            ),
        ),
        'options' => array(
            'position' => 'normal',
            'layout' => 'default',
            'hide_on_screen' => array(),
        ),
        'menu_order' => 2,
    ));

    register_field_group(array(
        'id' => 'faqs_page_general',
        'title' => 'General Section',
        'fields' => array(
            array(
                'key' => 'field_5das9430edgde39aaf',
                'label' => 'Title Text',
                'name' => 'faqs_title_text',
                'type' => 'text',
                'default_value' => 'FAQs',
                'placeholder' => 'Title Text',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            )
        ),
        'location' => array(
            array(
                array(
                    'param' => 'page_template',
                    'operator' => '==',
                    'value' => 'faqs.php',
                    'order_no' => 0,
                    'group_no' => 0,
                ),
            ),
        ),
        'options' => array(
            'position' => 'normal',
            'layout' => 'default',
            'hide_on_screen' => array(),
        ),
        'menu_order' => 1,
    ));

    register_field_group(array(
        'id' => 'faqs_page_banners',
        'title' => 'Banner Section',
        'fields' => array(
            array(
                'key' => 'field_594dsefdfsdsaa39aad',
                'label' => 'Banner Image',
                'name' => 'inner_page_banner_image',
                'type' => 'image',
                'save_format' => 'object',
                'preview_size' => 'full',
                'library' => 'all',
                'default_value' => isset($carhouseOption['opt_default_single_banner_image']['id']) ? $carhouseOption['opt_default_single_banner_image']['id'] : null,
            ),
            array(
                'key' => 'field_594dfdswdwdfds30ec139aae',
                'label' => 'Title',
                'name' => 'inner_page_banner_title',
                'type' => 'text',
                'default_value' => $carhouseOption['opt_default_banner_title'],
                'placeholder' => 'Title',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            ),
            array(
                'key' => 'field_3fds0ede39fdsfaaf',
                'label' => 'Subtitle',
                'name' => 'inner_page_banner_subtitle',
                'type' => 'text',
                'default_value' => $carhouseOption['opt_default_banner_subtitle'],
                'placeholder' => 'Subtitle',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'page_template',
                    'operator' => '==',
                    'value' => 'faqs.php',
                    'order_no' => 0,
                    'group_no' => 0,
                ),
            ),
        ),
        'options' => array(
            'position' => 'normal',
            'layout' => 'default',
            'hide_on_screen' => array(),
        ),
        'menu_order' => 2,
    ));


    register_field_group(array(
        'id' => 'compare_page_general',
        'title' => 'General Section',
        'fields' => array(
            array(
                'key' => 'field_5das943dasa0edgde39aaf',
                'label' => 'Title Text',
                'name' => 'compare_title_text',
                'type' => 'text',
                'default_value' => 'Compare Vehicles',
                'placeholder' => 'Title Text',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            )
        ),
        'location' => array(
            array(
                array(
                    'param' => 'page_template',
                    'operator' => '==',
                    'value' => 'compare.php',
                    'order_no' => 0,
                    'group_no' => 0,
                ),
            ),
        ),
        'options' => array(
            'position' => 'normal',
            'layout' => 'default',
            'hide_on_screen' => array(),
        ),
        'menu_order' => 1,
    ));

    register_field_group(array(
        'id' => 'compare_page_banners',
        'title' => 'Banner Section',
        'fields' => array(
            array(
                'key' => 'field_594dsefdfsddsdsaa39aad',
                'label' => 'Banner Image',
                'name' => 'inner_page_banner_image',
                'type' => 'image',
                'save_format' => 'object',
                'preview_size' => 'full',
                'library' => 'all',
                'default_value' => isset($carhouseOption['opt_default_single_banner_image']['id']) ? $carhouseOption['opt_default_single_banner_image']['id'] : null,
            ),
            array(
                'key' => 'field_594dfdswdwdfds30ec139aae',
                'label' => 'Title',
                'name' => 'inner_page_banner_title',
                'type' => 'text',
                'default_value' => $carhouseOption['opt_default_banner_title'],
                'placeholder' => 'Title',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            ),
            array(
                'key' => 'field_3fds0edefdsf39fdsfaaf',
                'label' => 'Subtitle',
                'name' => 'inner_page_banner_subtitle',
                'type' => 'text',
                'default_value' => $carhouseOption['opt_default_banner_subtitle'],
                'placeholder' => 'Subtitle',
                'prepend' => '',
                'append' => '',
                'formatting' => 'html',
                'maxlength' => '',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'page_template',
                    'operator' => '==',
                    'value' => 'compare.php',
                    'order_no' => 0,
                    'group_no' => 0,
                ),
            ),
        ),
        'options' => array(
            'position' => 'normal',
            'layout' => 'default',
            'hide_on_screen' => array(),
        ),
        'menu_order' => 2,
    ));

    if(function_exists("register_field_group"))
    {
        register_field_group(array (
            'id' => 'vehicle_brands_image',
            'title' => 'Brand Image',
            'fields' => array (
                array (
                    'key' => 'field_5aa709f309bae',
                    'label' => 'Brand',
                    'name' => 'vehicle_brands_image',
                    'type' => 'image',
                    'save_format' => 'object',
                    'preview_size' => 'thumbnail',
                    'library' => 'all',
                ),
            ),
            'location' => array (
                array (
                    array (
                        'param' => 'ef_taxonomy',
                        'operator' => '==',
                        'value' => 'vehicle_brands',
                        'order_no' => 0,
                        'group_no' => 0,
                    ),
                ),
            ),
            'options' => array (
                'position' => 'normal',
                'layout' => 'no_box',
                'hide_on_screen' => array (
                ),
            ),
            'menu_order' => 0,
        ));
    }
}