$(function () {
    'use strict'

    $('.page_loader').css('background', 'url(' + wp_localize.loader_icon + ') center no-repeat #fff');

    // Showing page loader
    $(window).load(function () {
        setTimeout(function () {
            $(".page_loader").fadeOut("fast");
            $('html').css('margin-right', '100');
            var docHeight = $(document).height();
            var winHeight = $(window).height();
            if(docHeight > winHeight) {
                $('html').css('position', 'relative');
            }
        }, 1500)
    });


    var val =  $('.price-slider').slider('getValue');
    $('.price-slider').on('slide', function (ev) {
        $('#minPrice').val(ev.value[0]);
        $('#maxPrice').val(ev.value[1]);
    });


    var videoWidth = $('iframe').width();
    var videoHeight = videoWidth * .61;
    $('iframe').css('height', videoHeight);

    var carBoxHeight = $('.car-pic-m').width();
    $('.car-pic-m img').css('width', carBoxHeight);
    $('.car-pic-m img').css('height', carBoxHeight);


    manageComparison();

    function manageComparison() {
        var selectedCompareVehicles = getCompareArray();
        $( ".single-car-box" ).each(function( index ) {
            var currentVehicleId = jQuery(this).find('.add_compare').data( 'id' );
            if (jQuery.inArray(currentVehicleId, selectedCompareVehicles)!='-1') {
                jQuery(this).find('.add_compare').removeClass('show_it');
                jQuery(this).find('.add_compare').addClass('hide_it');

                jQuery(this).find('.remove_compare').addClass('show_it');
                jQuery(this).find('.remove_compare').removeClass('hide_it');

                jQuery(this).find('.compare-btns').removeClass('hide_it');
                jQuery(this).find('.compare-btns').addClass('show_it');
            } else {
                jQuery(this).find('.add_compare').removeClass('hide_it');
                jQuery(this).find('.add_compare').addClass('show_it');

                jQuery(this).find('.remove_compare').removeClass('show_it');
                jQuery(this).find('.remove_compare').addClass('hide_it');

                jQuery(this).find('.compare-btns').removeClass('show_it');
                jQuery(this).find('.compare-btns').addClass('hide_it');
            }
        });
    }

    jQuery(document).on('click', '.add_compare', function(e) {
        e.preventDefault();
        var vehicleId = jQuery(this).data( 'id' );
        addCompareItem(vehicleId);
        manageComparison();
        var vehicles = getCompareArray();
        if(vehicles.length > 1) {
            var queryString = '?';
            $.each(vehicles, function (index, value) {
                var incIndex = index+1;
                queryString += 'v' + (incIndex) + '=' + value + '&'
            });
            var compareUrl = wp_localize.compare_page + queryString;
            compareUrl = compareUrl.slice(0, -1);
            cleanCompareItem();
            window.location.href = compareUrl;
        }
    });

    jQuery(document).on('click', '.remove_compare', function(e) {
        e.preventDefault();
        var vehicleId = jQuery(this).data( 'id' );
        removeVehicleId(vehicleId);
        manageComparison();
    });

    function getCompareArray() {
        var vehicleIds = JSON.parse(localStorage.getItem('compare_vehicles'));
        if(!jQuery.isArray(vehicleIds) || vehicleIds == null) {
            return [];
        }

        return vehicleIds;
    }

    Array.prototype.remove = function() {
        var what, a = arguments, L = a.length, ax;
        while (L && this.length) {
            what = a[--L];
            while ((ax = this.indexOf(what)) !== -1) {
                this.splice(ax, 1);
            }
        }
        return this;
    };

    function removeVehicleId(vehicleId) {
        var vehicleIds = getCompareArray();
        vehicleIds = vehicleIds.remove(vehicleId);
        localStorage.setItem('compare_vehicles', JSON.stringify(vehicleIds));
    }

    function cleanCompareItem(vehicleId) {
        localStorage.setItem('compare_vehicles', null);
    }

    function addCompareItem(vehicleId) {
        var vehicleIds = getCompareArray();
        if (jQuery.inArray(vehicleId, vehicleIds)!='-1') {

        } else {
            vehicleIds.push(vehicleId);
            localStorage.setItem('compare_vehicles', JSON.stringify(vehicleIds));
        }
    }

    var wrapperHeight = $('#wrapper').height();
    var docHeight = $(window).height();
    if(wrapperHeight < docHeight) {
        $('.sub-footer').addClass('abs-footer');
    }
    
    $('.show_brand').click(function () {
        $(this).addClass('hide');
        $('.hide_brand').removeClass('hide');

        $('.brand-checkbox').removeClass('hide');
        $('.brand-checkbox').addClass('show');
    })

    $('.hide_brand').click(function () {
        $(this).addClass('hide');
        $('.show_brand').removeClass('hide');

        $('.brand-checkbox').removeClass('show');
        $('.brand-checkbox').addClass('hide');
    })

    $('p:empty').remove();
});


