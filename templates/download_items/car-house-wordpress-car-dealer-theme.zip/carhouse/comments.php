<?php
if( !function_exists('carhouse_comment') ){
	function carhouse_comment($comment, $args, $depth) {
		$GLOBALS['comment'] = $comment; ?>
		<div class="single-comment" id="comment-<?php comment_ID(); ?>" <?php comment_class('media'); ?>>
			<div class="author pull-left">
				<?php echo get_avatar($comment, $size = '70'); ?>
			</div>
			<div class="media-body">
				<div class="media">
					<div class="media-heading clearfix">
						<div class="author-name custom-font pull-left">
							<span><?php echo esc_url(comment_author_link(get_comment_ID()))?></span>
						</div>
						<div class="time pull-right blog-posted">
							<?php edit_comment_link(__('(Edit)', 'carhouse'), '', ''); ?>
							<span>
								<i class="fa fa-clock-o"></i>
								<time datetime="<?php echo esc_attr(comment_date('c')); ?>"><?php printf(__('%1$s', 'carhouse'), get_comment_date(),  get_comment_time()); ?></time>
							</span>
						</div>
					</div>
					<?php if ($comment->comment_approved == '0') : ?>
						<div class="awaiting row-fluid">
							<i><?php esc_html_e('Your comment is awaiting moderation.', 'carhouse'); ?></i>
						</div>
					<?php endif; ?>
					<div class="media-content row-fluid">
						<?php comment_text(); ?>
						<div class="comment-icons">
							<?php comment_reply_link(array_merge($args, array('reply_text' => '<i class="fa fa-reply"></i> Reply', 'depth' => $depth, 'max_depth' => $args['max_depth']))); ?>
							<!--<a><i class="fa fa-share-alt"></i></a>-->
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php } } ?>

<?php if( isset( $_GET['success'] ) ) { ?>
	<div class="thanks-comments alert alert-success">
		<p>Thanks for your comment!</p>
	</div>
<?php } ?>
<?php if (have_comments()) : ?>
	<div class="comments-box">
		<h2 class="title">
			<?php
			if(get_post()->comment_count > 0){
				echo esc_attr(get_post()->comment_count . ' Responses');
			} else {
				echo esc_attr__('Comments Section', 'carhouse');
			}
			?>

		</h2>
		<?php if (post_password_required()) : ?>
			<div class="alert alert-warning alert-dismissible" role="alert">
				<a class="close" data-dismiss="alert">&times;</a>
				<p><?php esc_html_e('This post is password protected. Enter the password to view comments.', 'carhouse'); ?></p>
			</div>
		<?php else:  ?>

			<div class="commentlist">
				<div class="entry-summary">
					<?php wp_list_comments(array('callback' => 'carhouse_comment')); ?>
				</div>
			</div>

			<?php if (get_comment_pages_count() > 1 && get_option('page_comments')) : // are there comments to navigate through ?>
				<nav id="comments-nav" class="pager">
					<ul class="pager">
						<?php if (get_previous_comments_link()) : ?>
							<li class="previous"><?php previous_comments_link(__('&larr; Older comments', 'carhouse')); ?></li>
						<?php else: ?>
							<li class="previous disabled"><a><?php esc_html_e('&larr; Older comments', 'carhouse'); ?></a></li>
						<?php endif; ?>
						<?php if (get_next_comments_link()) : ?>
							<li class="next"><?php next_comments_link(__('Newer comments &rarr;', 'carhouse')); ?></li>
						<?php else: ?>
							<li class="next disabled"><a><?php esc_html_e('Newer comments &rarr;', 'carhouse'); ?></a></li>
						<?php endif; ?>
					</ul>
				</nav>
			<?php endif; // check for comment navigation ?>
		<?php endif; ?>
	</div><!-- /#comments -->
<?php endif; ?>

<div class="clearfix"></div>

<?php if (comments_open()) : ?>
	<div class="contact-form comment-box" id="respond">
		<?php /*if (isset($_GET['replytocom']) && $_GET['replytocom']): */?><!--
				<?php
/*				$replyTo = get_comment($_GET['replytocom']);
				*/?>
				<h2 class="title">Reply To: <?php /*echo wp_carhouse_text_truncate($replyTo->comment_content, 15) */?></h2>
		<?php /*else: */?>
			<h2 class="title">Write Your Comment</h2>
		--><?php /*endif; */?>
		<?php
		comment_form( array(
			'title_reply_before' => '<h2 id="reply-title" class="title">',
			'title_reply_after'  => '</h2>',
		) );
		?>
	</div>
<?php endif; ?>