<!-- Sidebar start-->
<div class="blog-sidebar">
    <?php
    if(is_active_sidebar('sidebar_widget')){
        dynamic_sidebar('sidebar_widget');
    }
    ?>
</div>
<!-- Sidebar end-->