<?php

/**
 * Class FooterGallery
 */
class FooterGallery extends WP_Widget
{
    /**
     * FooterGallery constructor.
     */
    public function __construct()
    {
        $widget_details = array(
            'classname' => 'footer_gallery_widget',
            'description' => __('Footer Vehicle Gallery Widget', 'carhouse')
        );

        parent::__construct('footer_gallery_widget', __('Car House: Vehicle Gallery (Footer)', 'carhouse'), $widget_details);
    }


    /**
     * @param array $instance
     */
    public function form($instance)
    {
        $title = !empty($instance['title']) ? $instance['title'] : 'Vehicle Gallery';
        $photoCount = !empty($instance['photo_count']) ? $instance['photo_count'] : 9;
        ?>
        <div class="widget_box">
            <div class="widget-field">
                <label><?php echo esc_attr__('Title', 'carhouse'); ?></label>
                <input class="widefat form-control" name="<?php echo esc_attr($this->get_field_name('title')); ?>"
                       placeholder="<?php echo esc_attr__('Title', 'carhouse'); ?>" value="<?php echo esc_attr($title); ?>"/>
            </div>

            <div class="widget-field">
                <label><?php echo esc_attr__('Number of Photo to Show', 'carhouse'); ?></label>
                <input class="widefat form-control" name="<?php echo esc_attr($this->get_field_name('photo_count')); ?>"
                       placeholder="<?php echo esc_attr__('Number of Photo to Show', 'carhouse'); ?>"
                       value="<?php echo $photoCount; ?>"/>
            </div>
        </div>
        <?php
    }

    /**
     * @param array $new_instance
     * @param array $old_instance
     * @return array
     */
    public function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        $instance['title'] = $new_instance['title'];
        $instance['photo_count'] = $new_instance['photo_count'];
        return $instance;
    }

    /**
     * @param array $args
     * @param array $instance
     */
    public function widget($args, $instance)
    {
        extract($args);
        $title = $instance['title'];
        $photoCount = $instance['photo_count'];
        $vehicles = getActiveVehicles($args = ['posts_per_page' => $photoCount]);
        echo $before_widget; ?>

        <div class="footer-item-content">
            <h2><?php echo esc_attr($title); ?></h2>
            <div class="line-dec"></div>
            <?php while ($vehicles->have_posts()): $vehicles->the_post(); ?>
                <div <?php post_class();?>>
                    <div class="gallery-item">
                        <a href="<?php echo esc_url(get_permalink()) ?>">
                            <?php
                            $image = array_values(rwmb_meta('vehicle_main_image', [], get_the_ID()));
                            $vehicleName = the_title('"', '"', false);
                            if (sizeof($image) > 0) {
                                echo "<img  src='{$image[0]['url']}' alt='".$vehicleName."'>";
                            } else {
                                global $carhouse;
                                $vehicleDummy = $carhouse['opt_default_vehicle_image']['url'];
                                echo "<img  src='{$vehicleDummy}' alt='".$vehicleName."'>";
                            }
                            ?>
                        </a>
                    </div>
                </div>
            <?php endwhile;
            wp_reset_postdata(); ?>
        </div>
        <div class="clearfix"></div>
        <?php echo $after_widget;
    }
}