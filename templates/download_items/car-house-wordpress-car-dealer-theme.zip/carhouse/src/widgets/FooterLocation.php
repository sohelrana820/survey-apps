<?php

/**
 * Class FooterLocation
 */
class FooterLocation extends WP_Widget
{

    /**
     * FooterLocation constructor.
     */
    public function __construct()
    {
        $widget_details = array(
            'classname' => 'footer_location_widget',
            'description' => __('Footer Location Widget', 'carhouse')
        );

        parent::__construct('footer_location_widget', __('Car House: Location (Footer)', 'carhouse'), $widget_details);
        add_action('admin_enqueue_scripts', array($this, 'wp_carhouse_scripts'));
    }

    /**
     *
     */
    public function wp_carhouse_scripts()
    {
        wp_enqueue_script('media-upload');
        wp_enqueue_media();
        wp_enqueue_script('our_admin', get_template_directory_uri() . '/assets/js/our_admin.js', array('jquery'));
        wp_enqueue_style('style', get_template_directory_uri() . '/assets/css/admin.css');
    }

    /**
     * @param array $instance
     */
    public function form($instance)
    {
        $image = !empty($instance['image']) ? $instance['image'] : '';
        ?>
        <div class="widget_box">
            <div class="widget-field">
                <div>
                    <?php if ($image): ?>
                        <img src="<?php echo esc_url($image); ?>" alt="">
                    <?php else: ?>
                        <img src="<?php echo get_template_directory_uri() . '/assets/img/png/logo.png' ?>" alt="">
                    <?php endif; ?>
                </div>
                <input class="widefat form-control" name="<?php echo $this->get_field_name('image'); ?>" type="hidden"
                       value="<?php echo esc_url($image); ?>"/>
                <button class="upload_image_button button button-primary"><?php echo esc_attr__('Change Logo', 'carhouse');?></button>
            </div>
            <div class="widget-field">
                <label><?php echo esc_attr__('Short Description', 'carhouse');?></label>
                <textarea class="widefat form-control" rows="4" name="<?php echo $this->get_field_name('short_descriptiopn'); ?>" placeholder="<?php echo esc_attr__('Short Description', 'carhouse');?>" >
                    <?php echo isset($instance['short_descriptiopn']) ? $instance['short_descriptiopn'] : null; ?>
                </textarea>
            </div>
            <div class="widget-field">
                <label><?php echo esc_attr__('Address', 'carhouse');?></label>
                <input class="widefat form-control" name="<?php echo $this->get_field_name('address'); ?>"
                       placeholder="<?php echo esc_attr__('Footer Address', 'carhouse');?>" value="<?php echo isset($instance['address']) ? $instance['address'] : null; ?>"/>
            </div>
            <div class="widget-field">
                <label><?php echo esc_attr__('Email', 'carhouse');?></label>
                <input class="widefat form-control" name="<?php echo $this->get_field_name('email'); ?>"
                       placeholder="<?php echo esc_attr__('Footer Email', 'carhouse');?>" value="<?php echo isset($instance['email']) ? $instance['email'] : null; ?>"/>
            </div>
            <div class="widget-field">
                <label><?php echo esc_attr__('Phone', 'carhouse');?></label>
                <input class="widefat form-control" name="<?php echo $this->get_field_name('phone'); ?>"
                       placeholder="<?php echo esc_attr__('Footer Phone', 'carhouse');?>" value="<?php echo isset($instance['phone']) ? $instance['phone'] : null; ?>"/>
            </div>
            <br/>
            <h4 class="text-uppercase">Social Media:</h4>
            <div class="widget-field">
                <label><?php echo esc_attr__('Facebook', 'carhouse');?></label>
                <input class="widefat form-control" type="url" name="<?php echo $this->get_field_name('facebook_url'); ?>"
                       placeholder="<?php echo esc_attr__('Facebook URL', 'carhouse');?>" value="<?php echo isset($instance['facebook_url']) ? $instance['facebook_url'] : null; ?>"/>
            </div>
            <div class="widget-field">
                <label><?php echo esc_attr__('Twitter', 'carhouse');?></label>
                <input class="widefat form-control" type="url" name="<?php echo $this->get_field_name('twitter_url'); ?>"
                       placeholder="<?php echo esc_attr__('Address URL', 'carhouse');?>" value="<?php echo isset($instance['twitter_url']) ? $instance['twitter_url'] : null; ?>"/>
            </div>
            <div class="widget-field">
                <label><?php echo esc_attr__('Google Plus', 'carhouse');?></label>
                <input class="widefat form-control" type="url" name="<?php echo $this->get_field_name('google_plus_url'); ?>"
                       placeholder="<?php echo esc_attr__('Google Plus URL', 'carhouse');?>" value="<?php echo isset($instance['google_plus_url']) ? $instance['google_plus_url'] : null; ?>"/>
            </div>
            <div class="widget-field">
                <label><?php echo esc_attr__('LinkedIn', 'carhouse');?></label>
                <input class="widefat form-control" type="url" name="<?php echo $this->get_field_name('linkedin_url'); ?>"
                       placeholder="<?php echo esc_attr__('LinkedIn URL', 'carhouse');?>" value="<?php echo isset($instance['linkedin_url']) ? $instance['linkedin_url'] : null; ?>"/>
            </div>
            <div class="widget-field">
                <label><?php echo esc_attr__('RSS Feed', 'carhouse');?></label>
                <input class="widefat form-control" type="url" name="<?php echo $this->get_field_name('rss_feed'); ?>"
                       placeholder="<?php echo esc_attr__('RSS Feed', 'carhouse');?>" value="<?php echo isset($instance['rss_feed']) ? $instance['rss_feed'] : null; ?>"/>
            </div>
            <div class="widget-field">
                <label><?php echo esc_attr__('Vimeo', 'carhouse');?></label>
                <input class="widefat form-control" type="url" name="<?php echo $this->get_field_name('vimeo_url'); ?>"
                       placeholder="<?php echo esc_attr__('Vimeo URL', 'carhouse');?>" value="<?php echo isset($instance['vimeo_url']) ? $instance['vimeo_url'] : null; ?>"/>
            </div>
        </div>
        <?php
    }

    /**
     * @param array $new_instance
     * @param array $old_instance
     * @return array
     */
    public function update($new_instance, $old_instance)
    {
        $instance = $old_instance;

        $instance['image'] = (!empty($new_instance['image'])) ? $new_instance['image'] : '';
        $instance['short_descriptiopn'] = strip_tags($new_instance['short_descriptiopn']);
        $instance['address'] = $new_instance['address'];
        $instance['email'] = $new_instance['email'];
        $instance['phone'] = $new_instance['phone'];
        $instance['facebook_url'] = $new_instance['facebook_url'];
        $instance['twitter_url'] = $new_instance['twitter_url'];
        $instance['google_plus_url'] = $new_instance['google_plus_url'];
        $instance['linkedin_url'] = $new_instance['linkedin_url'];
        $instance['rss_feed'] = $new_instance['rss_feed'];
        $instance['vimeo_url'] = $new_instance['vimeo_url'];
        return $instance;
    }

    /**
     * @param array $args
     * @param array $instance
     */
    public function widget($args, $instance)
    {
        extract($args);
        $image = !empty($instance['image']) ? $instance['image'] : '';
        $address = $instance['address'];
        $shortDescrition = $instance['short_descriptiopn'];
        $phone = $instance['phone'];
        $email = $instance['email'];


        echo $before_widget;
        if (isset($title)) {
            echo $before_title . $title . $after_title;
        } ?>
        <div class="footer-item-content">
            <a href="<?php echo get_home_url(); ?>">
                <?php if ($image): ?>
                    <img src="<?php echo esc_url($image); ?>" alt="">
                <?php else: ?>
                    <img src="<?php echo get_template_directory_uri() . '/assets/img/png/logo.png' ?>" class="footer-logo" alt="">
                <?php endif; ?>
            </a>
            <p><?php echo $shortDescrition; ?></p>
            <ul>
                <?php if ($address): ?>
                    <li>
                        <a>
                            <i class="fa fa-map-marker"></i><?php echo $address; ?>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if ($phone): ?>
                    <li>
                        <a href="tel:<?php echo $phone; ?>"><i class="fa fa-phone"></i> <?php echo $phone; ?></a>
                    </li>
                <?php endif; ?>
                <?php if ($email): ?>
                    <li>
                        <a href="mailto:<?php echo $email; ?>">
                            <i class="fa fa-envelope-o "></i> <?php echo $email; ?>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>

            <ul class="social-list clearfix">
                <?php if ($instance['facebook_url']): ?>
                    <li>
                        <a href="<?php echo $instance['facebook_url']; ?>" class="facebook">
                            <i class="fa fa-facebook"></i>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if ($instance['twitter_url']): ?>
                    <li>
                        <a href="<?php echo $instance['twitter_url'] ?>" class="twitter">
                            <i class="fa fa-twitter"></i>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if ($instance['linkedin_url']): ?>
                    <li>
                        <a href="<?php echo $instance['linkedin_url'] ?>" class="linkedin">
                            <i class="fa fa-linkedin"></i>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if ($instance['google_plus_url']): ?>
                    <li>
                        <a href="<?php echo $instance['google_plus_url']; ?>" class="google">
                            <i class="fa fa-google-plus"></i>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if ($instance['rss_feed']): ?>
                    <li>
                        <a href="<?php echo $instance['rss_feed']; ?>" class="rss">
                            <i class="fa fa-rss"></i>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if ($instance['vimeo_url']): ?>
                    <li>
                        <a href="<?php echo $instance['vimeo_url']; ?>" class="vimeo">
                            <i class="fa fa-vimeo"></i>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
        <?php echo $after_widget;
    }
}