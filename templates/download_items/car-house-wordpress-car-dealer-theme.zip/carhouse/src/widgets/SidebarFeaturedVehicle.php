<?php

/**
 * Class SidebarFeaturedVehicle
 */
class SidebarFeaturedVehicle extends WP_Widget
{
    /**
     * SidebarFeaturedVehicle constructor.
     */
    public function __construct()
    {
        $widget_details = array(
            'classname' => 'sidebar_featured_vehicle_widget',
            'description' => __('Sidebar Featured Vehicle Widget', 'carhouse')
        );

        parent::__construct('sidebar_featured_vehicle_widget', __('Car House: Featured Vehicle (Sidebar)', 'carhouse'), $widget_details);
    }

    /**
     * @param array $instance
     */
    public function form($instance)
    {
        $title = !empty($instance['title']) ? $instance['title'] : 'Featured Vehicles';
        ?>
        <div class="widget_box">
            <div class="widget-field">
                <label><?php echo esc_attr__('Title', 'carhouse'); ?></label>
                <input class="widefat form-control" name="<?php echo $this->get_field_name('title'); ?>"
                       placeholder="<?php echo esc_attr__('Title', 'carhouse'); ?>" value="<?php echo esc_attr($title); ?>"/>
            </div>
        </div>
        <?php
    }

    /**
     * @param array $new_instance
     * @param array $old_instance
     * @return array
     */
    public function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        $instance['title'] = $new_instance['title'];
        return $instance;
    }

    /**
     * @param array $args
     * @param array $instance
     */
    public function widget($args, $instance)
    {
        extract($args);
        $title = $instance['title'];
        echo $before_widget;
        $mostRecentPost = getFeturedVehicles(array('posts_per_page' => 1));
        if($mostRecentPost->post_count > 0){
            echo '<h4 class="widget-title">'.$title.'</h4>';
            while ($mostRecentPost->have_posts()): $mostRecentPost->the_post();
                get_template_part('elements/listing-grid');
            endwhile;
            wp_reset_postdata();
        }
        echo $after_widget;
    }
}