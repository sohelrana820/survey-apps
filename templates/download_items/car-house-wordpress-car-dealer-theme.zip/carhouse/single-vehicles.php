<?php
// Displaying header
get_header();
$args = array(
    'p'         => get_the_ID(), // ID of a page, post, or custom type
    'post_type' => 'vehicles',
    'posts_per_page' => 1,
);
if(!isset($_GET['preview']) && !isset($_GET['preview_id'])){
    $args['meta_query'] = array(
        array(
            'key' => 'vehicle_status',
            'value' => 'active',
            'compare' => '=',
        ),
        array(
            'key' => 'vehicle_expiry',
            'value' => date("Y-m-d"),
            'compare' => '>=',
        )
    );
}
$vehicles = new WP_Query($args);
if($vehicles->post_count == 0){
    $vehicles->set_404();
    status_header( 404 );
    get_template_part( 404 );
    exit();
}

// Displaying single page banner
get_template_part('elements/banner-single');
?>
<?php while ($vehicles->have_posts()): $vehicles->the_post(); ?>
    <div <?php post_class();?>>
        <div class="car-details content-area">
            <?php
            $vehicleTitle = get_the_ID();
            $sidebarPosition = $carhouse['opt_default_listing_sidebar_position'] ? $carhouse['opt_default_listing_sidebar_position'] : 'Right';
            ?>
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 <?php if ($sidebarPosition == 'Left') {
                        echo esc_attr__('col-lg-push-4 col-md-push-4', 'carhouse');
                    } ?>">
                        <div class="option-bar pricing-in-single">
                            <div class="row">
                                <div class="col-lg-9 col-md-9 col-sm-8">
                                    <div class="section-heading">
                                        <i class="fa fa-car"></i>
                                        <h2 class="car-title"><a href="<?php echo esc_url(get_permalink()) ?>"><?php the_title(); ?></a></h2>
                                        <div class="border"></div>
                                        <h4><?php echo esc_attr__('Details of', 'carhouse');?> <?php the_title(); ?></h4>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-4 text-right">
                                    <div class="car-details-header-price">
                                        <h3>
                                            <?php echo esc_attr($carhouse['opt_default_currency']); ?>
                                            <?php echo esc_attr(number_format(get_post_meta(get_the_ID(), 'vehicle_sale_price', true), 2)) ?>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php
                        $vehicleVideo = rwmb_meta('vehicle_video', [], get_the_ID());
                        $attributes = array_values(rwmb_meta('custom_attributes', [], get_the_ID()));
                        $images = array_values(rwmb_meta('vehicle_main_image', ['size' => 'vehicle-details-image'], get_the_ID()));
                        $galleries = array_values(rwmb_meta('vehicle_galleries', ['size' => 'vehicle-details-image'], get_the_ID()));
                        if(sizeof($images) > 0 && sizeof($galleries) > 0){
                            $galleries = array_merge($images, $galleries);
                        } else {
                            $galleries = $images;
                        }

                        $features = rwmb_meta('vehicle_features');
                        $features = is_array($features) ? array_values($features) : [];
                        ?>

                        <div class="clearfix"></div>

                        <!-- Car detail slider start-->
                        <div class="car-detail-slider">
                            <?php if (sizeof($galleries) > 0): ?>
                                <div id="carousel-custom" class="carousel slide" data-ride="carousel">
                                    <div class="carousel-outer">
                                        <!-- Wrapper for slides -->
                                        <div class="carousel-inner">
                                            <?php foreach ($galleries as $key => $gallery): ?>
                                                <?php
                                                $alt = null;
                                                if (!$alt && $gallery['alt'] != '') {
                                                    $alt = $gallery['alt'];
                                                } elseif (!$alt && $gallery['title'] != '') {
                                                    $alt = $gallery['title'];
                                                } elseif (!$alt && $gallery['caption'] != '') {
                                                    $alt = $gallery['caption'];
                                                }
                                                ?>
                                                <div class="item <?php if ($key == 0) {
                                                    echo esc_attr__('active', 'carhouse');
                                                } ?>">
                                                    <img src="<?php echo esc_attr($gallery['full_url']) ?>" class="thumb-preview"
                                                         alt="<?php echo esc_attr($alt); ?>">
                                                </div>
                                            <?php endforeach; ?>
                                        </div>

                                        <?php if(sizeof($galleries) > 1):?>
                                            <!-- Controls -->
                                            <a class="left carousel-control" href="#carousel-custom" role="button"
                                               data-slide="prev">
                                          <span class="slider-mover-left no-bg" aria-hidden="true">
                                             <img
                                                 src="<?php echo esc_url(get_template_directory_uri()) ?>/assets/img/png/left-chevron.png"
                                                 alt="left-chevron">
                                          </span>
                                                <span class="sr-only"><?php echo esc_attr__('Previous', 'carhouse');?></span>
                                            </a>
                                            <a class="right carousel-control" href="#carousel-custom" role="button"
                                               data-slide="next">
                                        <span class="slider-mover-right no-bg" aria-hidden="true">
                                            <img
                                                src="<?php echo esc_url(get_template_directory_uri()) ?>/assets/img/png/right-chevron.png"
                                                alt="right-chevron">
                                        </span>
                                                <span class="sr-only"><?php echo esc_attr__('Next', 'carhouse');?></span>
                                            </a>
                                        <?php endif;?>
                                    </div>

                                    <?php if(sizeof($galleries) > 1):?>
                                        <!-- Indicators -->
                                        <ol class="carousel-indicators thumbs visible-lg visible-md">
                                            <?php foreach ($galleries as $key => $gallery): ?>
                                                <?php
                                                $alt = null;
                                                if (!$alt && $gallery['alt'] != '') {
                                                    $alt = $gallery['alt'];
                                                } elseif (!$alt && $gallery['title'] != '') {
                                                    $alt = $gallery['title'];
                                                } elseif (!$alt && $gallery['caption'] != '') {
                                                    $alt = $gallery['caption'];
                                                }
                                                ?>
                                                <li data-target="#carousel-custom" data-slide-to="<?php echo esc_attr($key); ?>"
                                                    class="<?php if ($key == 0) {
                                                        echo esc_attr__('active', 'carhouse');
                                                    } ?>">
                                                    <img src="<?php echo esc_attr($gallery['url']); ?>" alt="<?php echo esc_attr($alt); ?>">
                                                </li>
                                            <?php endforeach; ?>
                                        </ol>
                                    <?php endif;?>
                                </div>
                            <?php else: ?>
                                <?php
                                $vehicleDummy = $carhouse['opt_default_vehicle_image']['url'];
                                ?>
                                <img src='<?php echo esc_attr($vehicleDummy);?>' alt='<?php the_title(); ?>'
                                     class='img-responsive'>
                            <?php endif; ?>
                        </div>
                        <!-- Car detail slider End-->

                        <div class="car-detail-block mrg-b-30 visible-xs visible-sm">
                            <div class="section-heading">
                                <i class="fa fa-search-plus"></i>
                                <h2><?php echo esc_attr__('Car specifications', 'carhouse');?></h2>
                                <div class="border"></div>
                                <h4><?php echo esc_attr__('Check the car specifications', 'carhouse');?></h4>
                            </div>
                            <ul class="car-detail-info-list">
                                <li>
                                    <span><?php echo esc_attr__('VIN #', 'carhouse'); ?>:</span>
                                    <?php
                                    $vin = get_post_meta(get_the_ID(), 'vehicle_vin', true);
                                    echo esc_attr($vin ? $vin : 'N/A')
                                    ?>
                                </li>
                                <li>
                                    <span><?php echo esc_attr__('Brand', 'carhouse'); ?>:</span>
                                    <?php
                                    $brand = rwmb_meta('vehicle_brand', [], get_the_ID());
                                    echo esc_attr(isset($brand->name) ? $brand->name : 'N/A')
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Transmission', 'carhouse'); ?>:</span>
                                    <?php
                                    $transmission = rwmb_meta('vehicle_transmission', [], get_the_ID());
                                    echo esc_attr(isset($transmission->name) ? $transmission->name : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Fuel', 'carhouse'); ?>:</span>
                                    <?php
                                    $fuel = rwmb_meta('vehicle_fuel', [], get_the_ID());
                                    echo esc_attr(isset($fuel->name) ? $fuel->name : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Condition', 'carhouse'); ?>:</span>
                                    <?php
                                    $condition = rwmb_meta('vehicle_condition', [], get_the_ID());
                                    echo esc_attr(isset($condition->name) ? $condition->name : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Category', 'carhouse'); ?>:</span>
                                    <?php
                                    $category = rwmb_meta('vehicle_category', [], get_the_ID());
                                    echo esc_attr(isset($category->name) ? $category->name : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Body Style', 'carhouse'); ?>:</span>
                                    <?php
                                    $body = get_post_meta(get_the_ID(), 'vehicle_body_style', true);
                                    echo esc_attr($body ? $body : 'N/A')
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Engine', 'carhouse'); ?>:</span>
                                    <?php
                                    $engine = get_post_meta(get_the_ID(), 'vehicle_engine', true);
                                    echo esc_attr($engine ? $engine : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Horse Power', 'carhouse'); ?>:</span>
                                    <?php
                                    $horsePower = get_post_meta(get_the_ID(), 'vehicle_horse_power', true);
                                    echo esc_attr($horsePower ? $horsePower . ' hp' : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Drive Train', 'carhouse'); ?>:</span>
                                    <?php
                                    $driveTrain = get_post_meta(get_the_ID(), 'vehicle_drive_train', true);
                                    echo esc_attr($driveTrain ? $driveTrain : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Interior color', 'carhouse'); ?>:</span>
                                    <?php
                                    $interiorColor = get_post_meta(get_the_ID(), 'vehicle_interior_color', true);
                                    echo esc_attr($interiorColor ? $interiorColor : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Exterior color', 'carhouse'); ?>:</span>
                                    <?php
                                    $exteriorColor = get_post_meta(get_the_ID(), 'vehicle_exterior_color', true);
                                    echo esc_attr($exteriorColor ? $exteriorColor : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Miles', 'carhouse'); ?>:</span>
                                    <?php
                                    $miles = get_post_meta(get_the_ID(), 'vehicle_miles', true);
                                    echo esc_attr($miles ? $miles . ' '.$carhouse['opt_default_mile_unit'] : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Mileage', 'carhouse'); ?>:</span>
                                    <?php
                                    $mileage = get_post_meta(get_the_ID(), 'vehicle_mileage', true);
                                    echo esc_attr($mileage ? $mileage . ' ' . $carhouse['opt_default_mileage_unit'] : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Top Speed', 'carhouse'); ?>:</span>
                                    <?php
                                    $topSpeed = get_post_meta(get_the_ID(), 'vehicle_top_speed', true);
                                    echo esc_attr($topSpeed ? $topSpeed . ' ' . $carhouse['opt_default_speed_unit'] : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Odometer', 'carhouse'); ?>:</span>
                                    <?php
                                    $odoMeter = get_post_meta(get_the_ID(), 'vehicle_odometer', true);
                                    echo esc_attr($odoMeter ? $odoMeter . ' ' . $carhouse['opt_default_speed_unit'] : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Torque', 'carhouse'); ?>:</span>
                                    <?php
                                    $torque = get_post_meta(get_the_ID(), 'vehicle_torque', true);
                                    echo esc_attr($torque ? $torque : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Towing Capacity', 'carhouse'); ?>:</span>
                                    <?php
                                    $towingCapacity = get_post_meta(get_the_ID(), 'vehicle_towing_capacity', true);
                                    echo esc_attr($towingCapacity ? $towingCapacity : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Doors', 'carhouse'); ?>:</span>
                                    <?php
                                    $doors = get_post_meta(get_the_ID(), 'vehicle_doors', true);
                                    echo esc_attr($doors ? $doors : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Passengers', 'carhouse'); ?>:</span>
                                    <?php
                                    $passengers = get_post_meta(get_the_ID(), 'vehicle_passengers', true);
                                    echo esc_attr($passengers ? $passengers : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Purpose', 'carhouse'); ?>:</span>
                                    <?php
                                    $vehicleFor = get_post_meta(get_the_ID(), 'vehicle_for', true);
                                    echo esc_attr($vehicleFor ? $vehicleFor : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Stock', 'carhouse'); ?>:</span>
                                    <?php
                                    $stock = get_post_meta(get_the_ID(), 'vehicle_stock', true);
                                    echo esc_attr($stock ? $stock : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Expired In', 'carhouse'); ?>:</span>
                                    <?php
                                    $vehicleExpiry = get_post_meta(get_the_ID(), 'vehicle_expiry', true);
                                    echo esc_attr($vehicleExpiry ? date('M d, Y', strtotime($vehicleExpiry)) : 'N/A');
                                    ?>
                                </li>

                                <li>
                                    <span><?php echo esc_attr__('Manufacture Year', 'carhouse'); ?>:</span>
                                    <?php
                                    $manufactureYear = get_post_meta(get_the_ID(), 'vehicle_manufacture_year', true);
                                    echo esc_attr($manufactureYear ? $manufactureYear : 'N/A');
                                    ?>
                                </li>
                            </ul>
                        </div>

                        <div class="clearfix"></div>

                        <!-- Car details content body start -->
                        <div class="car-details-content-body">
                            <ul class="nav nav-tabs">
                                <li class="active">
                                    <a href="#tab1default" data-toggle="tab" aria-expanded="true">
                                        <?php echo esc_attr__('Vehicle Overview', 'carhouse'); ?>
                                    </a>
                                </li>
                                <?php if (sizeof($features) > 0): ?>
                                    <li class="">
                                        <a href="#tab2default" data-toggle="tab" aria-expanded="false">
                                            <?php echo esc_attr__('Vehicle Features', 'carhouse');?>
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if (sizeof($attributes) > 0 && $attributes[0]['meta_key'] != ''): ?>
                                    <li class="">
                                        <a href="#tab3default" data-toggle="tab" aria-expanded="false">
                                            <?php echo esc_attr__('Additional', 'carhouse');?>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                            <div class="panel with-nav-tabs panel-default">
                                <div class="panel-body">
                                    <div class="tab-content">
                                        <div class="tab-pane fade active in" id="tab1default">
                                            <h2 class="border-title"><?php echo esc_attr__('Vehicle Overview', 'carhouse')?></h2>
                                            <div class="page_dynamic_content">
                                                <?php echo the_content(); ?>
                                            </div>
                                        </div>
                                        <?php if (sizeof($features) > 0): ?>
                                            <div class="tab-pane fade features" id="tab2default">
                                                <h2 class="border-title"><?php echo esc_attr__('Vehicle Features', 'carhouse')?></h2>
                                                <ul>
                                                    <?php foreach ($features as $feature): ?>
                                                        <li>
                                                            <i class="fa fa-check"></i>
                                                            <?php echo esc_attr($feature->name); ?>
                                                        </li>
                                                    <?php endforeach;; ?>
                                                </ul>
                                            </div>
                                        <?php endif; ?>

                                        <?php if (sizeof($attributes) > 0 && $attributes[0]['meta_key'] != ''): ?>
                                            <div class="tab-pane fade technical" id="tab3default">
                                                <h2 class="border-title"><?php echo esc_attr__('Additional Info', 'carhouse')?></h2>
                                                <ul>
                                                    <?php foreach ($attributes as $attribute): ?>
                                                        <li>
                                                            <strong><?php echo esc_attr($attribute['meta_key']);?>:</strong>
                                                            <span><?php echo esc_attr($attribute['meta_value'])?></span>
                                                        </li>
                                                    <?php endforeach;; ?>
                                                </ul>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Car details content body end -->

                        <?php if($vehicleVideo):?>
                            <h2 class="border-title">
                                Video
                            </h2>

                            <?php echo $vehicleVideo;?>

                            <br/>
                            <br/>
                        <?php endif;?>
                        <!-- Comments box start -->
                        <?php comments_template(); ?>
                    </div>

                    <div class="col-lg-4 col-md-4 col-xs-12 <?php if ($sidebarPosition == 'Left') {
                        echo esc_attr__('col-lg-pull-8 col-md-pull-8', 'carhouse');
                    } ?>">
                        <!-- Car sidebar right Start-->
                        <div class="car-sidebar-right">
                            <!-- Car detail block Start-->
                            <div class="car-detail-block mrg-b-30 visible-lg visible-md">
                                <div class="section-heading">
                                    <i class="fa fa-search-plus"></i>
                                    <h2><?php echo esc_attr__('Car specifications', 'carhouse');?></h2>
                                    <div class="border"></div>
                                    <h4><?php echo esc_attr__('Check the car specifications', 'carhouse');?></h4>
                                </div>
                                <ul class="car-detail-info-list">
                                    <li>
                                        <span><?php echo esc_attr__('VIN #', 'carhouse'); ?>:</span>
                                        <?php
                                        $vin = get_post_meta(get_the_ID(), 'vehicle_vin', true);
                                        echo esc_attr($vin ? $vin : 'N/A')
                                        ?>
                                    </li>
                                    <li>
                                        <span><?php echo esc_attr__('Brand', 'carhouse'); ?>:</span>
                                        <?php
                                        $brand = rwmb_meta('vehicle_brand', [], get_the_ID());
                                        echo esc_attr(isset($brand->name) ? $brand->name : 'N/A')
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Transmission', 'carhouse'); ?>:</span>
                                        <?php
                                        $transmission = rwmb_meta('vehicle_transmission', [], get_the_ID());
                                        echo esc_attr(isset($transmission->name) ? $transmission->name : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Fuel', 'carhouse'); ?>:</span>
                                        <?php
                                        $fuel = rwmb_meta('vehicle_fuel', [], get_the_ID());
                                        echo esc_attr(isset($fuel->name) ? $fuel->name : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Condition', 'carhouse'); ?>:</span>
                                        <?php
                                        $condition = rwmb_meta('vehicle_condition', [], get_the_ID());
                                        echo esc_attr(isset($condition->name) ? $condition->name : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Category', 'carhouse'); ?>:</span>
                                        <?php
                                        $category = rwmb_meta('vehicle_category', [], get_the_ID());
                                        echo esc_attr(isset($category->name) ? $category->name : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Body Style', 'carhouse'); ?>:</span>
                                        <?php
                                        $body = get_post_meta(get_the_ID(), 'vehicle_body_style', true);
                                        echo esc_attr($body ? $body : 'N/A')
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Engine', 'carhouse'); ?>:</span>
                                        <?php
                                        $engine = get_post_meta(get_the_ID(), 'vehicle_engine', true);
                                        echo esc_attr($engine ? $engine : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Horse Power', 'carhouse'); ?>:</span>
                                        <?php
                                        $horsePower = get_post_meta(get_the_ID(), 'vehicle_horse_power', true);
                                        echo esc_attr($horsePower ? $horsePower . ' hp' : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Drive Train', 'carhouse'); ?>:</span>
                                        <?php
                                        $driveTrain = get_post_meta(get_the_ID(), 'vehicle_drive_train', true);
                                        echo esc_attr($driveTrain ? $driveTrain : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Interior color', 'carhouse'); ?>:</span>
                                        <?php
                                        $interiorColor = get_post_meta(get_the_ID(), 'vehicle_interior_color', true);
                                        echo esc_attr($interiorColor ? $interiorColor : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Exterior color', 'carhouse'); ?>:</span>
                                        <?php
                                        $exteriorColor = get_post_meta(get_the_ID(), 'vehicle_exterior_color', true);
                                        echo esc_attr($exteriorColor ? $exteriorColor : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Miles', 'carhouse'); ?>:</span>
                                        <?php
                                        $miles = get_post_meta(get_the_ID(), 'vehicle_miles', true);
                                        echo esc_attr($miles ? $miles . ' '.$carhouse['opt_default_mile_unit'] : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Mileage', 'carhouse'); ?>:</span>
                                        <?php
                                        $mileage = get_post_meta(get_the_ID(), 'vehicle_mileage', true);
                                        echo esc_attr($mileage ? $mileage . ' ' . $carhouse['opt_default_mileage_unit'] : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Top Speed', 'carhouse'); ?>:</span>
                                        <?php
                                        $topSpeed = get_post_meta(get_the_ID(), 'vehicle_top_speed', true);
                                        echo esc_attr($topSpeed ? $topSpeed . ' ' . $carhouse['opt_default_speed_unit'] : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Odometer', 'carhouse'); ?>:</span>
                                        <?php
                                        $odoMeter = get_post_meta(get_the_ID(), 'vehicle_odometer', true);
                                        echo esc_attr($odoMeter ? $odoMeter . ' ' . $carhouse['opt_default_speed_unit'] : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Torque', 'carhouse'); ?>:</span>
                                        <?php
                                        $torque = get_post_meta(get_the_ID(), 'vehicle_torque', true);
                                        echo esc_attr($torque ? $torque : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Towing Capacity', 'carhouse'); ?>:</span>
                                        <?php
                                        $towingCapacity = get_post_meta(get_the_ID(), 'vehicle_towing_capacity', true);
                                        echo esc_attr($towingCapacity ? $towingCapacity : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Doors', 'carhouse'); ?>:</span>
                                        <?php
                                        $doors = get_post_meta(get_the_ID(), 'vehicle_doors', true);
                                        echo esc_attr($doors ? $doors : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Passengers', 'carhouse'); ?>:</span>
                                        <?php
                                        $passengers = get_post_meta(get_the_ID(), 'vehicle_passengers', true);
                                        echo esc_attr($passengers ? $passengers : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Purpose', 'carhouse'); ?>:</span>
                                        <?php
                                        $vehicleFor = get_post_meta(get_the_ID(), 'vehicle_for', true);
                                        echo esc_attr($vehicleFor ? $vehicleFor : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Stock', 'carhouse'); ?>:</span>
                                        <?php
                                        $stock = get_post_meta(get_the_ID(), 'vehicle_stock', true);
                                        echo esc_attr($stock ? $stock : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Expired In', 'carhouse'); ?>:</span>
                                        <?php
                                        $vehicleExpiry = get_post_meta(get_the_ID(), 'vehicle_expiry', true);
                                        echo esc_attr($vehicleExpiry ? date('M d, Y', strtotime($vehicleExpiry)) : 'N/A');
                                        ?>
                                    </li>

                                    <li>
                                        <span><?php echo esc_attr__('Manufacture Year', 'carhouse'); ?>:</span>
                                        <?php
                                        $manufactureYear = get_post_meta(get_the_ID(), 'vehicle_manufacture_year', true);
                                        echo esc_attr($manufactureYear ? $manufactureYear : 'N/A');
                                        ?>
                                    </li>
                                </ul>
                            </div>
                            <!-- Car detail block end-->

                            <div class="clearfix"></div>
                            <div class="vehicle-sidebar-area">
                                <?php get_sidebar('single-vehicle'); ?>
                            </div>
                        </div>
                        <!-- Car sidebar right end-->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>

    <!-- Displaying Related Vehicles [START] -->
    <?php
    $enableRelatedVehicle = rwmb_meta('enable_related_vehicles', [], get_the_ID());
    $relatedVehicles = wp_carhouse_get_ralated_vehicle($vehicleTitle);
    if(isset($relatedVehicles->posts) && sizeof($relatedVehicles->posts) > 0 && $enableRelatedVehicle == '1') :
    ?>
    <div class="container">
        <div class="mar-b-20">
            <h2 class="h2-title">Related Vehicles</h2>
            <div class="row">
                <?php
                if($relatedVehicles->post_count > 0) :
                    while($relatedVehicles->have_posts()): $relatedVehicles->the_post();
                        ?>
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                            <?php get_template_part('elements/listing-grid') ?>
                        </div>
                    <?php
                    endwhile;
                endif;?>
            </div>
        </div>
    </div>
    <?php endif;?>
    <!-- Displaying Related Vehicles [END] -->
<?php endwhile;?>

<?php get_footer(); ?>