<div <?php post_class();?>>
	<div class="thumbnail blog-box clearfix">
		<?php
		global $carhouse;
		$title = the_title('', '', false);
		if(has_post_thumbnail()){
			echo get_the_post_thumbnail(null, 'post-thumbnail', array('class' => 'post-featured-img'));
		} elseif($carhouse['opt_default_featured_image']['url']) {
			echo '<img src="'.esc_url($carhouse['opt_default_featured_image']['url']).'" alt="'.esc_attr($title).'">';
		} else{
			echo '<img src="'.esc_url(get_template_directory_uri() . '/assets/img/default-featured.jpg').'" alt="'.esc_attr($title).'">';
		}
		?>
		<!-- detail -->
		<div class="caption detail">
			<!-- Title -->
			<h1 class="title">
				<a href="<?php echo esc_url(get_permalink());?>"><?php echo esc_attr($title);?></a>
			</h1>
			<!-- Post Materials-->
			<div class="post-materials">
				<div class="header">
					BY <?php echo get_the_author_posts_link();?>
					<i class="fa fa-clock-o"></i> <?php echo esc_attr(date('M d, Y', strtotime(get_the_date())))?>
					<i class="fa fa-bars"></i>
					<?php
					$separate_meta = esc_attr__( ', ', 'carhouse' );
					echo get_the_category_list( $separate_meta );
					?>
					<i class="fa fa-commenting-o"></i>
					<a href="#"><?php comments_number( 'no comments', 'one comments', '% comments' );?></a>
				</div>
				<!-- paragraph -->
				<p><?php echo wp_carhouse_excerpt(200)?></p>
				<!-- Btn -->
				<a href="<?php echo esc_url(get_permalink());?>" class="btn btn-read-more"><?php echo esc_attr($carhouse['blog_page_button_text']);?></a>
			</div>
		</div>
	</div>
</div>
<div class="clearfix"></div>
