<?php
/*
Template Name: Services (Services page layout)
*/
?>

<?php
global $carhouse;
// Displaying header
get_header();

// Displaying single page banner
get_template_part('elements/banner-single');
?>

<div class="about-body">
    <?php
    $query = array(
        'post_type' => 'services',
        'post_status' => 'publish',
        'posts_per_page' => 100
    );
    $services = new WP_Query($query);
    ?>
    <div class="">
        <div class="container">
            <?php if($services->post_count > 0):?>
                <div class="title title-area">
                    <h2 class="h2-title"><?php echo esc_attr(get_field('service_title_text'));?></h2>
                    <hr/>
                </div>
                <div class="row">
                    <?php
                    while($services->have_posts()) : $services->the_post();
                    $serviceName = get_the_title();
                    ?>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="Services-box text-center">
                            <div <?php post_class();?>>
                                <?php
                                $icons = get_post_meta(get_the_ID(), 'service_fields');
                                $serviceIcon = 'fa-cog';
                                if(sizeof($icons) > 0){
                                    $serviceIcon = $icons[0]['icon_class'];
                                }
                                ?>
                                <i class="fa <?php echo esc_html($serviceIcon);?>"></i>
                                <h3><a href="<?php echo esc_url(get_permalink());?>"><?php echo esc_attr($serviceName);?></a></h3>
                                <p><?php echo wp_carhouse_excerpt(25) ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endwhile;wp_reset_postdata(); ?>
                </div>
            <?php else:?>
                <div class="error-404">
                    <div class="e404">
                        <div class="title-error">Services is Empty</div>
                        <p class="visible-lg visible-md">Sorry, No services were found.</p>
                    </div>
                </div>
                <br/><br/>
            <?php endif;?>
        </div>
    </div>
</div>
<?php get_footer();?>