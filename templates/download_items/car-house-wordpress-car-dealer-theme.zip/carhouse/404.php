<?php
// Displaying header
get_header();
global $carhouse;


// Displaying single page banner
?>
	<div class="page-content-404">
		<div class="container">
			<div class="col-lg-12 col-md-12 c0p-sm-12 col-xs-12">
				<div class="error-404">
					<img src="<?php echo get_template_directory_uri()?>/assets/img/png/mac.png" class="img-responsive" alt="mac">
					<div class="e404">
						<h1><?php echo esc_attr(404, 'carhouse');?></h1>
						<div class="title-error"><?php echo esc_attr($carhouse['opt_default_404_title']);?></div>
						<p class="visible-lg visible-md"><?php echo esc_attr($carhouse['opt_default_404_subtitle']);?></p>
					</div>

					<a class="btn btn-back" href="<?php echo site_url();?>"><?php echo esc_attr__('Get me back to homepage', 'carhouse')?></a>
				</div>
			</div>
		</div>
	</div>
<?php get_footer();?>