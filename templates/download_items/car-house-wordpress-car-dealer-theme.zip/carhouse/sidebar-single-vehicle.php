<div class="listing-sidebar">
    <?php
    if(is_active_sidebar('single_vehicle_widget')){
        dynamic_sidebar('single_vehicle_widget');
    }
    ?>
</div>