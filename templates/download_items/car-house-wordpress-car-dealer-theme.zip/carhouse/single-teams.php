<?php
global $carhouse;
// Displaying header
get_header();

// Displaying single page banner
get_template_part('elements/banner-single');
?>
    <div class="container">
        <?php while ( have_posts() ) : the_post();?>
        <div class="col-lg-10 col-lg-offset-1">
            <div <?php post_class();?>>
                <div class="agent-box-big clearfix">
                    <div class="row">
                        <div class="col-lg-5 col-md-5 col-sm-5 agent-box-theme agent-theme">
                            <?php
                            $memberName = get_the_title();
                            $image = array_values(rwmb_meta('member_image', ['size' => 'team-member-photo'], get_the_ID()));
                            if(sizeof($image) > 0){
                                $memberImg = $image[0]['url'];
                            } else {
                                global $carhouse;
                                $vehicleDummy = $carhouse['opt_default_profile_image']['url'];
                                $memberImg = $vehicleDummy;
                            }
                            ?>
                            <img src='<?php echo esc_url($memberImg);?>' alt='<?php esc_attr($memberName);?>' class='img-responsive'>
                        </div>
                        <div class="col-lg-7 col-md-7 col-sm-7 agent-content">
                            <h1 class="title">
                                <a href="<?php echo esc_url(get_permalink());?>"><?php echo esc_attr($memberName);?></a>
                            </h1>
                            <hr>
                            <!-- Address list -->
                            <ul class="address-list">
                                <li>
                                <span>
                                    <i class="fa fa-tag"></i>Name:
                                </span>
                                    <a href="<?php echo esc_url(get_permalink());?>"><?php echo esc_attr($memberName);?></a>
                                </li>
                                <li>
                                <span>
                                    <i class="fa fa-envelope"></i>Email:
                                </span>
                                    <?php echo esc_attr(get_post_meta(get_the_ID(), 'member_email', true) ? get_post_meta(get_the_ID(), 'member_email', true) : 'N/A')?>
                                </li>
                                <li>
                                <span>
                                    <i class="fa fa-phone"></i>Phone:
                                </span>
                                    <?php echo esc_attr(get_post_meta(get_the_ID(), 'member_phone', true) ? get_post_meta(get_the_ID(), 'member_phone', true) : 'N/A')?>
                                </li>
                                <li>
                                <span>
                                    <i class="fa fa-globe"></i>Website:
                                </span>
                                    <?php echo esc_attr(get_post_meta(get_the_ID(), 'member_website', true) ? get_post_meta(get_the_ID(), 'member_website', true) : 'N/A')?>
                                </li>
                                <li>
                                <span>
                                    <i class="fa fa-skype"></i>Skype:
                                </span>
                                    <?php echo esc_attr(get_post_meta(get_the_ID(), 'member_skype', true) ? get_post_meta(get_the_ID(), 'member_skype', true) : 'N/A')?>
                                </li>
                            </ul>

                            <p class="hidden-sm">
                                <?php
                                echo get_post_meta(get_the_ID(), 'member_intro', true);
                                ?>
                            </p>

                            <!-- social list -->
                            <ul class="social-list clearfix">
                                <?php if(get_post_meta(get_the_ID(), 'member_facebook', true)):?>
                                    <li>
                                        <a href="<?php echo esc_attr(get_post_meta(get_the_ID(), 'member_facebook', true) ? get_post_meta(get_the_ID(), 'member_facebook', true) : '#'); ?>" class="facebook">
                                            <i class="fa fa-facebook"></i>
                                        </a>
                                    </li>
                                <?php endif;?>
                                <?php if(get_post_meta(get_the_ID(), 'member_twitter', true)):?>
                                    <li>
                                        <a href="<?php echo esc_attr(get_post_meta(get_the_ID(), 'member_twitter', true) ? get_post_meta(get_the_ID(), 'member_twitter', true) : '#'); ?>" class="twitter">
                                            <i class="fa fa-twitter"></i>
                                        </a>
                                    </li>
                                <?php endif;?>
                                <?php if(get_post_meta(get_the_ID(), 'member_linkedin', true)):?>
                                    <li>
                                        <a href="<?php echo esc_attr(get_post_meta(get_the_ID(), 'member_linkedin', true) ? get_post_meta(get_the_ID(), 'member_linkedin', true) : '#'); ?>" class="linkedin">
                                            <i class="fa fa-linkedin"></i>
                                        </a>
                                    </li>
                                <?php endif;?>
                                <?php if(get_post_meta(get_the_ID(), 'member_gplud', true)):?>
                                    <li>
                                        <a href="<?php echo esc_attr(get_post_meta(get_the_ID(), 'member_gplud', true) ? get_post_meta(get_the_ID(), 'member_gplud', true) : '#'); ?>" class="google">
                                            <i class="fa fa-google-plus"></i>
                                        </a>
                                    </li>
                                <?php endif;?>
                                <?php if(get_post_meta(get_the_ID(), 'member_vimeo', true)):?>
                                    <li>
                                        <a href="<?php echo esc_attr(get_post_meta(get_the_ID(), 'member_vimeo', true) ? get_post_meta(get_the_ID(), 'member_vimeo', true) : '#'); ?>" class="rss">
                                            <i class="fa fa-vimeo"></i>
                                        </a>
                                    </li>
                                <?php endif;?>
                            </ul>
                            <hr class="hidden-sm hidden-xs">
                            <!-- btn -->
                        </div>
                    </div>
                </div>
                <div class="page_dynamic_content">
                    <?php echo the_content(); ?>
                </div>
                <br/>
                <br/>
            </div>
        </div>
        <?php endwhile;?>
        <div class="clearfix"></div>
    </div>
<?php get_footer();?>