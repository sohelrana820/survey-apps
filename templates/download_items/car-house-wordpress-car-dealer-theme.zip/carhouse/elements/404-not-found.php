<?php global $carhouse;?>
<div class="error-404">
    <div class="e404">
        <!--<h1>NOT FOUND</h1>-->
        <div class="title-error"><?php echo esc_attr($carhouse['opt_default_404_title']);?></div>
        <p class="visible-lg visible-md"><?php echo esc_attr($carhouse['opt_default_404_subtitle']);?></p>
    </div>
</div>