<div class="thumbnail car-box single-car-box">
    <div <?php post_class();?>>
        <a href="#" class="sale">
            <span><?php echo esc_attr(ucfirst(get_post_meta(get_the_ID(), 'vehicle_for', true)))?></span>
        </a>
        <?php
        global $carhouse;
        $image = array_values(rwmb_meta( 'vehicle_main_image',['size' => 'vehicle-details-image'], get_the_ID()));
        $title = the_title('', '', false);

        $alt = null;
        if (!$alt && isset($image[0]) && $image[0]['alt'] != '') {
            $alt = $image[0]['alt'];
        } elseif (!$alt && isset($image[0]) && $image[0]['title'] != '') {
            $alt = $image[0]['title'];
        }elseif (!$alt && isset($image[0]) && $image[0]['caption'] != '') {
            $alt = $image[0]['caption'];
        } else {
            $alt = $title;
        }

        if(sizeof($image) > 0){
            $vehicleImg = $image[0]['url'];
        } else {
            $vehicleImg = $carhouse['opt_default_vehicle_image']['url'];
        }
        ?>
        <div class="car-grid-thumb-area">
            <img src='<?php echo esc_url($vehicleImg)?>' alt='<?php echo esc_attr($alt);?>'>
            <?php if(isset($carhouse['opt_default_compare_page']) && $carhouse['opt_default_compare_page']):?>
                <div class="pull-right compare-btns">
                    <a class="btn details-button-2 add_compare show_it" data-id="<?php echo get_the_ID()?>">Add to Compare</a>
                    <a class="btn details-button-2 remove_compare hide_it" data-id="<?php echo get_the_ID()?>">Remove From Compare</a>
                </div>
            <?php endif;?>
        </div>

        <div class="caption car-content">
            <div class="header b-items-cars-one-info-header s-lineDownLeft">
                <h3>
                    <a href="<?php echo esc_url(get_permalink())?>"><?php echo wp_html_excerpt($title, 25, '...')?></a>
                    <span><?php echo esc_attr($carhouse['opt_default_currency']);?><?php echo esc_attr(number_format(get_post_meta(get_the_ID(), 'vehicle_sale_price', true), 2))?></span>
                </h3>
            </div>
            <p>
                <?php  echo wp_html_excerpt(get_post_meta(get_the_ID(), 'vehicle_short_description', true), 95, '...')?>
            </p>
            <div class="car-tags">
                <ul>
                    <?php
                    $year = get_post_meta(get_the_ID(), 'vehicle_manufacture_year', true);
                    echo $year ? '<li>'.esc_attr($year).'</li>' : '';

                    $brand = rwmb_meta( 'vehicle_brand',[], get_the_ID());
                    if(isset($brand->name)) {
                        echo '<li>'.esc_attr($brand->name).'</li>';
                    }

                    $category = rwmb_meta( 'vehicle_category',[], get_the_ID());
                    if(isset($category->name)) {
                        echo '<li>'.esc_attr($category->name).'</li>';
                    }

                    $mileage = get_post_meta(get_the_ID(), 'vehicle_miles', true);
                    echo $mileage ? '<li>'.esc_attr($mileage).' ml</li>' : '';

                    ?>
                </ul>
            </div>
            <!--<div class="ster-fa">
                <i class="fa fa-star orange-color"></i>
                <i class="fa fa-star orange-color"></i>
                <i class="fa fa-star orange-color"></i>
                <i class="fa fa-star orange-color"></i>
                <i class="fa fa-star-o orange-color"></i>
            </div>-->
            <a href="<?php echo esc_url(get_permalink())?>" class="btn details-button-2 pull-left"><?php echo esc_attr($carhouse['opt_default_listing_details_button']  );?></a>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<div class="clearfix"></div>