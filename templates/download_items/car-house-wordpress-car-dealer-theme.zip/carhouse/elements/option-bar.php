<?php
global $carhouse;
global $wp;
$currentPage = home_url(add_query_arg(array(),$wp->request));

$view = strtolower(get_field('listing_view'));
if(!$view) {
    $view = strtolower($carhouse['opt_default_listing_view']);
}

if(isset($_GET['view'])){
    $view = $_GET['view'];
}

?>
<div class="option-bar">
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6">
            <div class="section-heading">
                <i class="fa fa-car"></i>
                <h2><?php echo esc_attr($carhouse['opt_default_listing_title'])?></h2>
                <div class="border"></div>
                <h4><?php echo esc_attr($carhouse['opt_default_listing_subtitle'])?></h4>
            </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 text-right">
            <div class="sorting-options">
                <select class="sorting" onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
                    <option> Sort By</option>
                    <option value="<?php echo esc_url($currentPage) . '?'. http_build_query(array_merge($_GET, array('sort' => 'price', 'order' => 'desc')));?>">Price: High to low</option>
                    <option value="<?php echo esc_url($currentPage) . '?'. http_build_query(array_merge($_GET, array('sort' => 'price', 'order' => 'asc')));?>">Price: Low to high</option>
                    <option value="<?php echo esc_url($currentPage) . '?'. http_build_query(array_merge($_GET, array('sort' => 'date', 'order' => 'desc')));?>">Date: Newest</option>
                    <option value="<?php echo esc_url($currentPage) . '?'. http_build_query(array_merge($_GET, array('sort' => 'date', 'order' => 'asc')));?>">Date: Oldest</option>
                </select>
                <a href="<?php echo esc_url($currentPage) . '?'. http_build_query(array_merge($_GET, array('view' => 'list')));?>" class="change-view-btn <?php if($view != 'grid') {echo esc_attr__('active-view-btn', 'carhouse');}?>"><i class="fa fa-th-list"></i></a>
                <a href="<?php echo esc_url($currentPage) . '?'. http_build_query(array_merge($_GET, array('view' => 'grid')));?>" class="change-view-btn <?php if($view == 'grid') {echo esc_attr__('active-view-btn', 'carhouse');}?>"><i class="fa fa-th-large"></i></a>
            </div>
        </div>
    </div>
</div>