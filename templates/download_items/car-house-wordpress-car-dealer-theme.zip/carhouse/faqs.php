<?php
/*
Template Name: FAQs (Faq page layout)
*/
?>

<?php
global $carhouse;
// Displaying header
get_header();

// Displaying single page banner
get_template_part('elements/banner-single');
?>

<div class="container">
    <?php while ( have_posts() ) : the_post(); ?>
        <div <?php post_class();?>>
            <?php echo the_content();?>
        </div>
    <?php endwhile; ?>
</div>

<div class="about-body">
    <?php
    $query = array(
        'post_type' => 'faqs',
        'post_status' => 'publish'
    );
    $faqs = new WP_Query($query);
    ?>
    <div class="">
        <div class="container">
            <?php if($faqs->post_count > 0):?>
                <div class="title title-area">
                    <h2 class="h2-title"><?php echo esc_attr(get_field('faqs_title_text'));?></h2>
                    <hr/>
                </div>
                <div class="clearfix"></div>
                <div class="faq-area">
                    <?php
                    while($faqs->have_posts()) : $faqs->the_post();
                        $uniqueId = get_the_ID() . '-' . uniqid();
                        ?>
                        <div <?php post_class();?>>
                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="headingTwo">
                                    <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#<?php echo esc_attr($uniqueId);?>" aria-expanded="false" aria-controls="collapseTwo">
                                            <i class="fa fa"></i> <?php echo esc_attr(the_title());?>
                                        </a>
                                    </h4>
                                </div>
                                <div id="<?php echo esc_attr($uniqueId);?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo" aria-expanded="false">
                                    <div class="panel-body">
                                        <?php echo the_content();?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile;wp_reset_postdata(); ?>
                </div>
            <?php else:?>
                <div class="error-404">
                    <div class="e404">
                        <div class="title-error">FAQ is Empty</div>
                        <p class="visible-lg visible-md">Sorry, No faqs were found.</p>
                    </div>
                </div>
                <br/><br/>
            <?php endif;?>
        </div>
    </div>
</div>
<?php get_footer();?>