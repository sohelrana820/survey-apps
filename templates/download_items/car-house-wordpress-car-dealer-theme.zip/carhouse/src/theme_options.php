<?php
/**
 * ReduxFramework Sample Config File
 * For full documentation, please visit: http:///docs.reduxframework.com/
 */

if (!class_exists('Redux')) {
    return;
}


// This is your option name where all the Redux data is stored.
$opt_name = "carhouse";

// This line is only for altering the demo. Can be easily removed.
$opt_name = apply_filters('redux_demo/opt_name', 'carhouse');

/*
 *
 * --> Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
 *
 */

$sampleHTML = '';
if (file_exists(dirname(__FILE__) . '/info-html.html')) {
    Redux_Functions::initWpFilesystem();

    global $wp_filesystem;

    $sampleHTML = $wp_filesystem->get_contents(dirname(__FILE__) . '/info-html.html');
}

// Background Patterns Reader
$sample_patterns_path = ReduxFramework::$_dir . '../sample/patterns/';
$sample_patterns_url = ReduxFramework::$_url . '../sample/patterns/';
$sample_patterns = array();

if (is_dir($sample_patterns_path)) {

    if ($sample_patterns_dir = opendir($sample_patterns_path)) {
        $sample_patterns = array();

        while (($sample_patterns_file = readdir($sample_patterns_dir)) !== false) {

            if (stristr($sample_patterns_file, '.png') !== false || stristr($sample_patterns_file, '.jpg') !== false) {
                $name = explode('.', $sample_patterns_file);
                $name = str_replace('.' . end($name), '', $sample_patterns_file);
                $sample_patterns[] = array(
                    'alt' => $name,
                    'img' => $sample_patterns_url . $sample_patterns_file
                );
            }
        }
    }
}

/**
 * ---> SET ARGUMENTS
 * All the possible arguments for Redux.
 * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
 * */

$theme = wp_get_theme(); // For use with some settings. Not necessary.

$args = array(
    // TYPICAL -> Change these values as you need/desire
    'opt_name' => $opt_name,
    // This is where your data is stored in the database and also becomes your global variable name.
    'display_name' => $theme->get('Name'),
    // Name that appears at the top of your panel
    'display_version' => $theme->get('Version'),
    // Version that appears at the top of your panel
    'menu_type' => 'menu',
    //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
    'allow_sub_menu' => true,
    // Show the sections below the admin menu item or not
    'menu_title' => __('Theme Options', 'carhouse'),
    'page_title' => __('Theme Options', 'carhouse'),
    // You will need to generate a Google API key to use this feature.
    // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
    'google_api_key' => '',
    // Set it you want google fonts to update weekly. A google_api_key value is required.
    'google_update_weekly' => false,
    // Must be defined to add google fonts to the typography module
    'async_typography' => true,
    // Use a asynchronous font on the front end or font string
    //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
    'admin_bar' => true,
    // Show the panel pages on the admin bar
    'admin_bar_icon' => 'dashicons-portfolio',
    // Choose an icon for the admin bar menu
    'admin_bar_priority' => 50,
    // Choose an priority for the admin bar menu
    'global_variable' => '',
    // Set a different name for your global variable other than the opt_name
    'dev_mode' => false,
    // Show the time the page took to load, etc
    'update_notice' => false,
    // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
    'customizer' => true,
    // Enable basic customizer support
    //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
    //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

    // OPTIONAL -> Give you extra features
    'page_priority' => 26,
    // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
    'page_parent' => 'themes.php',
    // For a full list of options, visit: http:///codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
    'page_permissions' => 'manage_options',
    // Permissions needed to access the options panel.
    'menu_icon' => 'dashicons-welcome-widgets-menus',
    // Specify a custom URL to an icon
    'last_tab' => '',
    // Force your panel to always open to a specific tab (by id)
    'page_icon' => 'icon-themes',
    // Icon displayed in the admin panel next to your menu_title
    'page_slug' => '',
    // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
    'save_defaults' => true,
    // On load save the defaults to DB before user clicks save or not
    'default_show' => false,
    // If true, shows the default value next to each field that is not the default value.
    'default_mark' => '',
    // What to print by the field's title if the value shown is default. Suggested: *
    'show_import_export' => true,
    // Shows the Import/Export panel when not used as a field.

    // CAREFUL -> These options are for advanced use only
    'transient_time' => 60 * MINUTE_IN_SECONDS,
    'output' => true,
    // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
    'output_tag' => true,
    // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
    // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

    // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
    'database' => '',
    // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
    'use_cdn' => true,
    // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

    // HINTS
    'hints' => array(
        'icon' => 'el el-question-sign',
        'icon_position' => 'right',
        'icon_color' => 'lightgray',
        'icon_size' => 'normal',
        'tip_style' => array(
            'color' => 'red',
            'shadow' => true,
            'rounded' => false,
            'style' => '',
        ),
        'tip_position' => array(
            'my' => 'top left',
            'at' => 'bottom right',
        ),
        'tip_effect' => array(
            'show' => array(
                'effect' => 'slide',
                'duration' => '500',
                'event' => 'mouseover',
            ),
            'hide' => array(
                'effect' => 'slide',
                'duration' => '500',
                'event' => 'click mouseleave',
            ),
        ),
    )
);

// ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.
$args['admin_bar_links'][] = array(
    'id' => 'redux-docs',
    'href' => 'http:///docs.reduxframework.com/',
    'title' => __('Documentation', 'carhouse'),
);

$args['admin_bar_links'][] = array(
    //'id'    => 'redux-support',
    'href' => 'https://github.com/ReduxFramework/redux-framework/issues',
    'title' => __('Support', 'carhouse'),
);

$args['admin_bar_links'][] = array(
    'id' => 'redux-extensions',
    'href' => 'reduxframework.com/extensions',
    'title' => __('Extensions', 'carhouse'),
);

// SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
$args['share_icons'][] = array(
    'url' => 'https://github.com/sohelrana820',
    'title' => 'Visit me on GitHub',
    'icon' => 'el el-github'
    //'img'   => '', // You can use icon OR img. IMG needs to be a full URL.
);
$args['share_icons'][] = array(
    'url' => 'https://www.facebook.com/sohelrana820',
    'title' => 'Like me on Facebook',
    'icon' => 'el el-facebook'
);
$args['share_icons'][] = array(
    'url' => 'http:///twitter.com/me_sohelrana',
    'title' => 'Follow me on Twitter',
    'icon' => 'el el-twitter'
);
$args['share_icons'][] = array(
    'url' => 'https://www.linkedin.com/in/sohel-rana-a18a0228/',
    'title' => 'Find me on LinkedIn',
    'icon' => 'el el-linkedin'
);

// Panel Intro text -> before the form
if (!isset($args['global_variable']) || $args['global_variable'] !== false) {
    if (!empty($args['global_variable'])) {
        $v = $args['global_variable'];
    } else {
        $v = str_replace('-', '_', $args['opt_name']);
    }
    $args['intro_text'] = sprintf(__('', 'carhouse'), $v);
} else {
    $args['intro_text'] = __('<p>', 'carhouse');
}

// Add content after the form.
$args['footer_text'] = __('', 'carhouse');

Redux::setArgs('carhouse', $args);

/*
 * ---> END ARGUMENTS
 */


/*
 * ---> START HELP TABS
 */

$tabs = array(
    array(
        'id' => 'redux-help-tab-1',
        'title' => __('Theme Information 1', 'carhouse'),
        'content' => __('<p>This is the tab content, HTML is allowed.</p>', 'carhouse')
    ),
    array(
        'id' => 'redux-help-tab-2',
        'title' => __('Theme Information 2', 'carhouse'),
        'content' => __('<p>This is the tab content, HTML is allowed.</p>', 'carhouse')
    )
);
Redux::setHelpTab('carhouse', $tabs);

// Set the help sidebar
$content = __('<p>This is the sidebar content, HTML is allowed.</p>', 'carhouse');
Redux::setHelpSidebar('carhouse', $content);


/*
 * <--- END HELP TABS
 */


/*
 *
 * ---> START SECTIONS
 *
 */

/*

    As of Redux 3.5+, there is an extensive API. This API can be used in a mix/match mode allowing for


 */

// -> START Basic Fields
Redux::setSection('carhouse', array(
    'title' => __('General', 'carhouse'),
    'id' => 'theme_settings',
    'desc' => __('General configuration of carhouse theme', 'carhouse'),
    'customizer_width' => '400px',
    'icon' => 'el el-home',
    'fields' => array(
        array(
            'title' => __('Site Title', 'carhouse'),
            'id' => 'opt_site_title',
            'type' => 'text',
            'default' => get_bloginfo('name'),
        ),
        array(
            'title' => __('Number of Vehicle Display in Homepage', 'carhouse'),
            'id' => 'opt_vehicle_per_page_in_home_page',
            'type' => 'select',
            'options' => array(
                '3' => '3',
                '6' => '6',
                '9' => '9',
                '12' => '12',
                '15' => '15'
            ),
            'default' => __('6', 'carhouse'),
        ),
        array(
            'title' => __('Banner Title', 'carhouse'),
            'id' => 'opt_default_banner_title',
            'desc' => __('Default text for banner title', 'carhouse'),
            'type' => 'text',
            'default' => __('Banner Title', 'carhouse'),
            'placeholder' => __('Banner Title', 'carhouse')
        ),
        array(
            'title' => __('Banner Subtitle', 'carhouse'),
            'id' => 'opt_default_banner_subtitle',
            'desc' => __('Default text for banner subtitle', 'carhouse'),
            'type' => 'text',
            'default' => __('Banner Subtitle', 'carhouse'),
            'placeholder' => __('Banner Subtitle', 'carhouse')
        ),
        array(
            'title' => __('Vehicle Not Found Text (Title)', 'carhouse'),
            'id' => 'opt_default_not_found_title',
            'desc' => __('This message will display when vehicle search result is empty', 'carhouse'),
            'type' => 'text',
            'default' => __('Not Found', 'carhouse'),
            'placeholder' => __('Not Found Title Text', 'carhouse')
        ),
        array(
            'title' => __('Vehicle Not Found Text (Subtitle)', 'carhouse'),
            'id' => 'opt_default_not_found_subtitle',
            'desc' => __('This message will display when vehicle search result is empty', 'carhouse'),
            'type' => 'text',
            'default' => __('Sorry, No vehicles were found matching your selection.', 'carhouse'),
            'placeholder' => __('Not Found Subtitle Text', 'carhouse')
        ),
        array(
            'title' => __('404 Text (Title)', 'carhouse'),
            'id' => 'opt_default_404_title',
            'type' => 'text',
            'default' => __('Page Not Found!', 'carhouse'),
            'placeholder' => __('404 Title Text', 'carhouse')
        ),
        array(
            'title' => __('404 Text (Subtitle)', 'carhouse'),
            'id' => 'opt_default_404_subtitle',
            'type' => 'text',
            'default' => __('The page you are looking for was moved, removed, renamed<br>or might never existed. You stumbled upon a broken link', 'carhouse'),
            'placeholder' => __('404 Subtitle Text', 'carhouse')
        ),
        /*array(
            'id'       => 'opt_default_enable_compare',
            'type'     => 'checkbox',
            'title'    => __('Enable Vehicle Comparison?', 'carhouse'),
            'subtitle' => __('If you want to enable vehicle comparison, checked it', 'carhouse'),
            'default'  => '0'// 1 = on | 0 = off
        ),*/
        array(
            'id'       => 'opt_default_compare_page',
            'type'     => 'select',
            'multi'    => false,
            'data'     => 'posts',
            'args'     => array(
                'post_type'  => 'page',
                'meta_key' => '_wp_page_template',
                'meta_value' => 'compare.php'
            ),
            'title'    => __( 'Vehicle Comparison Page', 'carhouse' ),
            'subtitle' => __( 'Please select the vehicle comparison page. If you don\'t select the compare page, then it will not work', 'carhouse' ),
        ),
    )
));

Redux::setSection('carhouse', array(
    'title' => __('Header', 'carhouse'),
    'id' => 'theme_header_setting',
    'icon' => 'el el-leaf',
    'desc' => __('These are the options for the header', 'carhouse'),
    'fields' => array(
        array(
            'title' => __('Logo', 'carhouse'),
            'id' => 'opt_header_logo',
            'type' => 'media',
            'desc' => __('Change header logo', 'carhouse'),
            'default' => array(
                'url' => get_template_directory_uri() . '/assets/img/png/logo.png'
            )
        ),
        array(
            'title' => __('Facivon', 'carhouse'),
            'id' => 'opt_header_favicon',
            'type' => 'media',
            'desc' => __('Change Favicon Icon', 'carhouse'),
            'default' => array(
                'url' => get_template_directory_uri() . '/assets/favicon.ico'
            )
        ),
        array(
            'title' => __('Phone No', 'carhouse'),
            'id' => 'opt_header_phone',
            'type' => 'text',
            'default' => __('XXXXXXXX', 'carhouse')
        ),
        array(
            'title' => __('Email', 'carhouse'),
            'id' => 'opt_header_email',
            'type' => 'text',
            'default' => __('info@example.com', 'carhouse')
        ),
    )
));

Redux::setSection('carhouse', array(
    'title' => __('Footer', 'carhouse'),
    'id' => 'theme_footer_settings',
    'icon' => 'el el-bullhorn',
    'desc' => __('These are the options for the footer', 'carhouse'),
    'fields' => array(
        array(
            'title' => __('Copyright Text', 'carhouse'),
            'id' => 'opt_footer_copyright_text',
            'type' => 'text',
            'default' => __('&copy; 2017 - All Rights Reserved', 'carhouse')
        ), array(
            'title' => __('Google Analytic Tracking ID', 'carhouse'),
            'id' => 'opt_analytic_tracking_id',
            'type' => 'text',
            'placeholder' => __('UA-000000-2', 'carhouse')
        ),
    )
));

Redux::setSection('carhouse', array(
    'title' => __('Default Images', 'carhouse'),
    'id' => 'theme_default_image_settings',
    'icon' => 'el el-camera',
    'desc' => __('These are the options theme default images', 'carhouse'),
    'fields' => array(
        array(
            'title' => __('Single Banner Image', 'carhouse'),
            'desc' => __('Set default image of single banner', 'carhouse'),
            'id' => 'opt_default_single_banner_image',
            'type' => 'media',
            'preview' => 'full',
            'default' => array(
                'url' => get_template_directory_uri() . '/assets/img/banner-slider-01.jpg'
            )
        ),
        array(
            'title' => __('Blog Featured Image', 'carhouse'),
            'id' => 'opt_default_featured_image',
            'type' => 'media',
            'desc' => __('Change default featured image', 'carhouse'),
            'default' => array(
                'url' => get_template_directory_uri() . '/assets/img/default-featured.jpg'
            )
        ),
        array(
            'title' => __('Vehicle Image', 'carhouse'),
            'id' => 'opt_default_vehicle_image',
            'type' => 'media',
            'desc' => __('Change default vehicle image', 'carhouse'),
            'default' => array(
                'url' => get_template_directory_uri() . '/assets/img/vehicle-dummy.jpg'
            )
        ),
        array(
            'title' => __('Profile Image', 'carhouse'),
            'id' => 'opt_default_profile_image',
            'type' => 'media',
            'desc' => __('Change default profile image', 'carhouse'),
            'default' => array(
                'url' => get_template_directory_uri() . '/assets/img/profile-dummy.png'
            )
        ),
        array(
            'title' => __('Page Loading Image', 'carhouse'),
            'id' => 'opt_default_page_loader',
            'type' => 'media',
            'desc' => __('Change default profile image', 'carhouse'),
            'default' => array(
                'url' => get_template_directory_uri() . '/assets/img/loader.gif'
            )
        ),
    )
));

Redux::setSection('carhouse', array(
    'title' => __('Listing', 'carhouse'),
    'id' => 'theme_listing_setting',
    'icon' => 'el el-car',
    'desc' => __('Configure your default setting of listing', 'carhouse'),
    'fields' => array(
        array(
            'title' => __('Number of Vehicle Per Page', 'carhouse'),
            'id' => 'opt_vehicle_per_page_in_listing_page',
            'type' => 'select',
            'options' => array(
                '4' => '4',
                '6' => '6',
                '8' => '8',
                '10' => '10',
                '12' => '12',
                '14' => '14',
                '16' => '16',
                '18' => '18',
                '20' => '20'
            ),
            'default' => '6',
        ),
        array(
            'title' => __('Listing Title', 'carhouse'),
            'id' => 'opt_default_listing_title',
            'desc' => __('Write default text of listing title', 'carhouse'),
            'type' => 'text',
            'default' => __('Recent Vehicles', 'carhouse'),
            'placeholder' => __('Listing Title', 'carhouse')
        ),
        array(
            'title' => __('Listing Subtitle', 'carhouse'),
            'id' => 'opt_default_listing_subtitle',
            'desc' => __('Write default text of listing subtitle', 'carhouse'),
            'type' => 'text',
            'default' => __('Check our recent motor', 'carhouse'),
            'placeholder' => __('Listing Subtitle', 'carhouse')
        ),
        array(
            'title' => __('Default Listing View', 'carhouse'),
            'id' => 'opt_default_listing_view',
            'type' => 'select',
            'options' => array(
                'Grid' => 'Grid',
                'List' => 'List',
            ),
            'default' => __('List', 'carhouse'),
        ),
        array(
            'title' => __('Sidebar Position', 'carhouse'),
            'id' => 'opt_default_listing_sidebar_position',
            'type' => 'select',
            'options' => array(
                'Left' => 'Left',
                'Right' => 'Right',
            ),
            'default' => __('Right', 'carhouse'),
        ),
        array(
            'title' => __('Currency', 'carhouse'),
            'id' => 'opt_default_currency',
            'type' => 'text',
            'default' => __('$', 'carhouse'),
        ),
        array(
            'title' => __('Vehicle Mileage Unit', 'carhouse'),
            'id' => 'opt_default_mileage_unit',
            'type' => 'select',
            'options' => array(
                'MPG' => 'MPG',
                'km/L' => 'km/L',
                'L/100 km' => 'L/100 km',
            ),
            'default' => __('km/L', 'carhouse'),
        ),
        array(
            'title' => __('Vehicle Mile Unit', 'carhouse'),
            'id' => 'opt_default_mile_unit',
            'type' => 'select',
            'options' => array(
                'ml' => 'ml',
                'mi' => 'mi',
                'M' => 'M',
            ),
            'default' => __('ml', 'carhouse'),
        ),
        array(
            'title' => __('Vehicle Speed Unit', 'carhouse'),
            'id' => 'opt_default_speed_unit',
            'type' => 'select',
            'options' => array(
                'km/h' => 'km/h',
                'mph' => 'mi/h or mph',
            ),
            'default' => __('km/h', 'carhouse'),
        ),
        array(
            'title' => __('Search Box Title', 'carhouse'),
            'id' => 'opt_default_listing_search_box_title',
            'type' => 'text',
            'placeholder' => __('Search Box Title', 'carhouse'),
            'default' => __('Search Vehicle', 'carhouse'),
        ),
        array(
            'title' => __('Search Box Subtitle', 'carhouse'),
            'id' => 'opt_default_listing_search_box_subtitle',
            'type' => 'text',
            'placeholder' => __('Search Box Subtitle', 'carhouse'),
            'default' => __('Search your desire car', 'carhouse'),
        ),
        array(
            'title' => __('Criteria Text', 'carhouse'),
            'id' => 'opt_default_listing_search_box_criteria',
            'type' => 'text',
            'placeholder' => __('Criteria Text', 'carhouse'),
            'default' => __('Criteria', 'carhouse'),
        ),
        array(
            'title' => __('Name Text', 'carhouse'),
            'id' => 'opt_default_listing_search_box_vehicle_title',
            'type' => 'text',
            'placeholder' => __('Type Name', 'carhouse'),
            'default' => __('Vehicle Name', 'carhouse'),
        ),
        array(
            'title' => __('Choose Fuel Text', 'carhouse'),
            'id' => 'opt_default_listing_search_box_choose_fuel',
            'type' => 'text',
            'placeholder' => __('Choose Fuel Text', 'carhouse'),
            'default' => __('Choose Fuel', 'carhouse'),
        ),
        array(
            'title' => __('Choose Transmission Text', 'carhouse'),
            'id' => 'opt_default_listing_search_box_choose_transmission',
            'type' => 'text',
            'placeholder' => __('Choose Transmission Text', 'carhouse'),
            'default' => __('Choose Transmission', 'carhouse'),
        ),
        array(
            'title' => __('Choose Condition Text', 'carhouse'),
            'id' => 'opt_default_listing_search_box_choose_condition',
            'type' => 'text',
            'placeholder' => __('Choose Condition Text', 'carhouse'),
            'default' => __('Choose Condition', 'carhouse'),
        ),
        array(
            'title' => __('Manufacture Year Text', 'carhouse'),
            'id' => 'opt_default_listing_search_box_manufacture_year',
            'type' => 'text',
            'placeholder' => __('Manufacture Year Text', 'carhouse'),
            'default' => __('Manufacture Year', 'carhouse'),
        ),
        array(
            'title' => __('Price Text', 'carhouse'),
            'id' => 'opt_default_listing_search_box_price',
            'type' => 'text',
            'placeholder' => __('Price Text', 'carhouse'),
            'default' => __('Price', 'carhouse'),
        ),
        array(
            'title' => __('Brands Text', 'carhouse'),
            'id' => 'opt_default_listing_search_box_brand',
            'type' => 'text',
            'placeholder' => __('Brands Text', 'carhouse'),
            'default' => __('Brands', 'carhouse'),
        ),
        array(
            'title' => __('Category Text', 'carhouse'),
            'id' => 'opt_default_listing_search_box_category',
            'type' => 'text',
            'placeholder' => __('Category Text', 'carhouse'),
            'default' => __('Category', 'carhouse'),
        ),
        array(
            'title' => __('Search Button Text', 'carhouse'),
            'id' => 'opt_default_listing_search_btn_text',
            'type' => 'text',
            'placeholder' => __('Search Button Text', 'carhouse'),
            'default' => __('Search Vehicles', 'carhouse'),
        ),
        array(
            'title' => __('Reset Button Text', 'carhouse'),
            'id' => 'opt_default_listing_reset_btn_button',
            'type' => 'text',
            'placeholder' => __('Search Reset Text', 'carhouse'),
            'default' => __('Search Reset', 'carhouse'),
        ),
        array(
            'title' => __('Preview/Details Button Text', 'carhouse'),
            'id' => 'opt_default_listing_details_button',
            'type' => 'text',
            'placeholder' => __('Preview/Details Button Text', 'carhouse'),
            'default' => __('Details', 'carhouse'),
        ),
    )
));

Redux::setSection('carhouse', array(
    'title' => __('Blog', 'carhouse'),
    'id' => 'theme_blog_page_setting',
    'icon' => 'el el-blogger',
    'desc' => __('These are the options for the blog', 'carhouse'),
    'fields' => array(
        /*array(
            'title' => __('Post Per Page', 'carhouse'),
            'id' => 'post_per_blog_page',
            'type' => 'text',
            'default' => __(10)
        ),*/
        array(
            'title' => __('Blog Page Layout', 'carhouse'),
            'id' => 'blog_page_layout',
            'type' => 'select',
            'options' => array(
                'full_layout' => 'Full Layout',
                'left_sidebar' => 'Left Sidebar',
                'right_sidebar' => 'Right Sidebar',
            ),
            'default' => __('right_sidebar', 'carhouse'),
        ),
        array(
            'title' => __('Blog Page Title Text', 'carhouse'),
            'id' => 'blog_page_title',
            'type' => 'text',
            'placeholder' => __('Blog Page Title Text', 'carhouse'),
            'default' => __('Our Blog', 'carhouse')
        ),
        array(
            'title' => __('Blog Page Subtitle Text', 'carhouse'),
            'id' => 'blog_page_subtitle',
            'type' => 'text',
            'placeholder' => __('Blog Page Subtitle Text', 'carhouse'),
            'default' => __('Our Official Blog', 'carhouse')
        ),
        array(
            'title' => __('Blog Page Button Text', 'carhouse'),
            'id' => 'blog_page_button_text',
            'type' => 'text',
            'default' => __('Read More', 'carhouse')
        ),
        array(
            'title' => __('Show Share Icons', 'carhouse'),
            'id' => 'blog_page_visible_share_icon',
            'type' => 'select',
            'options' => array(
                'yes' => 'Yes',
                'no' => 'No',
            ),
            'default' => __('yes', 'carhouse'),
        ),
        array(
            'title' => __('Social Share Text', 'carhouse'),
            'id' => 'blog_page_share_text',
            'type' => 'text',
            'default' => __('Share', 'carhouse')
        ),
    )
));

Redux::setSection('carhouse', array(
    'title' => __('Sliders', 'carhouse'),
    'id' => 'theme_slider_settings',
    'icon' => 'el el-cog-alt',
    'desc' => 'These are the options for the slider',
    'fields' => array(
        array(
            'id' => 'opt-slides',
            'type' => 'slides',
            'title' => __('Slides Options', 'carhouse'),
            'subtitle' => __('Unlimited slides with drag and drop sortings.', 'carhouse'),
            'desc' => __('This field will store all slides values into a multidimensional array to use into a foreach loop.', 'carhouse'),
            'placeholder' => array(
                'title' => __('This is a title', 'carhouse'),
                'description' => __('Description Here', 'carhouse'),
                'url' => __('Give us a link!', 'carhouse'),
            ),
        ),
    )
));

Redux::setSection('carhouse', array(
    'title' => __('Custom Code Editor', 'carhouse'),
    'id' => 'code-editor',
    'icon' => 'el el-edit',
    'desc' => 'Customize your application look',
    'fields' => array(
        array(
            'id' => 'opt-theme-css-editor',
            'type' => 'ace_editor',
            'mode' => 'css',
            'title' => __('Custom CSS', 'carhouse'),
            'desc' => __('Write your own custom CSS', 'carhouse'),
        ),
        array(
            'id' => 'opt-theme-css-js',
            'type' => 'ace_editor',
            'mode' => 'jsvasccript',
            'title' => __('Custom JS', 'carhouse'),
            'desc' => __('Write your own custom JS', 'carhouse'),
        ),
    )
));

if (!function_exists('compiler_action')) {
    function compiler_action($options, $css, $changed_values)
    {
        echo '<h1>The compiler hook has run!</h1>';
        echo "<pre>";
        print_r($changed_values); // Values that have changed since the last save
        echo "</pre>";
        //print_r($options); //Option values
        //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )
    }
}

/**
 * Custom function for the callback validation referenced above
 * */
if (!function_exists('redux_validate_callback_function')) {
    function redux_validate_callback_function($field, $value, $existing_value)
    {
        $error = false;
        $warning = false;

        //do your validation
        if ($value == 1) {
            $error = true;
            $value = $existing_value;
        } elseif ($value == 2) {
            $warning = true;
            $value = $existing_value;
        }

        $return['value'] = $value;

        if ($error == true) {
            $field['msg'] = 'your custom error message';
            $return['error'] = $field;
        }

        if ($warning == true) {
            $field['msg'] = 'your custom warning message';
            $return['warning'] = $field;
        }

        return $return;
    }
}

/**
 * Custom function for the callback referenced above
 */
if (!function_exists('redux_my_custom_field')) {
    function redux_my_custom_field($field, $value)
    {
        print_r($field);
        echo '<br/>';
        print_r($value);
    }
}

/**
 * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
 * Simply include this function in the child themes functions.php file.
 * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
 * so you must use get_template_directory_uri() if you want to use any of the built in icons
 * */
if (!function_exists('dynamic_section')) {
    function dynamic_section($sections)
    {
        //$sections = array();
        $sections[] = array(
            'title' => __('Section via hook', 'carhouse'),
            'desc' => __('<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'carhouse'),
            'icon' => 'el el-paper-clip',
            // Leave this as a blank section, no options just some intro text set above.
            'fields' => array()
        );

        return $sections;
    }
}

/**
 * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
 * */
if (!function_exists('change_arguments')) {
    function change_arguments($args)
    {
        //$args['dev_mode'] = true;

        return $args;
    }
}

/**
 * Filter hook for filtering the default value of any given field. Very useful in development mode.
 * */
if (!function_exists('change_defaults')) {
    function change_defaults($defaults)
    {
        $defaults['str_replace'] = 'Testing filter hook!';

        return $defaults;
    }
}

/**
 * Removes the demo link and the notice of integrated demo from the redux-framework plugin
 */
if (!function_exists('remove_demo')) {
    function remove_demo()
    {
        // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
        if (class_exists('ReduxFrameworkPlugin')) {
            remove_filter('plugin_row_meta', array(
                ReduxFrameworkPlugin::instance(),
                'plugin_metalinks'
            ), null, 2);

            // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
            remove_action('admin_notices', array(ReduxFrameworkPlugin::instance(), 'admin_notices'));
        }
    }
}

