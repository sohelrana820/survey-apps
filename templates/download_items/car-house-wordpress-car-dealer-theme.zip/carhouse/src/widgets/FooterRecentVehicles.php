<?php

/**
 * Class FooterRecentVehicles
 */
class FooterRecentVehicles extends WP_Widget
{
    /**
     * FooterRecentVehicles constructor.
     */
    public function __construct()
    {
        $widget_details = array(
            'classname' => 'footer_recent_vehicle_widget',
            'description' => __('Footer Recent Vehicle Widget', 'carhouse')
        );

        parent::__construct('footer_recent_vehicle_widget', __('Car House: Recent Vehicle (Footer)', 'carhouse'), $widget_details);
    }


    /**
     * @param array $instance
     */
    public function form($instance)
    {
        $title = !empty($instance['title']) ? $instance['title'] : 'Recent Vehicles';
        $vehicleCount = !empty($instance['vehicle_count']) ? $instance['vehicle_count'] : 3;
        ?>
        <div class="widget_box">
            <div class="widget-field">
                <label><?php echo esc_attr__('Title', 'carhouse'); ?></label>
                <input class="widefat form-control" name="<?php echo $this->get_field_name('title'); ?>"
                       placeholder="<?php echo esc_attr__('Title', 'carhouse'); ?>" value="<?php echo esc_attr($title); ?>"/>
            </div>

            <div class="widget-field">
                <label><?php echo esc_attr__('Number of Vehicles to Show', 'carhouse'); ?></label>
                <input class="widefat form-control" name="<?php echo $this->get_field_name('vehicle_count'); ?>"
                       placeholder="<?php echo esc_attr__('Number of Vehicles to Show', 'carhouse'); ?>"
                       value="<?php echo $vehicleCount; ?>"/>
            </div>
        </div>
        <?php
    }

    /**
     * @param array $new_instance
     * @param array $old_instance
     * @return array
     */
    public function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        $instance['title'] = $new_instance['title'];
        $instance['vehicle_count'] = $new_instance['vehicle_count'];
        return $instance;
    }

    /**
     * @param array $args
     * @param array $instance
     */
    public function widget($args, $instance)
    {
        extract($args);
        $title = $instance['title'];
        $vehicleCount = $instance['vehicle_count'];
        $vehicles = getActiveVehicles($args = ['posts_per_page' => $vehicleCount]);
        echo $before_widget; ?>

        <div class="footer-item-content">
            <h2><?php echo esc_attr($title); ?></h2>
            <div class="line-dec"></div>
            <?php while ($vehicles->have_posts()): $vehicles->the_post(); ?>
                <div <?php post_class();?>>
                    <div class="media">
                        <div class="media-left">
                            <a href="<?php echo esc_url(get_permalink()) ?>">
                                <?php
                                $image = array_values(rwmb_meta('vehicle_main_image', [], get_the_ID()));
                                $vehicleName = the_title('"', '"', false);
                                if (sizeof($image) > 0) {
                                    echo "<img class='media-object' src='{$image[0]['url']}' alt='".$vehicleName."'>";
                                } else {
                                    global $carhouse;
                                    $vehicleDummy = $carhouse['opt_default_vehicle_image']['url'];
                                    echo "<img class='media-object' src='{$vehicleDummy}' alt='".$vehicleName."'>";
                                }
                                ?>
                            </a>
                        </div>
                        <div class="media-body">
                            <?php $title =  the_title('', '', false);?>
                            <a href="<?php echo esc_url(get_permalink()) ?>"><?php echo wp_carhouse_truncate_string($title, 20, '...') ?></a>
                            <div class="line-dec-o"></div>
                            <span>$<?php echo number_format(get_post_meta(get_the_ID(), 'vehicle_sale_price', true), 2) ?></span>
                        </div>
                    </div>
                </div>
            <?php endwhile;
            wp_reset_postdata(); ?>
        </div>
        <?php echo $after_widget;
    }
}