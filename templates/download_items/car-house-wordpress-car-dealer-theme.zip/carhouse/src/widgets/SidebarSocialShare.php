<?php

/**
 * Class SidebarSocialShare
 */
class SidebarSocialShare extends WP_Widget
{
    /**
     * SidebarSocialShare constructor.
     */
    public function __construct()
    {
        $widget_details = array(
            'classname' => 'sidebar_share_widget',
            'description' => __('Sidebar Social Share Widget', 'carhouse')
        );

        parent::__construct('sidebar_share_widget', __('Car House: Social Share (Sidebar)', 'carhouse'), $widget_details);
    }


    /**
     * @param array $instance
     */
    public function form($instance)
    {
        $title = !empty($instance['title']) ? $instance['title'] : 'Social Media Share';
        ?>
        <div class="widget_box">
            <div class="widget-field">
                <label><?php echo esc_attr__('Title', 'carhouse');?></label>
                <input class="widefat form-control" name="<?php echo $this->get_field_name('title'); ?>"
                       placeholder="<?php echo esc_attr__('Title', 'carhouse');?>" value="<?php echo esc_attr($title); ?>"/>
            </div>
        </div>
        <?php
    }

    /**
     * @param array $new_instance
     * @param array $old_instance
     * @return array
     */
    public function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        $instance['title'] = $new_instance['title'];
        return $instance;
    }

    /**
     * @param array $args
     * @param array $instance
     */
    public function widget($args, $instance)
    {
        extract($args);
        $title = $instance['title'];
        echo $before_widget; ?>

        <div class="share mrg-b-30">
            <h2><?php echo esc_attr($title);?></h2>
            <div class="clearfix"></div>
            <ul class="social-list">
                <li>
                    <a href="#" class="facebook">
                        <i class="fa fa-facebook"></i>
                    </a>
                </li>
                <li>
                    <a href="#" class="twitter">
                        <i class="fa fa-twitter"></i>
                    </a>
                </li>
                <li>
                    <a href="#" class="linkedin">
                        <i class="fa fa-linkedin"></i>
                    </a>
                </li>
                <li>
                    <a href="#" class="google">
                        <i class="fa fa-google-plus"></i>
                    </a>
                </li>
                <li>
                    <a href="#" class="rss">
                        <i class="fa fa-rss"></i>
                    </a>
                </li>
                <li>
                    <a href="#" class="vimeo">
                        <i class="fa fa-vimeo"></i>
                    </a>
                </li>
            </ul>
        </div>
        <div class="clearfix"></div>
        <?php echo $after_widget;
    }
}