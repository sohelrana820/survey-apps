<?php

/**
 * Class FooterShortDescription
 */
class FooterShortDescription extends WP_Widget
{
    /**
     * FooterShortDescription constructor.
     */
    public function __construct()
    {
        $widget_details = array(
            'classname' => 'footer_what_we_offer_widget',
            'description' => __('Footer Short Description Widget', 'carhouse')
        );

        parent::__construct('footer_what_we_offer_widget', __('Car House: What We Offer (Footer)', 'carhouse'), $widget_details);
    }


    /**
     * @param array $instance
     */
    public function form($instance)
    {
        $title = !empty($instance['title']) ? $instance['title'] : 'What We Offer';
        ?>
        <div class="widget_box">
            <div class="widget-field">
                <label><?php echo esc_attr__('Title', 'carhouse');?></label>
                <input class="widefat form-control" name="<?php echo $this->get_field_name('title'); ?>"
                       placeholder="<?php echo esc_attr__('Title', 'carhouse');?>" value="<?php echo esc_attr($title); ?>"/>
            </div>
            <div class="widget-field">
                <label><?php echo esc_attr__('Text', 'carhouse');?>:</label>
                <textarea class="widefat form-control" name="<?php echo $this->get_field_name('text'); ?>"
                          placeholder="<?php echo esc_attr__('Title', 'carhouse');?>" rows="10"><?php echo isset($instance['text']) ? $instance['text'] : null; ?></textarea>
            </div>
        </div>
        <?php
    }

    /**
     * @param array $new_instance
     * @param array $old_instance
     * @return array
     */
    public function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        $instance['title'] = $new_instance['title'];
        $instance['text'] = $new_instance['text'];
        return $instance;
    }

    /**
     * @param array $args
     * @param array $instance
     */
    public function widget($args, $instance)
    {
        extract($args);
        $title = $instance['title'];
        $text = $instance['text'];
        echo $before_widget; ?>

        <div class="footer-item-content">
            <h2><?php echo esc_attr($title); ?></h2>
            <div class="line-dec"></div>
            <p>
                <?php echo $text; ?>
            </p>
        </div>
        <?php echo $after_widget;
    }
}