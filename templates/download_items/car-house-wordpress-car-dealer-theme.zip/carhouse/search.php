<?php
global $carhouse;
// Displaying header

get_header();

$layout = $carhouse['blog_page_layout'];
if(!$layout){
    $layout = 'right_sidebar';
}

$title = $carhouse['blog_page_title'];
if (!$title) {
    $title = 'Blog';
}

$postPerPage = (int) get_option('posts_per_page');
if($postPerPage < 1){
    $postPerPage = 10;
}

$queryParam = null;
if(array_key_exists('s', $_GET)){
    $queryParam = $_GET['s'];
}
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
?>
    <div class="blog-banner">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <h2><?php echo esc_attr($title); ?></h2>
                    <?php
                    if($queryParam) {
                        echo esc_attr('Search Term: '. $queryParam);
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>

    <div class="blog-body">
        <div class="container">
            <div class="row">
                <div class="<?php echo esc_attr($layout == 'full_layout' ? 'col-lg-12 col-md-12 col-xs-12' : 'col-lg-8 col-md-8 col-xs-12');?> <?php echo esc_attr($layout == 'left_sidebar' ? 'col-lg-push-4' : '');?>">
                    <?php
                    $query = array(
                        'post_type' => 'post',
                        'post_status' => 'publish',
                        'paged' => $paged,
                        'posts_per_page' => $postPerPage,
                        's' => $queryParam,
                    );
                   /* if($authorId){
                        $query = array_merge($query, array('author__in' => array($authorId)));
                    }*/
                    $posts = new WP_Query($query);
                    if($posts->post_count > 0):?>
                        <?php
                        while ($posts->have_posts()): $posts->the_post();
                            get_template_part('elements/posts-list');
                        endwhile;
                        wp_reset_postdata()
                        ?>
                    <?php else:?>
                        <div class="error-404" style="margin-bottom: 150px;">
                            <div class="e404">
                                <div class="title-error">Post is Empty</div>
                                <p class="visible-lg visible-md">Sorry, No posts were found.</p>
                            </div>
                        </div>
                    <?php endif;?>

                    <?php if($posts->max_num_pages): ?>
                        <div class="page-count"><?php _e('Showing page','carhouse'); ?> <?php echo esc_attr($paged == 0 ? $paged + 1 : $paged); ?> <?php _e('of','carhouse'); ?> <?php echo esc_attr($posts->max_num_pages); ?></div>
                        <?php wp_carhouse_pagination($posts->max_num_pages); ?>
                        <br/>
                    <?php endif; ?>
                </div>
                <?php if($layout != 'full_layout'):?>
                    <div class="col-lg-4 col-md-4 col-xs-12 <?php echo esc_attr($layout == 'left_sidebar' ? 'col-lg-pull-8' : '');?>">
                        <?php get_sidebar('blog')?>
                    </div>
                <?php endif;?>
            </div>
        </div>
    </div>

<?php get_footer();?>