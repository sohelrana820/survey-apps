<?php

/**
 * Class TopHeaderButtons
 */
class TopHeaderButtons extends WP_Widget
{
    /**
     * TopHeaderButtons constructor.
     */
    public function __construct()
    {
        $widget_details = array(
            'classname' => 'top_header_buttons_widget',
            'description' => __('Top Header Buttons Widget', 'carhouse')
        );

        parent::__construct('top_header_buttons_widget', __('Car House: Buttons (Top Header)', 'carhouse'), $widget_details);
    }

    public function form($instance)
    {
        $text = !empty($instance['text']) ? $instance['text'] : '<a href="#" class="btn btn-grey btn-sm text-uppercase"><i class="fa fa-user pr-10"></i> Signup</a>
        <a href="#" class="btn btn-grey btn-sm text-uppercase"><i class="fa fa-lock pr-10"></i> Signin</a>';
        ?>
        <div class="widget_box">
            <div class="widget-field">
                <label><?php echo esc_attr__('Text', 'carhouse');?>:</label>
                <textarea class="widefat form-control" name="<?php echo $this->get_field_name('text'); ?>" placeholder="<?php echo esc_attr__('Header Buttons', 'carhouse');?>" rows="10"><?php echo $text; ?></textarea>
            </div>
        </div>
        <small>You can use any font-awesome icons (e.g fa fa-*)</small>
        <br/><br/>
        <div class="clearfix"></div>
        <?php
    }

    /**
     * @param array $new_instance
     * @param array $old_instance
     * @return array
     */
    public function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        $instance['text'] = $new_instance['text'];
        return $instance;
    }

    /**
     * @param array $args
     * @param array $instance
     */
    public function widget($args, $instance)
    {
        extract($args);
        $text = $instance['text'];
        echo $before_widget; ?>
        <?php echo $text;?>
        <?php echo $after_widget;
    }
}