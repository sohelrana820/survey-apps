<?php
// Require theme's necessary files
get_template_part('src/theme_options');
get_template_part('src/plugin-activation');
get_template_part('src/carhouse_function');

/**
 * Loading theme's assets [stylesheets & scripts]
 */
function wp_carhouse_load_theme_assets() {
    // Enqueue themes's stylesheets
    wp_enqueue_style( 'carhouse-style', get_stylesheet_uri(), array( 'bootstrap.min' ) );
    wp_enqueue_style('bootstrap.min', get_template_directory_uri(). '/assets/css/bootstrap.min.css', '3.3.7' );
    wp_enqueue_style('animate.min', get_template_directory_uri(). '/assets/css/animate.min.css' );
    wp_enqueue_style('slider', get_template_directory_uri(). '/assets/css/slider.css' );
    wp_enqueue_style('font-awesome.min', get_template_directory_uri(). '/assets/css/font-awesome/css/font-awesome.min.css', '4.5.0' );
    wp_enqueue_style('custom', get_template_directory_uri(). '/assets/css/custom.css' );
    wp_enqueue_style('ie10-viewport-bug-workaround', get_template_directory_uri(). '/assets/css/ie10-viewport-bug-workaround.css' );
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800%7COswald:200,300,400,500,600%7CRoboto:100,300,400,400i,500,700' );

    // Enqueue themes's conditional scripts
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
    wp_enqueue_script( 'carhouse-ie-emulation', get_template_directory_uri() . '/assets/js/ie-emulation-modes-warning.js',  array(), '20141010' );
    wp_enqueue_script( 'carhouse-html5shiv', get_template_directory_uri() . '/assets/js/html5shiv.min.js',  array(), '20141010' );
    wp_enqueue_script( 'carhouse-respond', get_template_directory_uri() . '/assets/js/respond.min.js',  array(), '20141010' );
    wp_script_add_data( 'carhouse-ie-emulation', 'conditional', 'lt IE 9' );
    wp_script_add_data( 'carhouse-html5shiv', 'conditional', 'lt IE 9' );
    wp_script_add_data( 'carhouse-respond', 'conditional', 'lt IE 9' );

    // Enqueue themes's scripts
    wp_enqueue_script( 'jquery-2.2.0.min', get_stylesheet_directory_uri() . '/assets/js/jquery-2.2.0.min.js', array(  ), null , true);
    wp_enqueue_script( 'bootstrap.min', get_stylesheet_directory_uri() . '/assets/js/bootstrap.min.js', array( 'jquery-2.2.0.min' ), null, true);
    wp_enqueue_script( 'bootstrap-slider', get_stylesheet_directory_uri() . '/assets/js/bootstrap-slider.js', array( 'jquery-2.2.0.min' ), null, true);
    wp_enqueue_script( 'app', get_stylesheet_directory_uri() . '/assets/js/app.js', array( 'jquery-2.2.0.min' ), null, true);
}
add_action( 'wp_enqueue_scripts', 'wp_carhouse_load_theme_assets' );

/**
 * Manage favicon icon
 */
function favicon_link() {
    $carhouseOption = get_option('carhouse');
    $iconUrl = get_template_directory_uri().'/assets/favicon.ico';
    if(isset($carhouseOption['opt_header_favicon']) && $carhouseOption['opt_header_favicon'] != '') {
        $iconUrl = $carhouseOption['opt_header_favicon']['url'];
    }
    echo '<link rel="shortcut icon" type="image/x-icon" href="'.$iconUrl.'" />';
}
add_action( 'wp_head', 'favicon_link' );

/**
 * Manage theme's inline style classes and javascript codes
 */
function wp_carhouse_inline_script()
{
    $carhouseOption = get_option('carhouse');
    $bannerBg = null;
    $hasBannerImg = get_field('inner_page_banner_image');
    if ($hasBannerImg) {
        $bannerBg = isset($hasBannerImg['url']) ? $hasBannerImg['url'] : null;
    } else if (rwmb_meta('single_page_banner_image', [], get_the_ID())) {
        $image = array_values(rwmb_meta('single_page_banner_image', [], get_the_ID()));
        $bannerBg = $image[0]['full_url'];
    } else if ($carhouseOption['opt_default_single_banner_image']) {
        $bannerBg = $carhouseOption['opt_default_single_banner_image']['url'];
    }

    // Inline Styling
    $headerImage = get_header_image();
    $inline_styles = "
                .main-header{
                        background-image: url({$headerImage});
                }
                .page-banner{
                        background-image: url({$bannerBg}) !important;
                }";

    wp_register_style( 'inline-style', false );
    wp_add_inline_style( "inline-style", $inline_styles);
    wp_enqueue_style('inline-style');

    // Inline Script
    $trackingCode = null;
    if(isset($carhouseOption['opt_analytic_tracking_id']) && $carhouseOption['opt_analytic_tracking_id'] != '') {
        $trackingCode = $carhouseOption['opt_analytic_tracking_id'];
    }

    $inline_script = '';
    if($trackingCode) {
        $inline_script .= <<<EOF
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
    ga('create', '$trackingCode', 'auto');
    ga('send', 'pageview');
EOF;
    }
    wp_register_script( 'inline-script', get_stylesheet_directory_uri() . '/assets/js/app.js', array (), false, true);
    wp_add_inline_script( "inline-script", $inline_script);

    $pageLoding = get_template_directory_uri().'/assets/img/loader.gif';
    if ((isset($carhouseOption['opt_default_page_loader'])) && $carhouseOption['opt_default_page_loader']['url']) {
        $pageLoding = $carhouseOption['opt_default_page_loader']['url'];
    }
    $wpLocalizeArray = array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'compare_page' => isset($carhouseOption['opt_default_compare_page']) ? rtrim(get_page_link($carhouseOption['opt_default_compare_page']),"/") : '',
        'loader_icon' => $pageLoding,
    );
    wp_localize_script( 'inline-script', 'wp_localize', $wpLocalizeArray );
    wp_enqueue_script('inline-script');

}
add_action( 'wp_enqueue_scripts', 'wp_carhouse_inline_script' );

/**
 * Setup theme
 */
function wp_carhouse_car_house_theme_setup()
{
    // Load themes text domain [textdomain]
    load_theme_textdomain('carhouse');

    // Add default posts and comments RSS feed links to head.
    add_theme_support('automatic-feed-links');

    add_theme_support('html5', array('search-form'));

    // Theme support cuctome header
    add_theme_support( 'custom-header', array('weight' => 1200, 'height' => 100) );

    // Theme support cuctome background
    add_theme_support("custom-background", array('default-color'          => '#ffffff',));


    add_theme_support('post-thumbnails');

    // Register navigation
    register_nav_menu('header-menu', __('Header Menu', 'carhouse'));
    register_nav_menu('footer-menu', __('Footer Menu', 'carhouse'));

    add_image_size( 'vehicle-details-image', 700, 500, true );
    add_image_size( 'team-member-photo', 400, 400, true );

    // Manage the page title.
    add_theme_support('title-tag');
}


add_filter( 'image_size_names_choose', 'wp_carhouse_custom_image_sixes' );
function wp_carhouse_custom_image_sixes( $sizes ) {
    $custom_sizes = array(
        'vehicle-details-image' => 'Vehicle Single Image',
        'team-member-photo' => 'Team Member Photo'
    );
    return array_merge( $sizes, $custom_sizes );
}

add_action('after_setup_theme', 'wp_carhouse_car_house_theme_setup');

/**
 * Manages the editor style
 */
add_action('init', 'wp_carhouse_add_editor_styles');
function wp_carhouse_add_editor_styles()
{
    add_editor_style(get_stylesheet_uri());
}

/**
 * Theme's pagination scripts
 */
if (!function_exists('wp_carhouse_pagination')) {
    /**
     * @param $maxPages
     * @param array $args
     * @return string
     */
    function wp_carhouse_pagination($maxPages, $args = array())
    {
        $defaults = array(
            'echo' => true,
            'query' => $GLOBALS['wp_query'],
            'show_all' => false,
            'prev_next' => true,
            'prev_text' => __('Previous Page', 'carhouse'),
            'next_text' => __('Next Page', 'carhouse'),
        );

        $args = wp_parse_args($args, $defaults);
        extract($args, EXTR_SKIP);

        $pagination = '';
        $links = array();

        $paged = max(1, absint($query->get('paged')));
        $max = intval($maxPages);

        if ($show_all) {
            $links = range(1, $max);
        } else {
            // Add the pages before the current page to the array
            if ($paged >= 2 + 1) {
                $links[] = $paged - 2;
                $links[] = $paged - 1;
            }

            // Add current page to the array
            if ($paged >= 1) {
                $links[] = $paged;
            }

            // Add the pages after the current page to the array
            if (($paged + 2) <= $max) {
                $links[] = $paged + 1;
                $links[] = $paged + 2;
            }
        }

        $pagination .= "\n" . '<ul class="pagination">' . "\n";
        // Previous Post Link
        if ($prev_next && get_previous_posts_link()) {
            $pagination .= sprintf('<li class="prev">%s</li>', get_previous_posts_link('&laquo;<span class="sr-only">' . $prev_text . '</span>'));
        }

        $pagination .= "\n";
        // Link to first page, plus ellipses if necessary
        if (!in_array(1, $links)) {
            $class = 1 == $paged ? ' class="active"' : '';
            $pagination .= sprintf('<li%s><a href="%s">%s</a></li>', $class, esc_url(get_pagenum_link(1)), '1');
            $pagination .= "\n";
            if (!in_array(2, $links)) {
                $pagination .= '<li class="ellipsis"><span>' . __('&hellip;', 'carhouse') . '</span></li>';
            }
            $pagination .= "\n";
        }
        // Link to current page, plus $mid_size pages in either direction if necessary
        sort($links);
        foreach ((array)$links as $link) {
            $class = $paged == $link ? ' class="active"' : '';
            $pagination .= sprintf('<li%s><a href="%s">%s</a></li>', $class, esc_url(get_pagenum_link($link)), $link);
            $pagination .= "\n";
        }
        // Link to last page, plus ellipses if necessary
        if (!in_array($max, $links)) {
            if (!in_array($max - 1, $links)) {
                $pagination .= '<li class="ellipsis"><span>' . __('&hellip;', 'carhouse') . '</span></li>';
                $pagination .= "\n";
            }
            $class = $paged == $max ? ' class="active"' : '';
            $pagination .= sprintf('<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url(get_pagenum_link($max)), $max);
            $pagination .= "\n";
        }
        // Next Post Link
        if ($prev_next && get_next_posts_link() && $paged <= $max) {
            $pagination .= sprintf('<li class="next">%s</li>' . "\n", get_next_posts_link('<span class="sr-only">' . $next_text . '</span>&raquo;'));
        }
        $pagination .= "</ul><!-- /.pagination -->\n";

        if ($echo) {
            echo $pagination;
        } else {
            return $pagination;
        }
    }
}

/**
 * Link register menu location with admin panel's menu section
 */
if (!function_exists('wp_carhouse_carhouse_menu_editor')) {
    /**
     * @param $args
     * @return string|void
     */
    function wp_carhouse_carhouse_menu_editor($args)
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        extract($args);

        $link = $link_before
            . '<a href="' . admin_url('nav-menus.php') . '">' . $before . 'Add a menu' . $after . '</a>'
            . $link_after;

        // We have a list
        if (FALSE !== stripos($items_wrap, '<ul')
            or FALSE !== stripos($items_wrap, '<ol')
        ) {
            $link = "<li>$link</li>";
        }

        $output = sprintf($items_wrap, $menu_id, $menu_class, $link);
        if (!empty ($container)) {
            $output = "<$container class='$container_class' id='$container_id'>$output</$container>";
        }

        if ($echo) {
            echo $output;
        }

        return $output;
    }
}

/**
 * @param $input
 * @return string
 *
 * Customize the custom post type's title placeholder.
 */
function wp_carhouse_custom_enter_title($input)
{
    global $post_type;

    if (is_admin() && 'Enter title here' == $input && 'teams' == $post_type) {
        return 'Name of Member';
    } else if (is_admin() && 'Enter title here' == $input && 'testimonials' == $post_type) {
        return 'Name of Client / Customer';
    } else if (is_admin() && 'Enter title here' == $input && 'faqs' == $post_type) {
        return 'Write Question';
    } else if (is_admin() && 'Enter title here' == $input && 'services' == $post_type) {
        return 'Name of Service';
    }
    return $input;
}
add_filter('gettext', 'wp_carhouse_custom_enter_title');

/**
 * @param $limit
 * @return array|mixed|string
 */
function wp_carhouse_excerpt($limit)
{
    $excerpt = explode(' ', get_the_excerpt(), $limit);
    if (count($excerpt) >= $limit) {
        array_pop($excerpt);
        $excerpt = implode(" ", $excerpt) . '...';
    } else {
        $excerpt = implode(" ", $excerpt);
    }
    $excerpt = preg_replace('`\[[^\]]*\]`', '', $excerpt);
    return $excerpt;
}

/**
 * @param $string
 * @param int $limit
 * @return array|mixed|string
 */
function wp_carhouse_text_truncate($string, $limit = 25)
{
    $string = explode(' ', $string, $limit);
    if (count($string) >= $limit) {
        array_pop($string);
        $string = implode(" ", $string) . '...';
    } else {
        $string = implode(" ", $string);
    }
    $string = preg_replace('`\[[^\]]*\]`', '', $string);
    return $string;
}


function wp_carhouse_truncate_string($string, $limit) {
    if (strlen($string) < $limit) {
        return $string;
    } else {
        $strArray = str_split($string, $limit);
        return count($strArray) > 1 ? $strArray[0] . '...' : $strArray[0];
    }
}

/**
 * Comment form hidden fields
 */
function wp_carhouse_comment_form_hidden_fields()
{
    comment_id_fields();
    if (current_user_can('unfiltered_html')) {
        wp_nonce_field('unfiltered-html-comment_' . get_the_ID(), '_wp_unfiltered_html_comment', false);
    }
}

/**
 * @param $location
 * @param $commentdata
 * @return string
 *
 * Redirect to comment section after reply
 */
function wp_carhouse_redirect_comments($location, $commentdata)
{
    if (!isset($commentdata) || empty($commentdata->comment_post_ID)) {
        return $location;
    }
    $post_id = $commentdata->comment_post_ID;
    /*if('my-custom-post' == get_post_type($post_id)){
        return wp_get_referer()."?success=true#comment-".$commentdata->comment_ID;
    }*/
    return wp_get_referer() . "?success=true#comment-" . $commentdata->comment_ID;
    return $location;
}
add_filter('comment_post_redirect', 'wp_carhouse_redirect_comments', 10, 2);

/************** CHOOSE ICON ON SERVICE ***************/
function wp_carhouse_font_awesome_icons()
{
    $icon = array(
        'no-icon' => 'No-Icon',
        'fa-adjust' => 'Adjust',
        'fa-adn' => 'Adn',
        'fa-align-center' => 'Align Center',
        'fa-align-justify' => 'Align Justify',
        'fa-align-left' => 'Align Left',
        'fa-align-right' => 'Align Right',
        'fa-ambulance' => 'Ambulance',
        'fa-anchor' => 'Anchor',
        'fa-android' => 'Android',
        'fa-angle-double-down' => 'Angle Double Down',
        'fa-angle-double-left' => 'Angle Double Left',
        'fa-angle-double-right' => 'Angle Double Right',
        'fa-angle-double-up' => 'Angle Double Up',
        'fa-angle-down' => 'Angle Down',
        'fa-angle-left' => 'Angle Left',
        'fa-angle-right' => 'Angle Right',
        'fa-angle-up' => 'Angle Up',
        'fa-apple' => 'Apple',
        'fa-archive' => 'Archive',
        'fa-arrow-circle-down' => 'Arrow Circle Down',
        'fa-arrow-circle-left' => 'Arrow Circle Left',
        'fa-arrow-circle-o-down' => 'Arrow Circle O Down',
        'fa-arrow-circle-o-left' => 'Arrow Circle O Left',
        'fa-arrow-circle-o-right' => 'Arrow Circle O Right',
        'fa-arrow-circle-o-up' => 'Arrow Circle O Up',
        'fa-arrow-circle-right' => 'Arrow Circle Right',
        'fa-arrow-circle-up' => 'Arrow Circle Up',
        'fa-arrow-down' => 'Arrow Down',
        'fa-arrow-left' => 'Arrow Left',
        'fa-arrow-right' => 'Arrow Right',
        'fa-arrows' => 'Arrows',
        'fa-arrows-alt' => 'Arrows Alt',
        'fa-arrows-h' => 'Arrows H',
        'fa-arrows-v' => 'Arrows V',
        'fa-arrow-up' => 'Arrow Up',
        'fa-asterisk' => 'Asterisk',
        'fa-automobile' => 'Automobile',
        'fa-backward' => 'Backward',
        'fa-ban' => 'Ban',
        'fa-bank' => 'Bank',
        'fa-bar-chart-o' => 'Bar Chart O',
        'fa-barcode' => 'Barcode',
        'fa-bars' => 'Bars',
        'fa-bed' => 'Bed',
        'fa-bed' => 'Hotel',
        'fa-beer' => 'Beer',
        'fa-behance' => 'Behance',
        'fa-behance-square' => 'Behance Square',
        'fa-bell' => 'Bell',
        'fa-bell-o' => 'Bell O',
        'fa-bitbucket' => 'Bitbucket',
        'fa-bitbucket-square' => 'Bitbucket Square',
        'fa-bitcoin' => 'Bitcoin',
        'fa-bold' => 'Bold',
        'fa-bolt' => 'Bolt',
        'fa-bomb' => 'Bomb',
        'fa-book' => 'Book',
        'fa-bookmark' => 'Bookmark',
        'fa-bookmark-o' => 'Bookmark O',
        'fa-briefcase' => 'Briefcase',
        'fa-btc' => 'Btc',
        'fa-bug' => 'Bug',
        'fa-building' => 'Building',
        'fa-building-o' => 'Building O',
        'fa-bullhorn' => 'Bullhorn',
        'fa-bullseye' => 'Bullseye',
        'fa-buysellads' => 'Buysellads',
        'fa-cab' => 'Cab',
        'fa-calendar' => 'Calendar',
        'fa-calendar-o' => 'Calendar O',
        'fa-camera' => 'Camera',
        'fa-camera-retro' => 'Camera Retro',
        'fa-car' => 'Car',
        'fa-caret-down' => 'Caret Down',
        'fa-caret-left' => 'Caret Left',
        'fa-caret-right' => 'Caret Right',
        'fa-caret-square-o-down' => 'Caret Square O Down',
        'fa-caret-square-o-left' => 'Caret Square O Left',
        'fa-caret-square-o-right' => 'Caret Square O Right',
        'fa-caret-square-o-up' => 'Caret Square O Up',
        'fa-caret-up' => 'Caret Up',
        'fa-cart-arrow-down' => 'Cart Arrow Down',
        'fa-cart-plus' => 'Cart Plus',
        'fa-certificate' => 'Certificate',
        'fa-chain' => 'Chain',
        'fa-chain-broken' => 'Chain Broken',
        'fa-check' => 'Check',
        'fa-check-circle' => 'Check Circle',
        'fa-check-circle-o' => 'Check Circle O',
        'fa-check-square' => 'Check Square',
        'fa-check-square-o' => 'Check Square O',
        'fa-chevron-circle-down' => 'Chevron Circle Down',
        'fa-chevron-circle-left' => 'Chevron Circle Left',
        'fa-chevron-circle-right' => 'Chevron Circle Right',
        'fa-chevron-circle-up' => 'Chevron Circle Up',
        'fa-chevron-down' => 'Chevron Down',
        'fa-chevron-left' => 'Chevron Left',
        'fa-chevron-right' => 'Chevron Right',
        'fa-chevron-up' => 'Chevron Up',
        'fa-child' => 'Child',
        'fa-circle' => 'Circle',
        'fa-circle-o' => 'Circle O',
        'fa-circle-o-notch' => 'Circle O Notch',
        'fa-circle-thin' => 'Circle Thin',
        'fa-clipboard' => 'Clipboard',
        'fa-clock-o' => 'Clock O',
        'fa-cloud' => 'Cloud',
        'fa-cloud-download' => 'Cloud Download',
        'fa-cloud-upload' => 'Cloud Upload',
        'fa-cny' => 'Cny',
        'fa-code' => 'Code',
        'fa-code-fork' => 'Code Fork',
        'fa-codepen' => 'Codepen',
        'fa-coffee' => 'Coffee',
        'fa-cog' => 'Cog',
        'fa-cogs' => 'Cogs',
        'fa-columns' => 'Columns',
        'fa-comment' => 'Comment',
        'fa-comment-o' => 'Comment O',
        'fa-comments' => 'Comments',
        'fa-comments-o' => 'Comments O',
        'fa-compass' => 'Compass',
        'fa-compress' => 'Compress',
        'fa-connectdevelop' => 'Connectdevelop',
        'fa-copy' => 'Copy',
        'fa-credit-card' => 'Credit Card',
        'fa-crop' => 'Crop',
        'fa-crosshairs' => 'Crosshairs',
        'fa-css3' => 'Css3',
        'fa-cube' => 'Cube',
        'fa-cubes' => 'Cubes',
        'fa-cut' => 'Cut',
        'fa-cutlery' => 'Cutlery',
        'fa-dashboard' => 'Dashboard',
        'fa-dashcube' => 'Dashcube',
        'fa-database' => 'Database',
        'fa-dedent' => 'Dedent',
        'fa-delicious' => 'Delicious',
        'fa-desktop' => 'Desktop',
        'fa-deviantart' => 'Deviantart',
        'fa-diamond' => 'Diamond',
        'fa-digg' => 'Digg',
        'fa-dollar' => 'Dollar',
        'fa-dot-circle-o' => 'Dot Circle O',
        'fa-download' => 'Download',
        'fa-dribbble' => 'Dribbble',
        'fa-dropbox' => 'Dropbox',
        'fa-drupal' => 'Drupal',
        'fa-edit' => 'Edit',
        'fa-eject' => 'Eject',
        'fa-ellipsis-h' => 'Ellipsis H',
        'fa-ellipsis-v' => 'Ellipsis V',
        'fa-empire' => 'Empire',
        'fa-envelope' => 'Envelope',
        'fa-envelope-o' => 'Envelope O',
        'fa-envelope-square' => 'Envelope Square',
        'fa-eraser' => 'Eraser',
        'fa-eur' => 'Eur',
        'fa-euro' => 'Euro',
        'fa-exchange' => 'Exchange',
        'fa-exclamation' => 'Exclamation',
        'fa-exclamation-circle' => 'Exclamation Circle',
        'fa-exclamation-triangle' => 'Exclamation Triangle',
        'fa-expand' => 'Expand',
        'fa-external-link' => 'External Link',
        'fa-external-link-square' => 'External Link Square',
        'fa-eye' => 'Eye',
        'fa-eye-slash' => 'Eye Slash',
        'fa-facebook' => 'Facebook',
        'fa-facebook-official' => 'Facebook Official',
        'fa-facebook-square' => 'Facebook Square',
        'fa-fast-backward' => 'Fast Backward',
        'fa-fast-forward' => 'Fast Forward',
        'fa-fax' => 'Fax',
        'fa-female' => 'Female',
        'fa-fighter-jet' => 'Fighter Jet',
        'fa-file' => 'File',
        'fa-file-archive-o' => 'File Archive O',
        'fa-file-audio-o' => 'File Audio O',
        'fa-file-code-o' => 'File Code O',
        'fa-file-excel-o' => 'File Excel O',
        'fa-file-image-o' => 'File Image O',
        'fa-file-movie-o' => 'File Movie O',
        'fa-file-o' => 'File O',
        'fa-file-pdf-o' => 'File Pdf O',
        'fa-file-photo-o' => 'File Photo O',
        'fa-file-picture-o' => 'File Picture O',
        'fa-file-powerpoint-o' => 'File Powerpoint O',
        'fa-files-o' => 'Files O',
        'fa-file-sound-o' => 'File Sound O',
        'fa-file-text' => 'File Text',
        'fa-file-text-o' => 'File Text O',
        'fa-file-video-o' => 'File Video O',
        'fa-file-word-o' => 'File Word O',
        'fa-file-zip-o' => 'File Zip O',
        'fa-film' => 'Film',
        'fa-filter' => 'Filter',
        'fa-fire' => 'Fire',
        'fa-fire-extinguisher' => 'Fire Extinguisher',
        'fa-flag' => 'Flag',
        'fa-flag-checkered' => 'Flag Checkered',
        'fa-flag-o' => 'Flag O',
        'fa-flash' => 'Flash',
        'fa-flask' => 'Flask',
        'fa-flickr' => 'Flickr',
        'fa-floppy-o' => 'Floppy O',
        'fa-folder' => 'Folder',
        'fa-folder-o' => 'Folder O',
        'fa-folder-open' => 'Folder Open',
        'fa-folder-open-o' => 'Folder Open O',
        'fa-font' => 'Font',
        'fa-forumbee' => 'Forumbee',
        'fa-forward' => 'Forward',
        'fa-foursquare' => 'Foursquare',
        'fa-frown-o' => 'Frown O',
        'fa-gamepad' => 'Gamepad',
        'fa-gavel' => 'Gavel',
        'fa-gbp' => 'Gbp',
        'fa-ge' => 'Ge',
        'fa-gear' => 'Gear',
        'fa-gears' => 'Gears',
        'fa-gift' => 'Gift',
        'fa-git' => 'Git',
        'fa-github' => 'Github',
        'fa-github-alt' => 'Github Alt',
        'fa-github-square' => 'Github Square',
        'fa-git-square' => 'Git Square',
        'fa-gittip' => 'Gittip',
        'fa-glass' => 'Glass',
        'fa-globe' => 'Globe',
        'fa-google' => 'Google',
        'fa-google-plus' => 'Google Plus',
        'fa-google-plus-square' => 'Google Plus Square',
        'fa-graduation-cap' => 'Graduation Cap',
        'fa-group' => 'Group',
        'fa-hacker-news' => 'Hacker News',
        'fa-hand-o-down' => 'Hand O Down',
        'fa-hand-o-left' => 'Hand O Left',
        'fa-hand-o-right' => 'Hand O Right',
        'fa-hand-o-up' => 'Hand O Up',
        'fa-hdd-o' => 'Hdd O',
        'fa-header' => 'Header',
        'fa-headphones' => 'Headphones',
        'fa-heart' => 'Heart',
        'fa-heartbeat' => 'Heartbeat',
        'fa-heart-o' => 'Heart O',
        'fa-history' => 'History',
        'fa-home' => 'Home',
        'fa-hospital-o' => 'Hospital O',
        'fa-h-square' => 'H Square',
        'fa-html5' => 'Html5',
        'fa-image' => 'Image',
        'fa-inbox' => 'Inbox',
        'fa-indent' => 'Indent',
        'fa-info' => 'Info',
        'fa-info-circle' => 'Info Circle',
        'fa-inr' => 'Inr',
        'fa-instagram' => 'Instagram',
        'fa-institution' => 'Institution',
        'fa-italic' => 'Italic',
        'fa-joomla' => 'Joomla',
        'fa-jpy' => 'Jpy',
        'fa-jsfiddle' => 'Jsfiddle',
        'fa-key' => 'Key',
        'fa-keyboard-o' => 'Keyboard O',
        'fa-krw' => 'Krw',
        'fa-language' => 'Language',
        'fa-laptop' => 'Laptop',
        'fa-leaf' => 'Leaf',
        'fa-leanpub' => 'Leanpub',
        'fa-legal' => 'Legal',
        'fa-lemon-o' => 'Lemon O',
        'fa-level-down' => 'Level Down',
        'fa-level-up' => 'Level Up',
        'fa-life-bouy' => 'Life Bouy',
        'fa-life-ring' => 'Life Ring',
        'fa-life-saver' => 'Life Saver',
        'fa-lightbulb-o' => 'Lightbulb O',
        'fa-link' => 'Link',
        'fa-linkedin' => 'Linkedin',
        'fa-linkedin-square' => 'Linkedin Square',
        'fa-linux' => 'Linux',
        'fa-list' => 'List',
        'fa-list-alt' => 'List Alt',
        'fa-list-ol' => 'List Ol',
        'fa-list-ul' => 'List Ul',
        'fa-location-arrow' => 'Location Arrow',
        'fa-lock' => 'Lock',
        'fa-long-arrow-down' => 'Long Arrow Down',
        'fa-long-arrow-left' => 'Long Arrow Left',
        'fa-long-arrow-right' => 'Long Arrow Right',
        'fa-long-arrow-up' => 'Long Arrow Up',
        'fa-magic' => 'Magic',
        'fa-magnet' => 'Magnet',
        'fa-mail-forward' => 'Mail Forward',
        'fa-mail-reply' => 'Mail Reply',
        'fa-mail-reply-all' => 'Mail Reply All',
        'fa-male' => 'Male',
        'fa-map-marker' => 'Map Marker',
        'fa-mars' => 'Mars',
        'fa-mars-double' => 'Mars Double',
        'fa-mars-stroke' => 'Mars Stroke',
        'fa-mars-stroke-h' => 'Mars Stroke H',
        'fa-mars-stroke-v' => 'Mars Stroke V',
        'fa-maxcdn' => 'Maxcdn',
        'fa-medium' => 'Medium',
        'fa-medkit' => 'Medkit',
        'fa-meh-o' => 'Meh O',
        'fa-mercury' => 'Mercury',
        'fa-microphone' => 'Microphone',
        'fa-microphone-slash' => 'Microphone Slash',
        'fa-minus' => 'Minus',
        'fa-minus-circle' => 'Minus Circle',
        'fa-minus-square' => 'Minus Square',
        'fa-minus-square-o' => 'Minus Square O',
        'fa-mobile' => 'Mobile',
        'fa-mobile-phone' => 'Mobile Phone',
        'fa-money' => 'Money',
        'fa-moon-o' => 'Moon O',
        'fa-mortar-board' => 'Mortar Board',
        'fa-motorcycle' => 'Motorcycle',
        'fa-music' => 'Music',
        'fa-navicon' => 'Navicon',
        'fa-neuter' => 'Fa Neuter',
        'fa-openid' => 'Openid',
        'fa-outdent' => 'Outdent',
        'fa-pagelines' => 'Pagelines',
        'fa-paperclip' => 'Paperclip',
        'fa-paper-plane' => 'Paper Plane',
        'fa-paper-plane-o' => 'Paper Plane O',
        'fa-paragraph' => 'Paragraph',
        'fa-paste' => 'Paste',
        'fa-pause' => 'Pause',
        'fa-paw' => 'Paw',
        'fa-pencil' => 'Pencil',
        'fa-pencil-square' => 'Pencil Square',
        'fa-pencil-square-o' => 'Pencil Square O',
        'fa-phone' => 'Phone',
        'fa-phone-square' => 'Phone Square',
        'fa-photo' => 'Photo',
        'fa-picture-o' => 'Picture O',
        'fa-pied-piper' => 'Pied Piper',
        'fa-pied-piper-alt' => 'Pied Piper Alt',
        'fa-pied-piper-square' => 'Pied Piper Square',
        'fa-pinterest' => 'Pinterest',
        'fa-pinterest-p' => 'Pinterest P',
        'fa-pinterest-square' => 'Pinterest Square',
        'fa-plane' => 'Plane',
        'fa-play' => 'Play',
        'fa-play-circle' => 'Play Circle',
        'fa-play-circle-o' => 'Play Circle O',
        'fa-plus' => 'Plus',
        'fa-plus-circle' => 'Plus Circle',
        'fa-plus-square' => 'Plus Square',
        'fa-plus-square-o' => 'Plus Square O',
        'fa-power-off' => 'Power Off',
        'fa-print' => 'Print',
        'fa-puzzle-piece' => 'Puzzle Piece',
        'fa-qq' => 'Qq',
        'fa-qrcode' => 'Qrcode',
        'fa-question' => 'Question',
        'fa-question-circle' => 'Question Circle',
        'fa-quote-left' => 'Quote Left',
        'fa-quote-right' => 'Quote Right',
        'fa-ra' => 'Ra',
        'fa-random' => 'Random',
        'fa-rebel' => 'Rebel',
        'fa-recycle' => 'Recycle',
        'fa-reddit' => 'Reddit',
        'fa-reddit-square' => 'Reddit Square',
        'fa-refresh' => 'Refresh',
        'fa-renren' => 'Renren',
        'fa-reorder' => 'Reorder',
        'fa-repeat' => 'Repeat',
        'fa-reply' => 'Reply',
        'fa-reply-all' => 'Reply All',
        'fa-retweet' => 'Retweet',
        'fa-rmb' => 'Rmb',
        'fa-road' => 'Road',
        'fa-rocket' => 'Rocket',
        'fa-rotate-left' => 'Rotate Left',
        'fa-rotate-right' => 'Rotate Right',
        'fa-rouble' => 'Rouble',
        'fa-rss' => 'Rss',
        'fa-rss-square' => 'Rss Square',
        'fa-rub' => 'Rub',
        'fa-ruble' => 'Ruble',
        'fa-rupee' => 'Rupee',
        'fa-save' => 'Save',
        'fa-scissors' => 'Scissors',
        'fa-search' => 'Search',
        'fa-search-minus' => 'Search Minus',
        'fa-search-plus' => 'Search Plus',
        'fa-sellsy' => 'Sellsy',
        'fa-send' => 'Send',
        'fa-send-o' => 'Send O',
        'fa-server' => 'Fa Server',
        'fa-share' => 'Share',
        'fa-share-alt' => 'Share Alt',
        'fa-share-alt-square' => 'Share Alt Square',
        'fa-share-square' => 'Share Square',
        'fa-share-square-o' => 'Share Square O',
        'fa-shield' => 'Shield',
        'fa-ship' => 'Ship',
        'fa-shirtsinbulk' => 'Shirtsinbulk',
        'fa-shopping-cart' => 'Shopping Cart',
        'fa-signal' => 'Signal',
        'fa-sign-in' => 'Sign In',
        'fa-sign-out' => 'Sign Out',
        'fa-simplybuilt' => 'Simplybuilt',
        'fa-sitemap' => 'Sitemap',
        'fa-skyatlas' => 'Skyatlas',
        'fa-skype' => 'Skype',
        'fa-slack' => 'Slack',
        'fa-sliders' => 'Sliders',
        'fa-smile-o' => 'Smile O',
        'fa-sort' => 'Sort',
        'fa-sort-alpha-asc' => 'Sort Alpha Asc',
        'fa-sort-alpha-desc' => 'Sort Alpha Desc',
        'fa-sort-amount-asc' => 'Sort Amount Asc',
        'fa-sort-amount-desc' => 'Sort Amount Desc',
        'fa-sort-asc' => 'Sort Asc',
        'fa-sort-desc' => 'Sort Desc',
        'fa-sort-down' => 'Sort Down',
        'fa-sort-numeric-asc' => 'Sort Numeric Asc',
        'fa-sort-numeric-desc' => 'Sort Numeric Desc',
        'fa-sort-up' => 'Sort Up',
        'fa-soundcloud' => 'Soundcloud',
        'fa-space-shuttle' => 'Space Shuttle',
        'fa-spinner' => 'Spinner',
        'fa-spoon' => 'Spoon',
        'fa-spotify' => 'Spotify',
        'fa-square' => 'Square',
        'fa-square-o' => 'Square O',
        'fa-stack-exchange' => 'Stack Exchange',
        'fa-stack-overflow' => 'Stack Overflow',
        'fa-star' => 'Star',
        'fa-star-half' => 'Star Half',
        'fa-star-half-empty' => 'Star Half Empty',
        'fa-star-half-full' => 'Star Half Full',
        'fa-star-half-o' => 'Star Half O',
        'fa-star-o' => 'Star O',
        'fa-steam' => 'Steam',
        'fa-steam-square' => 'Steam Square',
        'fa-step-backward' => 'Step Backward',
        'fa-step-forward' => 'Step Forward',
        'fa-stethoscope' => 'Stethoscope',
        'fa-stop' => 'Stop',
        'fa-street-view' => 'Street View',
        'fa-strikethrough' => 'Strikethrough',
        'fa-stumbleupon' => 'Stumbleupon',
        'fa-stumbleupon-circle' => 'Stumbleupon Circle',
        'fa-subscript' => 'Subscript',
        'fa-subway' => 'Fa Subway',
        'fa-suitcase' => 'Suitcase',
        'fa-sun-o' => 'Sun O',
        'fa-superscript' => 'Superscript',
        'fa-support' => 'Support',
        'fa-table' => 'Table',
        'fa-tablet' => 'Tablet',
        'fa-tachometer' => 'Tachometer',
        'fa-tag' => 'Tag',
        'fa-tags' => 'Tags',
        'fa-tasks' => 'Tasks',
        'fa-taxi' => 'Taxi',
        'fa-tencent-weibo' => 'Tencent Weibo',
        'fa-terminal' => 'Terminal',
        'fa-text-height' => 'Text Height',
        'fa-text-width' => 'Text Width',
        'fa-th' => 'Th',
        'fa-th-large' => 'Th Large',
        'fa-th-list' => 'Th List',
        'fa-thumbs-down' => 'Thumbs Down',
        'fa-thumbs-o-down' => 'Thumbs O Down',
        'fa-thumbs-o-up' => 'Thumbs O Up',
        'fa-thumbs-up' => 'Thumbs Up',
        'fa-thumb-tack' => 'Thumb Tack',
        'fa-ticket' => 'Ticket',
        'fa-times' => 'Times',
        'fa-times-circle' => 'Times Circle',
        'fa-times-circle-o' => 'Times Circle O',
        'fa-tint' => 'Tint',
        'fa-toggle-down' => 'Toggle Down',
        'fa-toggle-left' => 'Toggle Left',
        'fa-toggle-right' => 'Toggle Right',
        'fa-toggle-up' => 'Toggle Up',
        'fa-train' => 'Train',
        'fa-transgender' => 'Transgender',
        'fa-transgender-alt' => 'Transgender Alt',
        'fa-trash-o' => 'Trash O',
        'fa-tree' => 'Tree',
        'fa-trello' => 'Trello',
        'fa-trophy' => 'Trophy',
        'fa-truck' => 'Truck',
        'fa-try' => 'Try',
        'fa-tumblr' => 'Tumblr',
        'fa-tumblr-square' => 'Tumblr Square',
        'fa-turkish-lira' => 'Turkish Lira',
        'fa-twitter' => 'Twitter',
        'fa-twitter-square' => 'Twitter Square',
        'fa-umbrella' => 'Umbrella',
        'fa-underline' => 'Underline',
        'fa-undo' => 'Undo',
        'fa-university' => 'University',
        'fa-unlink' => 'Unlink',
        'fa-unlock' => 'Unlock',
        'fa-unlock-alt' => 'Unlock Alt',
        'fa-unsorted' => 'Unsorted',
        'fa-upload' => 'Upload',
        'fa-usd' => 'Usd',
        'fa-user' => 'User',
        'fa-user-md' => 'User Md',
        'fa-user-plus' => 'User Plus',
        'fa-users' => 'Users',
        'fa-user-secret' => 'User Secret',
        'fa-user-times' => 'User Times',
        'fa-venus' => 'Venus',
        'fa-venus-double' => 'Venus Double',
        'fa-venus-mars' => 'Venus Mars',
        'fa-viacoin' => 'Viacoin',
        'fa-video-camera' => 'Video Camera',
        'fa-vimeo-square' => 'Vimeo Square',
        'fa-vine' => 'Vine',
        'fa-vk' => 'Vk',
        'fa-volume-down' => 'Volume Down',
        'fa-volume-off' => 'Volume Off',
        'fa-volume-up' => 'Volume Up',
        'fa-warning' => 'Warning',
        'fa-wechat' => 'Wechat',
        'fa-weibo' => 'Weibo',
        'fa-weixin' => 'Weixin',
        'fa-whatsapp' => 'Whatsapp',
        'fa-wheelchair' => 'Wheelchair',
        'fa-windows' => 'Windows',
        'fa-won' => 'Won',
        'fa-wordpress' => 'Wordpress',
        'fa-wrench' => 'Wrench',
        'fa-xing' => 'Xing',
        'fa-xing-square' => 'Xing Square',
        'fa-yahoo' => 'Yahoo',
        'fa-yen' => 'Yen',
        'fa-youtube' => 'Youtube',
        'fa-youtube-play' => 'Youtube Play',
        'fa-youtube-square' => 'Youtube Square',
    );
    return $icon;
}


function wp_carhouse_service_meta_box()
{
    add_meta_box(
        'services_custom_fields_meta_box',
        'Choose Service Icon',
        'wp_carhouse_show_service_custom_fields',
        'services',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'wp_carhouse_service_meta_box');

function wp_carhouse_show_service_custom_fields()
{
    global $post;
    $iconClass = '';
    $meta = get_post_meta($post->ID, 'service_fields', true);
    if (is_array($meta) && array_key_exists('icon_class', $meta)) {
        $iconClass = str_replace('fa ', '', $meta['icon_class']);
    }
    ?>
    <input type="hidden" name="your_meta_box_nonce" value="<?php echo wp_create_nonce(basename(__FILE__)); ?>">

    <?php
    $icons = wp_carhouse_font_awesome_icons();
    ?>
    <div class="icon-list-area">
        <?php foreach ($icons as $key => $value): ?>
            <?php
            if (strpos($key, 'fa') !== false) { ?>
                <div class="single-icon <?php echo $iconClass == $key ? 'service-icon-selected' : '' ?>">
                    <i class="fa <?php echo esc_attr($key); ?>"></i>
                </div>
            <?php } ?>
        <?php endforeach; ?>
    </div>
    <p>
        <input type="hidden" name="service_fields[icon_class]" id="icon_class" class="regular-text"
               value="<?php echo esc_attr($meta['icon_class']); ?>">
    </p>

    <script>
        jQuery(document).ready(function ($) {
            var iconClass = 'fa fa-cogs';
            $('.single-icon').click(function (e) {
                //e.preventDefault();
                $(".single-icon").removeClass("service-icon-selected");
                $(this).addClass('service-icon-selected');
                iconClass = $(this).find('i').attr('class');
                $('#icon_class').val(iconClass);
            });
        });
    </script>
<?php }

function wp_carhouse_save_service_custom_meta_fields($post_id)
{
    // verify nonce
    if (!wp_verify_nonce(isset($_POST['your_meta_box_nonce']) ? $_POST['your_meta_box_nonce'] : false, basename(__FILE__))) {
        return $post_id;
    }
    // check autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }
    // check permissions
    if ('page' === $_POST['post_type']) {
        if (!current_user_can('edit_page', $post_id)) {
            return $post_id;
        } elseif (!current_user_can('edit_post', $post_id)) {
            return $post_id;
        }
    }

    $old = get_post_meta($post_id, 'service_fields', true);
    $new = $_POST['service_fields'];

    if ($new && $new !== $old) {
        update_post_meta($post_id, 'service_fields', $new);
    } elseif ('' === $new && $old) {
        delete_post_meta($post_id, 'service_fields', $old);
    }
}
add_action('save_post', 'wp_carhouse_save_service_custom_meta_fields');

function wp_carhouse_load_font_awesome()
{
    wp_enqueue_script('bootstrap.min', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'));
    wp_enqueue_style('font-awesome.min', get_template_directory_uri() . '/assets/css/font-awesome/css/font-awesome.min.css');
}
add_action('admin_enqueue_scripts', 'wp_carhouse_load_font_awesome');
/************** CHOOSE ICON ON SERVICE ***************/

// Rewrite rules for [vehicle] custom posts
add_rewrite_rule('^vehicles/page/([0-9]+)', 'index.php?pagename=vehicles&paged=$matches[1]', 'top');
add_rewrite_rule('^teams/page/([0-9]+)', 'index.php?pagename=teams&paged=$matches[1]', 'top');

// set the content width value
if (!isset($content_width)) {
    $content_width = 900;
}

// Calling these funcation for avoid [REQUIRED] message
wp_link_pages();

/**
 * @param $fields
 * @return array
 *
 * WordPress comments form
 */
function wp_carhouse_comment_form_fields($fields)
{
    $commenter = wp_get_current_commenter();
    $req = get_option('require_name_email');
    $aria_req = ($req ? " aria-required='true'" : '');
    $html5 = current_theme_supports('html5', 'comment-form') ? 1 : 0;

    $fields = array(
        'author' => '<div class="row"><div class="col-lg-4"><div class="form-group comment-form-author">' .
            '<input class="form-control input-text" id="author" name="author" type="text" value="' . esc_attr($commenter['comment_author']) . '" size="30"' . $aria_req . ' /></div></div>',
        'email' => '<div class="col-lg-4"><div class="form-group comment-form-email">' .
            '<input class="form-control input-text" id="email" name="email" ' . ($html5 ? 'type="email"' : 'type="text"') . ' value="' . esc_attr($commenter['comment_author_email']) . '" size="30"' . $aria_req . ' /></div></div>',
        'url' => '<div class="col-lg-4"><div class="form-group comment-form-url">' .
            '<input class="form-control input-text" id="url" name="url" ' . ($html5 ? 'type="url"' : 'type="text"') . ' value="' . esc_attr($commenter['comment_author_url']) . '" size="30" /></div></div></div>'
    );

    return $fields;
}
add_filter('comment_form_default_fields', 'wp_carhouse_comment_form_fields');

/**
 * @param $args
 * @return mixed
 */
function wp_carhouse_comment_form($args)
{
    $args['comment_field'] = '<div class="form-group comment-form-comment">
            <textarea class="form-control input-text" id="comment" name="comment" cols="45" rows="8" aria-required="true"></textarea>
        </div>';
    $args['class_submit'] = 'btn details-button';
    return $args;
}
add_filter('comment_form_defaults', 'wp_carhouse_comment_form');

/**
 * @param $vehiclesIds
 * @return WP_Query
 */
function wp_carhouse_gte_compare_entities($vehiclesIds){
    $vehicles = [];
    $allFeatures = [];
    $customFields = wp_carhouse_get_custom_fiels($vehiclesIds);
    foreach ($vehiclesIds as $index => $id) {
        $args = array(
            'p'         => $id,
            'post_type' => 'vehicles'
        );
        $vehicleDetails = new WP_Query( $args );
        if (isset($vehicleDetails->posts[0])) {
            $vehicleDetails = (array) $vehicleDetails->posts[0];
            foreach ($customFields as $field){
                $vehicleDetails[$field] = get_post_meta($id, $field, true) ? get_post_meta($id, $field, true) : 'N/A';
            }
        }

        $vehicles[$index]['details'] = $vehicleDetails;
        $vehicles[$index]['features'] = wp_carhouse_generate_features(rwmb_meta('vehicle_features', [], $id));
        $vehicles[$index]['brand'] = rwmb_meta('vehicle_brand', [], $id);;
        $vehicles[$index]['transmission'] = rwmb_meta('vehicle_transmission', [], $id);;
        $vehicles[$index]['fuel'] = rwmb_meta('vehicle_fuel', [], $id);;
        $vehicles[$index]['condition'] = rwmb_meta('vehicle_condition', [], $id);;
        $vehicles[$index]['category'] = rwmb_meta('vehicle_category', [], $id);;
        $allFeatures = array_merge($allFeatures, $vehicles[$index]['features']);
    }

    $compareItem = [
            'items' => $vehicles,
            'all_features' => $allFeatures
    ];

    return $compareItem;
}

/**
 * @param $ids
 * @return array
 */
function wp_carhouse_get_custom_fiels($ids) {
    $customFields = ['vehicle_manufacture_year', 'vehicle_engine', 'vehicle_mileage', 'vehicle_miles', 'vehicle_horse_power',
        'vehicle_doors', 'vehicle_drive_train', 'vehicle_interior_color', 'vehicle_exterior_color', 'vehicle_top_speed',
        'vehicle_odometer', 'vehicle_torque'];
    foreach ($ids as $index => $id) {
        $customFields = array_merge($customFields, array_diff(array_keys(get_post_custom($id)), ['_edit_last', 'custom_attributes', '']));
    }

    return $customFields;
}

/**
 * @param $features
 * @return array
 */
function wp_carhouse_generate_features($features) {
    $resultArray = [];
    if(is_array($features)) {
        foreach ($features as $feature) {
            $resultArray[] = $feature->name;
        }
    }
    return $resultArray;
}

/**
 * @return mixed
 */
function wp_query_all_vehicles_array(){
    $args = array(
        'post_type'     => 'vehicles',
        'post_status'   => 'publish',
        'meta_query'    => array(
            array(
                'key' => 'vehicle_status',
                'value' => 'active',
                'compare' => '=',
            ),
            'key' => 'vehicle_expiry',
            'value' => date("Y-m-d"),
            'compare' => '>=',
            'type' => 'DATE'
        ),
    );
    $result_query = new WP_Query( $args );
    $ids = $result_query->posts;
    wp_reset_postdata();
    return $ids;
}

/**
 * @return mixed
 */
function wp_carhouse_get_ralated_vehicle($id){

    $terms = get_the_terms( $id, 'vehicle_brands' );
    $term_list = array();
    foreach( $terms as $term ) {
        $term_list[] = $term->slug;
    }
    $related_args = array(
        'post_type' => 'vehicles',
        'posts_per_page' => 10,
        'post_status' => 'publish',
        'post__not_in' => array( $id ),
        'orderby' => 'rand',
        'tax_query' => array(
            array(
                'taxonomy' => 'vehicle_brands',
                'field' => 'slug',
                'terms' => $term_list
            )
        )
    );

    $result = new WP_Query( $related_args );
    return $result;
}

add_image_size( 'custom-size', 700, 500, true ); // 220 pixels wide by 180 pixels tall, hard crop mode

// Remove Redux Demo
add_action( 'redux/loaded', 'remove_demo' );