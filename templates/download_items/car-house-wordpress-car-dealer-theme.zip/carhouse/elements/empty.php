<?php global $carhouse;?>
<div class="error-404">
    <div class="e404">
        <!--<h1>NOT FOUND</h1>-->
        <div class="title-error"><?php echo esc_attr__('Result Empty', 'carhouse')?></div>
    </div>
</div>