<div class="col-lg-12">
    <div <?php post_class();?>>
        <div class="list-car-box single-car-box">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 list-car-pic clearfix">
                    <?php
                    global $carhouse;
                    $image = array_values(rwmb_meta( 'vehicle_main_image',['size' => 'vehicle-details-image'], get_the_ID()));
                    $title = the_title('', '', false);

                    $alt = null;
                    if (!$alt && isset($image[0]) && $image[0]['alt'] != '') {
                        $alt = $image[0]['alt'];
                    } elseif (!$alt && isset($image[0]) && $image[0]['title'] != '') {
                        $alt = $image[0]['title'];
                    }elseif (!$alt && isset($image[0]) && $image[0]['caption'] != '') {
                        $alt = $image[0]['caption'];
                    } else {
                        $alt = $title;
                    }

                    if(sizeof($image) > 0){
                        $vehicleImg = $image[0]['url'];
                    } else {
                        $vehicleImg = $carhouse['opt_default_vehicle_image']['url'];
                    }
                    ?>
                    <img src='<?php echo esc_url($vehicleImg)?>' alt='<?php echo esc_attr($alt);?>' class="img-responsive">

                    <?php if(isset($carhouse['opt_default_compare_page']) && $carhouse['opt_default_compare_page']):?>
                        <div class="pull-right compare-btns visible-xs">
                            <a class="btn details-button-2 add_compare show_it" data-id="<?php echo get_the_ID()?>">Add to Compare</a>
                            <a class="btn details-button-2 remove_compare hide_it" data-id="<?php echo get_the_ID()?>">Remove From Compare</a>
                        </div>
                    <?php endif;?>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 car-content clearfix">
                    <div class="header b-items-cars-one-info-header  s-lineDownLeft">
                        <h3>
                            <a href="<?php echo esc_url(get_permalink())?>"><?php echo wp_html_excerpt($title, 30, '...')?></a>
                            <span><?php echo esc_attr($carhouse['opt_default_currency']);?><?php echo esc_attr(number_format(get_post_meta(get_the_ID(), 'vehicle_sale_price', true), 2))?></span>
                        </h3>
                    </div>
                    <div class="line-border"></div>

                    <p class="visible-md visible-sm"><?php echo wp_html_excerpt(get_post_meta(get_the_ID(), 'vehicle_short_description', true), 100, '...')?></p>
                    <p class="hidden-md hidden-sm"><?php echo wp_html_excerpt(get_post_meta(get_the_ID(), 'vehicle_short_description', true), 150, '...')?></p>


                    <div class="item">
                        <div class="col-md-5 col-sm-5 col-xs-12 col-pad">
                            <p>
                                <span><?php echo esc_attr__('Brand', 'carhouse')?>:</span>
                                <?php
                                $brand = rwmb_meta( 'vehicle_brand',[], get_the_ID());
                                echo isset($brand->name) ? esc_attr($brand->name) : 'N/A';
                                ?>
                            </p>
                            <p>
                                <span><?php echo esc_attr__('Transmission', 'carhouse');?>:</span>
                                <?php
                                $transmission = rwmb_meta( 'vehicle_transmission',[], get_the_ID());
                                echo isset($transmission->name) ? esc_attr($transmission->name) : 'N/A';
                                ?>
                            </p>
                            <p>
                                <span>Mileage:</span>
                                <?php
                                $mileage = get_post_meta(get_the_ID(), 'vehicle_mileage', true);
                                echo $mileage ? esc_attr($mileage . 'ml') : 'N/A';
                                ?>
                            </p>
                        </div>
                        <div class="col-md-5 col-sm-5 col-xs-12 col-pad">
                            <p>
                                <span><?php echo esc_attr__('Category', 'carhouse');?>:</span>
                                <?php
                                $category = rwmb_meta( 'vehicle_category',[], get_the_ID());
                                echo isset($category->name) ? esc_attr($category->name) : 'N/A';
                                ?>
                            </p>
                            <p>
                                <span><?php echo esc_attr__('Fuel', 'carhouse');?>:</span>
                                <?php
                                $fuel = rwmb_meta( 'vehicle_fuel',[], get_the_ID());
                                echo isset($fuel->name) ? esc_attr($fuel->name) : 'N/A';
                                ?>
                            </p>
                            <p>
                                <span><?php echo esc_attr__('Engine', 'carhouse');?>:</span>
                                <?php
                                $engine = get_post_meta(get_the_ID(), 'vehicle_engine', true);
                                echo $engine ? esc_attr($engine) : 'N/A';
                                ?>
                            </p>
                        </div>
                        <div class="col-md-2 col-sm-2 col-xs-12 col-pad text-right">
                            <!--<a href="<?php /*echo esc_url(get_permalink());*/?>" class="btn details-button-2">
                                <?php /*echo esc_attr($carhouse['opt_default_listing_details_button']);*/?>
                            </a>-->
                        </div>
                    </div>
                </div>
            </div>
            <?php if(isset($carhouse['opt_default_compare_page']) && $carhouse['opt_default_compare_page']):?>
                <div class="pull-right compare-btns hidden-xs">
                    <a class="btn details-button-2 add_compare show_it" data-id="<?php echo get_the_ID()?>">Add to Compare</a>
                    <a class="btn details-button-2 remove_compare hide_it" data-id="<?php echo get_the_ID()?>">Remove From Compare</a>
                </div>
            <?php endif;?>
        </div>
    </div>
</div>