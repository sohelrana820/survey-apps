<?php

// Require footer widget files.
get_template_part('src/widgets/FooterLocation');
get_template_part('src/widgets/FooterShortDescription');
get_template_part('src/widgets/FooterTags');
get_template_part('src/widgets/FooterRecentVehicles');
get_template_part('src/widgets/FooterGallery');

// Require sidebar widget files.
get_template_part('src/widgets/SidebarRecentPosts');
get_template_part('src/widgets/SidebarTags');
get_template_part('src/widgets/SidebarHelpCenter');
get_template_part('src/widgets/SidebarRecentVehicle');
get_template_part('src/widgets/SidebarFeaturedVehicle');
get_template_part('src/widgets/SidebarVehicleSearch');
get_template_part('src/widgets/SidebarSocialShare');
get_template_part('src/widgets/SidebarSendMessage');
get_template_part('src/widgets/SidebarBlogSearch');

// Require common widget files.
get_template_part('src/widgets/Video');
get_template_part('src/widgets/CustomTextWidget');


// Require header widget files.
get_template_part('src/widgets/TopHeaderButtons');

function wp_carhouse_register_theme_sidebars()
{
    register_sidebar(array(
        'name' => 'Footer Widget 4',
        'id' => 'footer_widget_4',
        'before_widget' => '<div>',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="rounded">',
        'after_title' => '</h2>',
    ));

    register_sidebar(array(
        'name' => 'Footer Widget 1',
        'id' => 'footer_widget_1',
        'before_widget' => '<div>',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="rounded">',
        'after_title' => '</h2>',
    ));

    register_sidebar(array(
        'name' => 'Footer Widget 2',
        'id' => 'footer_widget_2',
        'before_widget' => '<div>',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="rounded">',
        'after_title' => '</h2>',
    ));

    register_sidebar(array(
        'name' => 'Footer Widget 3',
        'id' => 'footer_widget_3',
        'before_widget' => '<div>',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="rounded">',
        'after_title' => '</h2>',
    ));

    /*register_sidebar(array(
        'name' => 'Footer Widget 5',
        'id' => 'footer_widget_5',
        'before_widget' => '<div>',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="rounded">',
        'after_title' => '</h2>',
    ));*/

    register_sidebar(array(
        'name' => 'Blog Sidebar',
        'id' => 'sidebar_widget',
        'before_widget' => '<div>',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="rounded">',
        'after_title' => '</h2>',
    ));

    register_sidebar(array(
        'name' => 'Vehicle Listing Sidebar',
        'id' => 'vehicle_listing_widget',
        'before_widget' => '<div>',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="rounded">',
        'after_title' => '</h2>',
    ));

    register_sidebar(array(
        'name' => 'Vehicle Single Page Sidebar',
        'id' => 'single_vehicle_widget',
        'before_widget' => '<div>',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="rounded">',
        'after_title' => '</h2>',
    ));

    register_sidebar(array(
        'name' => 'Top Header Buttons',
        'id' => 'vehicle_top_header_widget',
        'before_widget' => '<div>',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="rounded">',
        'after_title' => '</h2>',
    ));
}

add_action('widgets_init', 'wp_carhouse_register_theme_sidebars');
add_action('widgets_init', 'wp_carhouse_load_theme_widgets');

function wp_carhouse_load_theme_widgets()
{
    // Register footer widgets
    register_widget('FooterLocation');
    register_widget('FooterShortDescription');
    register_widget('FooterTags');
    register_widget('FooterRecentVehicles');
    register_widget('FooterGallery');

    // Register sidebar widgets
    register_widget('SidebarRecentPosts');
    register_widget('SidebarTags');
    register_widget('SidebarHelpCenter');
    register_widget('SidebarRecentVehicle');
    register_widget('SidebarFeaturedVehicle');
    register_widget('SidebarVehicleSearch');
    register_widget('SidebarSocialShare');
    register_widget('SidebarSendMessage');
    register_widget('SidebarBlogSearch');

    // Register common widgets
    register_widget('CustomTextWidget');
    register_widget('Video');

    // Register header widgets
    register_widget('TopHeaderButtons');
}

