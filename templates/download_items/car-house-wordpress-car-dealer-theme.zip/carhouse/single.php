<?php
global $carhouse;
// Displaying header

get_header();

$layout = $carhouse['blog_page_layout'];
if(!$layout){
	$layout = 'right_sidebar';
}

$title = $carhouse['blog_page_title'];
if (!$title) {
	$title = 'Blog';
}
?>
	<div class="blog-banner">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<h2><?php echo esc_attr($title); ?></h2>
					<a href="<?php echo esc_url(get_permalink());?>"><?php echo esc_attr(the_title());?></a>
				</div>
			</div>
		</div>
	</div>

	<div class="blog-body">
		<div class="container">
			<div class="row">
				<div class="<?php echo esc_attr($layout == 'full_layout' ? 'col-lg-12 col-md-12 col-xs-12' : 'col-lg-8 col-md-8 col-xs-12');?> <?php echo esc_attr($layout == 'left_sidebar' ? 'col-lg-push-4' : '');?>">
					<?php
					if(have_posts()):?>
						<?php while (have_posts()): the_post(); ?>
							<div class="thumbnail blog-box clearfix">
								<div <?php post_class();?>>
									<?php
									$title = the_title('', '', false);
									if(has_post_thumbnail()){
										echo get_the_post_thumbnail(null, 'post-thumbnail', array('class' => 'post-full-img'));
									} else {
										echo '<img src="'.esc_attr($carhouse['opt_default_featured_image']['url']).'" alt="'.esc_attr($title).'">';
									}

									$thumbUrl = get_the_post_thumbnail_url();
									if(!$thumbUrl){
										$thumbUrl = $carhouse['opt_default_featured_image']['url'];
									}
									$postUrl = get_permalink();
									?>
									<!-- detail -->
									<div class="caption detail">
										<!-- Title -->
										<h1 class="title">
											<a href="<?php echo esc_url(get_permalink());?>"><?php echo esc_attr($title);?></a>
										</h1>
										<!-- Post Materials-->
										<div class="post-materials">
											<div class="header">
												BY <?php echo get_the_author_posts_link();?>
												<i class="fa fa-clock-o"></i> <?php echo esc_attr(date('M d, Y', strtotime(get_the_date())));?>
												<i class="fa fa-bars"></i>
												<?php
												$separate_meta = __(', ', 'carhouse' );
												$categories = get_the_category_list( $separate_meta );
												echo $categories;
												?>
												<i class="fa fa-commenting-o"></i>
												<a href="#"><?php comments_number( 'no comments', 'one comments', '% comments' );?></a>
											</div>
											<!-- paragraph -->
                                            <div class="page_dynamic_content">
                                                <?php echo the_content(); ?>
                                            </div>
											<!-- Btn -->
										</div>


                                        <div class="row">
                                            <div class="col-lg-8 col-md-8">
                                                <!-- Tags box start-->
                                                <?php
                                                $tags = get_the_tags();
                                                if($tags):
                                                    ?>
                                                    <div class="tags-box">
                                                        <h2 class="title">Tags</h2>
                                                        <?php foreach ($tags as $tag):?>
                                                            <a href="<?php echo esc_url(get_tag_link($tag->term_id))?>" class="tags"><?php echo esc_attr($tag->name);?></a>
                                                        <?php endforeach;?>
                                                    </div>
                                                <?php endif;?>
                                                <!-- Tags box end-->
                                            </div>
                                            <div class="col-lg-4 col-md-4">
                                                <!-- Blog-share start -->
                                                <?php if($carhouse['blog_page_visible_share_icon'] == 'yes'):?>
                                                    <div class="blog-share">
                                                        <h2 class="title"><?php echo esc_attr($carhouse['blog_page_share_text'])?></h2>
                                                        <ul class="share-buttons">
                                                            <li class="bordered-right">
                                                                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_url($postUrl);?>" title="Share on Facebook" target="_blank">
                                                                    <i class="fa fa-facebook color-facebook"></i>
                                                                </a>
                                                            </li>
                                                            <li class="bordered-right">
                                                                <a href="https://twitter.com/intent/tweet?source=<?php echo esc_url($postUrl)?>&text=<?php echo esc_attr($title);?>" target="_blank" title="Share on Twitter">
                                                                    <i class="fa fa-twitter color-twitter"></i>
                                                                </a>
                                                            </li>
                                                            <li class="bordered-right">
                                                                <a href="https://plus.google.com/share?url=<?php echo esc_url($postUrl);?>" target="_blank" title="Share on Google Plus">
                                                                    <i class="fa fa-google-plus color-google"></i>
                                                                </a>
                                                            </li>
                                                            <li class="bordered-right">
                                                                <a href="http://www.linkedin.com/shareArticle?mini=true&url=<?php echo esc_url($postUrl);?>&title=<?php echo esc_attr($title);?>&summary=<?php echo wp_html_excerpt(get_the_content(), 200)?>" target="_blank" title="Share on LinkedIn">
                                                                    <i class="fa fa-linkedin color-linkedin"></i>
                                                                </a>
                                                            </li>
                                                            <li>
                                                                <a href="http://pinterest.com/pin/create/button/?url=<?php echo esc_url($postUrl);?>&media=<?php echo esc_url($thumbUrl);?>&description=<?php echo wp_html_excerpt(get_the_content(), 200)?>" target="_blank" title="Pin it">
                                                                    <i class="fa fa-pinterest color-pinterest"></i>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                <?php endif;?>
                                                <!-- Blog-share end -->
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
										<div class="clearfix"></div>
									</div>
								</div>
							</div>
							<div class="clearfix"></div>
							<?php
							if ( comments_open() || get_comments_number() ) :
								comments_template();
							endif;
							?>
						<?php endwhile; wp_reset_postdata()
						?>
					<?php endif;?>
				</div>
				<?php if($layout != 'full_layout'):?>
					<div class="col-lg-4 col-md-4 col-xs-12 <?php echo esc_attr($layout == 'left_sidebar' ? 'col-lg-pull-8' : '');?>">
						<?php get_sidebar('blog')?>
					</div>
				<?php endif;?>
			</div>
		</div>
	</div>

<?php get_footer();?>