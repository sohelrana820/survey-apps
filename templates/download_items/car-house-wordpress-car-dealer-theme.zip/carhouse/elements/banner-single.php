<?php
global $wp;
global $carhouse;

$breadcrumbItem = isset($wp_query->post->post_title) ? $wp_query->post->post_title : null;
$currentUrl = home_url(add_query_arg(array(), $wp->request));

$hasTitle = get_field('inner_page_banner_title');
if ($hasTitle) {
    $title = $hasTitle;
} else if (!$hasTitle && sizeof($_GET) > 0) {
    $title = 'Search Results';
} else {
    $title = $breadcrumbItem;
}

if (sizeof($_GET) > 0) {
    $breadcrumbItem = 'Search Results';
    if (array_key_exists('title', $_GET)) {
        $breadcrumbItem .= ': ' . $_GET['title'];
    }
    $currentUrl = $currentUrl . '?' . http_build_query($_GET);
}
?>

<div class="page-banner">
    <div class="breadcrumb-area">
        <h2><?php echo esc_attr($title); ?></h2>
        <div class="line-dec"></div>
        <h5><?php echo esc_attr(get_field('inner_page_banner_subtitle')); ?></h5>
        <p>
            <a href="<?php echo esc_url(get_home_url()); ?>" class="home-btn"><?php echo esc_attr__('Home', 'carhouse') ?></a>
            <a href="<?php echo esc_url($currentUrl); ?>" class="active-page"><?php echo esc_attr($breadcrumbItem); ?></a>
        </p>
    </div>
</div>
<div class="clearfix"></div>