<?php
get_header();
global $carhouse;
$sliders = isset($carhouse['opt-slides']) ? $carhouse['opt-slides'] : false;
if(is_array($sliders)){
    $sliders = array_values($sliders);
}
?>

<?php if(!is_home() && is_front_page() && is_array($sliders) && sizeof($sliders) > 0 && $sliders[0]['image'] != ''):?>
    <div class="banner">
        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
                <?php $count = 0; foreach($sliders as  $slide):?>
                    <div class="item <?php echo esc_attr($count == 0 ? 'active' : '');?>" style="background-image: url('<?php echo esc_url($slide['image']);?>')">
                        <div class="container">
                            <div class="banner-slider-inner-1">
                                <div class="banner-content">
                                    <h1><?php echo esc_attr($slide['title'])?></h1>
                                    <p class="lead"><?php echo esc_attr($slide['description'])?></p>
                                    <a class="btn details-button btn-get-started" href="<?php echo esc_url($slide['url'])?>">Learn More</a>
                                </div>
                                <!--<h4>Attract, High Performance, &amp; Convert<br>Outstanding Technology Combined</h4>-->
                            </div>
                        </div>
                    </div>
                    <?php $count++; endforeach;?>
            </div>
            <?php if(sizeof($sliders) > 1):?>
                <!-- Controls -->
                <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
          <span class="slider-mover-left" aria-hidden="true">
             <img src="<?php echo get_template_directory_uri()?>/assets/img/png/left-chevron.png" alt="left-chevron">
          </span>
                    <span class="sr-only"><?php echo esc_attr__('Previous', 'carhouse');?></span>
                </a>
                <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
            <span class="slider-mover-right" aria-hidden="true">
                <img src="<?php echo get_template_directory_uri()?>/assets/img/png/right-chevron.png" alt="right-chevron">
            </span>
                    <span class="sr-only"><?php echo esc_attr__('Next', 'carhouse');?></span>
                </a>
            <?php endif;?>
        </div>
    </div>
<?php else:?>
    <?php get_template_part('elements/banner-single');?>
<?php endif;?>

<?php
global $carhouse;
$vehicles = getActiveVehicles($args = ['posts_per_page' => (int) get_field('index_number_of_vehicle')]);
?>

<?php if($vehicles->post_count > 0): ?>
    <!-- Recent car start-->
    <div class="recent-car content-area">
        <div class="container">
            <div class="recent-car-content">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="section-heading">
                            <i class="fa fa-car"></i>
                            <h2>
                                <?php
                                echo get_field('index_listing_title') ? get_field('index_listing_title') : __('Recent Vehicle', 'carhouse')
                                ?>
                            </h2>
                            <div class="border"></div>
                            <h4>
                                <?php
                                echo get_field('index_listing_subtitle') ? get_field('index_listing_subtitle') : __('Recent Vehicle', 'carhouse')
                                ?>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <?php
                    while ($vehicles->have_posts()): $vehicles->the_post(); ?>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                            <?php get_template_part('elements/listing-grid') ?>
                        </div>
                    <?php endwhile; wp_reset_postdata();?>
                </div>
            </div>
        </div>
    </div>
    <!-- Recent car end-->
<?php endif;?>

<?php
if(get_field('enabled_disable_testimonial_section') == 'Yes'){
    get_template_part('elements/testimonials');
}
?>

<?php get_footer();?>