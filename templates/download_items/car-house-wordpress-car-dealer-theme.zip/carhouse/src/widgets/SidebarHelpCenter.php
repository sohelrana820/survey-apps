<?php

/**
 * Class SidebarHelpCenter
 */
class SidebarHelpCenter extends WP_Widget
{
    /**
     * SidebarHelpCenter constructor.
     */
    public function __construct()
    {
        $widget_details = array(
            'classname' => 'sidebar_help_center_widget',
            'description' => __('Sidebar Help Center Widget', 'carhouse')
        );

        parent::__construct('sidebar_help_center_widget', __('Car House: Help Center (Sidebar)', 'carhouse'), $widget_details);
    }

    public function form($instance)
    {
        $title = !empty($instance['title']) ? $instance['title'] : 'Help Center';
        $text = !empty($instance['text']) ? $instance['text'] : '
        <ul>
                <li>
                    <span>Contact:</span> Person: Alex TM
                </li>
                <li>
                    <span>Address:</span> 12 Street, Los Angeles, CA, 94101
                </li>
                <li>
                    <span>Phone:</span> <a href="tel:+55-417-634-7X71">+55 4XX-634-7071</a>
                </li>
                <li>
                    <span>Mobile:</span> <a href="tel:+55-417-634-7X71">+55 4XX-634-7071</a>
                </li>
            </ul>';
        ?>
        <div class="widget_box">
            <div class="widget-field">
                <label><?php echo esc_attr__('Title', 'carhouse');?></label>
                <input class="widefat form-control" name="<?php echo $this->get_field_name('title'); ?>"
                       placeholder="<?php echo esc_attr__('Title', 'carhouse');?>" value="<?php echo esc_attr($title); ?>"/>
            </div>
            <div class="widget-field">
                <label><?php echo esc_attr__('Text', 'carhouse');?>:</label>
                <textarea class="widefat form-control" name="<?php echo $this->get_field_name('text'); ?>" placeholder="<?php echo esc_attr__('Help center', 'carhouse');?>" rows="10"><?php echo $text; ?></textarea>
            </div>
        </div>
        <div class="clearfix"></div>
        <?php
    }

    /**
     * @param array $new_instance
     * @param array $old_instance
     * @return array
     */
    public function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        $instance['title'] = $new_instance['title'];
        $instance['text'] = $new_instance['text'];
        return $instance;
    }

    /**
     * @param array $args
     * @param array $instance
     */
    public function widget($args, $instance)
    {
        extract($args);
        $title = $instance['title'];
        $text = $instance['text'];
        echo $before_widget; ?>
        <div class="car-sidebar-right help-widget">
            <div class="dealer-contact mrg-b-30">
                <h2 class="title"><?php echo esc_attr($title);?></h2>
                <?php echo $text;?>
            </div>
        </div>
        <?php echo $after_widget;
    }
}