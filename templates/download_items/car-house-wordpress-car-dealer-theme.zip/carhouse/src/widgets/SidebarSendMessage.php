<?php

/**
 * Class SidebarSendMessage
 */
class SidebarSendMessage extends WP_Widget
{
    /**
     * SidebarSendMessage constructor.
     */
    public function __construct()
    {
        $widget_details = array(
            'classname' => 'sidebar_send_message_widget',
            'description' => __('Sidebar Send Message Widget', 'carhouse')
        );

        parent::__construct('sidebar_send_message_widget', __('Car House: Send Message (Sidebar)', 'carhouse'), $widget_details);
    }


    /**
     * @param array $instance
     */
    public function form($instance)
    {
        $title = !empty($instance['title']) ? $instance['title'] : 'Send Message';
        $formID = !empty($instance['formID']) ? $instance['formID'] : '0';
        ?>
        <div class="widget_box">
            <div class="widget-field">
                <label><?php echo esc_attr__('Title', 'carhouse');?></label>
                <input class="widefat form-control" name="<?php echo $this->get_field_name('title'); ?>"
                       placeholder="<?php echo esc_attr__('Title', 'carhouse');?>" value="<?php echo esc_attr($title); ?>"/>
            </div>
            <div class="widget-field">
                <label><?php echo esc_attr__('Choose Contact Form', 'carhouse');?></label>
                <?php
                $args = array('post_type' => 'wpcf7_contact_form', 'posts_per_page' => -1);
                $forms = array();
                if( $data = get_posts($args)){
                    foreach($data as $key){
                        $forms[$key->ID] = $key->post_title;
                    }
                }else{
                    $forms['0'] = esc_html__('No Contact Form found', 'carhouse');
                }
                ?>

                <select id="contact_form_id" class="widefat form-control" name="<?php echo $this->get_field_name('formID'); ?>">
                    <option value="0"><?php echo esc_attr__('Choose Form', 'carhouse')?></option>
                    <?php foreach ($forms as $key => $value):?>
                        <option value="<?php echo $key;?>" <?php echo $key == $formID ? 'selected': ''?> ><?php echo $value;?></option>
                    <?php endforeach;?>
                </select>
            </div>
        </div>
        <?php
    }

    /**
     * @param array $new_instance
     * @param array $old_instance
     * @return array
     */
    public function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        $instance['title'] = $new_instance['title'];
        $instance['formID'] = $new_instance['formID'];
        return $instance;
    }

    /**
     * @param array $args
     * @param array $instance
     */
    public function widget($args, $instance)
    {
        extract($args);
        $title = $instance['title'];
        $formID = (int) $instance['formID'];
        echo $before_widget; ?>

        <div class="car-sidebar-right">
            <div class="private-message-to-dealer mrg-b-30">
                <h2 class="title"><?php echo esc_attr($title);?></h2>
                <!-- Contact form start -->
                <div class="contact-form">
                    <?php
                        if($formID > 0) {
                            $shortCode = '[contact-form-7 id="'.$formID.'" title="'.$title.'"]';
                            echo do_shortcode($shortCode);
                        }
                    ?>
                </div>
                <!-- Contact form end -->
            </div>
        </div>
        <div class="clearfix"></div>
        <?php echo $after_widget;
    }
}