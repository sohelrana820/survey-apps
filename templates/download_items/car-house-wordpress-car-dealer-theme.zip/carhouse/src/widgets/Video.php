<?php

/**
 * Class Video
 */
class Video extends WP_Widget
{
    /**
     * Video constructor.
     */
    public function __construct()
    {
        $widget_details = array(
            'classname' => 'video_widget',
            'description' => __('Video Widget', 'carhouse')
        );

        parent::__construct('video_widget', __('Car House: Video Widget (Common)', 'carhouse'), $widget_details);
    }

    public function form($instance)
    {
        $title = !empty($instance['title']) ? $instance['title'] : 'Video';
        $embeddedUrl = !empty($instance['embedded_url']) ? $instance['embedded_url'] : '';
        ?>
        <div class="widget_box">
            <div class="widget-field">
                <label><?php echo esc_attr__('Title', 'carhouse');?></label>
                <input class="widefat form-control" name="<?php echo $this->get_field_name('title'); ?>"
                       placeholder="<?php echo esc_attr__('Title', 'carhouse');?>" value="<?php echo esc_attr($title); ?>"/>
            </div>
            <div class="widget-field">
                <label><?php echo esc_attr__('Video URL (Youtube)', 'carhouse');?>:</label>
                <textarea class="widefat form-control" name="<?php echo $this->get_field_name('embedded_url'); ?>" placeholder="<?php echo esc_attr__('Youtube video URL (i.g iframe)', 'carhouse');?>" rows="10"><?php echo $embeddedUrl; ?></textarea>
            </div>

            <?php if($embeddedUrl):?>
                <div class="widget-field youtube-player">
                    <label><?php echo esc_attr__('Current Video', 'carhouse');?>:</label>
                    <?php echo $embeddedUrl;?>
                </div>
            <?php endif;?>

        </div>
        <div class="clearfix"></div>
        <?php
    }

    /**
     * @param array $new_instance
     * @param array $old_instance
     * @return array
     */
    public function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        $instance['title'] = $new_instance['title'];
        $instance['embedded_url'] = $new_instance['embedded_url'];
        return $instance;
    }

    /**
     * @param array $args
     * @param array $instance
     */
    public function widget($args, $instance)
    {
        extract($args);
        $title = $instance['title'];
        $embeddedUrl = $instance['embedded_url'];
        echo $before_widget; ?>
        <div class="car-sidebar-right">
            <div class="dealer-contact mrg-b-30">
                <?php echo esc_attr($title) ? '<h2 class="title">'.$title.'</h2>' : '';?>
                <?php echo $embeddedUrl;?>
            </div>
        </div>
        <?php echo $after_widget;
    }
}