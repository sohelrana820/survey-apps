<?php
/*
Template Name: Teams (Team member page layout)
*/
?>

<?php
global $carhouse;
// Displaying header
get_header();


// Displaying single page banner
get_template_part('elements/banner-single');
?>



<div class="about-body team-page">
    <div class="container">
        <?php
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        $query = array(
            'post_type' => 'teams',
            'posts_per_page' => get_field('member_per_page'),
            'paged' => $paged,
            'meta_query' => array(
                [
                    'key' => 'member_status',
                    'value' => 'active',
                    'compare' => '=',
                ]
            )
        );
        $members = new WP_Query($query);
        ?>
        <section class="about-team-meet">
            <?php if($members->post_count > 0):?>
                <div class="title title-area">
                    <h2 class="h2-title"><?php echo esc_attr(get_field('team_member_title_text'));?></h2>
                    <hr/>
                </div>
                <div class="row mrg-t-20">
                    <?php while($members->have_posts()) : $members->the_post(); ?>
                        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 ">
                            <div class="thumbnail about-box clearfix">
                                <div <?php post_class();?>>
                                    <?php
                                    $memberName = get_the_title();
                                    $image = array_values(rwmb_meta('member_image', ['size' => 'team-member-photo'], get_the_ID()));
                                    if(sizeof($image) > 0){
                                        $memberImg = $image[0]['url'];
                                    } else {
                                        global $carhouse;
                                        $vehicleDummy = $carhouse['opt_default_profile_image']['url'];
                                        $memberImg = $vehicleDummy;
                                    }
                                    ?>
                                    <img src='<?php echo esc_url($memberImg);?>' alt='<?php esc_attr($memberName);?>' class='img-responsive'>
                                    <div class="caption content">
                                        <h6><?php echo esc_attr(get_post_meta(get_the_ID(), 'member_type', true));?></h6>
                                        <div class="header b-items-cars-one-info-header  s-lineDownLeft">
                                            <h3>
                                                <a href="<?php echo esc_url(get_permalink());?>"><?php echo esc_attr($memberName);?></a>
                                            </h3>
                                        </div>
                                        <p>
                                            <?php echo esc_attr(wp_carhouse_excerpt(15)) ?>
                                        </p>
                                        <ul class="social-list">
                                            <li>
                                                <a href="<?php echo get_post_meta(get_the_ID(), 'member_facebook', true) ? esc_attr(get_post_meta(get_the_ID(), 'member_facebook', true)) : '#'?>" class="facebook">
                                                    <i class="fa fa-facebook"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo get_post_meta(get_the_ID(), 'member_twitter', true) ? esc_attr(get_post_meta(get_the_ID(), 'member_twitter', true)) : '#'?>" class="twitter">
                                                    <i class="fa fa-twitter"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo get_post_meta(get_the_ID(), 'member_linkedin', true) ? esc_attr(get_post_meta(get_the_ID(), 'member_linkedin', true)) : '#'?>" class="linkedin">
                                                    <i class="fa fa-linkedin"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo get_post_meta(get_the_ID(), 'member_gplud', true) ? esc_attr(get_post_meta(get_the_ID(), 'member_gplud', true)) : '#'?>" class="google">
                                                    <i class="fa fa-google-plus"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo get_post_meta(get_the_ID(), 'member_vimeo', true) ? esc_attr(get_post_meta(get_the_ID(), 'member_vimeo', true)) : '#'?>" class="rss">
                                                    <i class="fa fa-vimeo"></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile;wp_reset_postdata(); ?>
                </div>

                <div class="page-count"><?php _e('Showing page','carhouse'); ?> <?php echo esc_attr($paged == 0 ? $paged + 1 : $paged); ?> <?php _e('of','carhouse'); ?> <?php echo esc_attr($members->max_num_pages); ?></div>
                <?php wp_carhouse_pagination($members->max_num_pages); ?>
                <br/>

            <?php else:?>
                <div class="error-404">
                    <div class="e404">
                        <div class="title-error"><?php echo esc_attr__('Team Member is Empty', 'carhouse')?></div>
                        <p class="visible-lg visible-md"><?php echo esc_attr__('Sorry, No team member were found.', 'carhouse');?></p>
                    </div>
                </div>
                <br/><br/>
            <?php endif;?>
        </section>
    </div>
</div>

<?php get_footer();?>